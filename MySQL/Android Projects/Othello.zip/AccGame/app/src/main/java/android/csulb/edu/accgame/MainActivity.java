package android.csulb.edu.accgame;

import android.app.Activity;
import android.os.Bundle;
import android.os.PowerManager;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity
{
    private static final String TAG = "android.csulb.edu.accgame.MainActivity";
    private PowerManager.WakeLock mWakeLock;
    SimulationView simulation;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(simulation = new SimulationView(this));

        PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
        mWakeLock = powerManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, TAG);
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        mWakeLock.acquire();
        simulation.startSimulation();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        mWakeLock.release();
        simulation.stopSimulation();
    }
}
