package android.csulb.edu.assignment4;

import android.app.LoaderManager;
import android.content.ContentValues;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends FragmentActivity implements LoaderManager.LoaderCallbacks<Cursor>
{
    private final LatLng LOCATION_UNIV = new LatLng(33.783768, -118.114336);
    private final LatLng LOCATION_ECS = new LatLng(33.782777, -118.111868);
    private GoogleMap map;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        map = ((MapFragment) getFragmentManager().findFragmentById(R.id.map)).getMap();
        getLoaderManager().initLoader(0, null, this);

        map.setOnMapClickListener(new GoogleMap.OnMapClickListener()
        {
            @Override
            public void onMapClick(LatLng latLng)
            {
                map.addMarker(new MarkerOptions().position(latLng));
                LocationInsertTask locationInsertTask = new LocationInsertTask();
                locationInsertTask.execute(createContentValues(latLng, map.getCameraPosition().zoom));
            }
        });

        map.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener()
        {
            @Override
            public void onMapLongClick(LatLng latLng)
            {
                map.clear();
                LocationDeleteTask locationDeleteTask = new LocationDeleteTask();
                locationDeleteTask.execute();
                Toast.makeText(MainActivity.this, "All markers removed", Toast.LENGTH_LONG).show();
            }
        });
    }

    private ContentValues createContentValues(LatLng latLng, float zoom)
    {
        ContentValues values = new ContentValues();
        values.put(LocationsDB.getKeyLatitude(), latLng.latitude);
        values.put(LocationsDB.getKeyLongitude(), latLng.longitude);
        values.put(LocationsDB.getKeyZoom(), zoom);

        return values;
    }

    private class LocationInsertTask extends AsyncTask<ContentValues, Void, Void>
    {
        @Override
        protected Void doInBackground(ContentValues... params)
        {
            getContentResolver().insert(LocationsContentProvider.CONTENT_URI, params[0]);

            return null;
        }
    }

    private class LocationDeleteTask extends AsyncTask<Void, Void, Void>
    {
        @Override
        protected Void doInBackground(Void... params)
        {
            getContentResolver().delete(LocationsContentProvider.CONTENT_URI, null, null);

            return null;
        }
    }

    public void onClick_Irvine(View view)
    {
        map.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(LOCATION_UNIV, 14);
        map.animateCamera(update);
    }

    public void onClick_LongBeachUniv(View view)
    {
        map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(LOCATION_ECS, 16);
        map.animateCamera(update);
    }

    public void onClick_City(View view)
    {
        map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
        CameraUpdate update = CameraUpdateFactory.newLatLngZoom(LOCATION_UNIV, 9);
        map.animateCamera(update);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int arg0, Bundle arg1)
    {
        Uri allLocations = LocationsContentProvider.CONTENT_URI;
        CursorLoader cursorLoader = new CursorLoader(this, allLocations, null, null, null, null);

        return cursorLoader;
    }

    @Override
    public void onLoadFinished(Loader<Cursor> arg0, Cursor arg1)
    {
        int locationCount = 0, zoom = 0;
        double lat = 0, lng = 0;
        LatLng latLng = LOCATION_UNIV;

        if (arg1 != null)
        {
            locationCount = arg1.getCount();
            arg1.moveToFirst();
        }
        else
            locationCount = 0;

        for (int i = 0; i < locationCount; i++)
        {
            lat = arg1.getDouble(1);
            lng = arg1.getDouble(2);
            zoom = arg1.getInt(3);

            latLng = new LatLng(lat, lng);
            map.addMarker(new MarkerOptions().position(latLng));

            arg1.moveToNext();
        }

        if (locationCount > 0)
        {
            CameraUpdate update = CameraUpdateFactory.newLatLngZoom(latLng, zoom);
            map.animateCamera(update);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader)
    {

    }
}
