package android.csulb.edu.assignment4;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Location;

import java.util.ArrayList;
import java.util.List;

public class LocationsDB extends SQLiteOpenHelper
{
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "locations";
    private static final String DATABASE_TABLE = "locations";
    private static final String KEY_ID = "_id";
    private static final String KEY_LATITUDE = "latitude";
    private static final String KEY_LONGITUDE = "longitude";
    private static final String KEY_ZOOM = "zoom";

    public LocationsDB(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String CREATE_CATEGORIES_TABLE = "CREATE TABLE " + DATABASE_TABLE + "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_LATITUDE + " REAL," + KEY_LONGITUDE + " REAL," + KEY_ZOOM + " REAL)";
        db.execSQL(CREATE_CATEGORIES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
        onCreate(db);
    }

    @Override
    public SQLiteDatabase getReadableDatabase()
    {
        return super.getReadableDatabase();
    }

    @Override
    public SQLiteDatabase getWritableDatabase()
    {
        return super.getWritableDatabase();
    }

    public void insertLocation(double lat, double lng, float zoom)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_LATITUDE, lat);
        values.put(KEY_LONGITUDE, lng);
        values.put(KEY_ZOOM, zoom);

        db.insert(DATABASE_TABLE, null, values);
        db.close();
    }

    public void insertLocation(double lat, double lng)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_LATITUDE, lat);
        values.put(KEY_LONGITUDE, lng);
        values.put(KEY_ZOOM, 2);

        db.insert(DATABASE_TABLE, null, values);
        db.close();
    }

    public List<Location> getAllLocations()
    {
        List<Location> locations = new ArrayList<Location>();
        String[] resultColumns = {KEY_LATITUDE, KEY_LONGITUDE};

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(DATABASE_TABLE, resultColumns, null, null, null, null, null);

        if(cursor.moveToFirst())
        {
            do
            {
                double lat = cursor.getDouble(0);
                double lng = cursor.getDouble(1);

                Location location = new Location("");
                location.setLatitude(lat);
                location.setLongitude(lng);

                locations.add(location);
            }
            while (cursor.moveToNext());
        }

        cursor.close();
        db.close();

        return locations;
    }

    public void deleteAllLocations()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(DATABASE_TABLE, null, null);
    }

    public String getDatabaseTable()
    {
        return DATABASE_TABLE;
    }

    public String getDatabaseName()
    {
        return DATABASE_NAME;
    }

    public int getDatabaseVersion()
    {
        return DATABASE_VERSION;
    }

    public static String getKeyLatitude()
    {
        return KEY_LATITUDE;
    }

    public static String getKeyLongitude()
    {
        return KEY_LONGITUDE;
    }

    public static String getKeyZoom()
    {
        return KEY_ZOOM;
    }
}
