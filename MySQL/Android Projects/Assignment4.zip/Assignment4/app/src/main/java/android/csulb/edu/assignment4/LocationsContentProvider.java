package android.csulb.edu.assignment4;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

import java.util.HashMap;

public class LocationsContentProvider extends ContentProvider
{
    static final String PROVIDER_NAME = "android.csulb.edu.assignment4";
    static final String URL = "content://" + PROVIDER_NAME + "/locations";
    static final Uri CONTENT_URI = Uri.parse(URL);
    static final int LOCATIONS = 1;
    static final int LOCATIONS_ID = 2;
    private LocationsDB locationsDB;
    private SQLiteDatabase db;
    private static HashMap<String, String> LOCATIONS_PROJECTION_MAP;

    static final UriMatcher uriMatcher;
    static
    {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(PROVIDER_NAME, "locations", LOCATIONS);
    }

    @Override
    public boolean onCreate()
    {
        locationsDB = new LocationsDB(getContext());

        db = locationsDB.getWritableDatabase();

        return (db == null)? false:true;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values)
    {
        long rowID = db.insert(locationsDB.getDatabaseTable(), null, values);

        if (rowID > 0)
        {
            Uri _uri = ContentUris.withAppendedId(CONTENT_URI, rowID);
            getContext().getContentResolver().notifyChange(_uri, null);
            return _uri;
        }

        throw new SQLException("Failed to add a record into " + uri);
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs)
    {
        int count = 0;

        switch (uriMatcher.match(uri))
        {
            case LOCATIONS:
                count = db.delete(locationsDB.getDatabaseTable(), selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown Uri " + uri);
        }

        getContext().getContentResolver().notifyChange(uri, null);

        return count;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder)
    {
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        qb.setTables(locationsDB.getDatabaseTable());

        switch (uriMatcher.match(uri))
        {
            case LOCATIONS:
                qb.setProjectionMap(LOCATIONS_PROJECTION_MAP);
                break;
            default:
                throw new IllegalArgumentException("Unknown Uri " + uri);
        }

        Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, sortOrder);
        c.setNotificationUri(getContext().getContentResolver(), uri);

        return c;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs)
    {
        int count = 0;

        switch (uriMatcher.match(uri))
        {
            case LOCATIONS:
                count = db.update(locationsDB.getDatabaseTable(), values, selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Unknown Uri " + uri);
        }

        getContext().getContentResolver().notifyChange(uri, null);

        return count;
    }

    @Override
    public String getType(Uri uri)
    {
        return null;
    }
}
