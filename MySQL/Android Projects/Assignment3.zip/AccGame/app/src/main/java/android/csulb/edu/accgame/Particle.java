package android.csulb.edu.accgame;

public class Particle
{
    private final static float COR = 0.7f;
    public float mPosX, mPosY, mVelX, mVelY;

    public void updatePosition(float sx, float sy, float sz, long timestamp)
    {
        float dt = (System.nanoTime() - timestamp) / 100000000.0f;

        mVelX += -sx * dt;
        mVelY += -sy * dt;

        mPosX += mVelX * dt;
        mPosY += mVelY * dt;
    }

    public void resolveCollisionWithBounds(float mHorizontalBounds, float mVerticalBounds)
    {
        if (mPosX > mHorizontalBounds)
        {
            mPosX = mHorizontalBounds;
            mVelX = -mVelX * COR;
        }
        else if (mPosX < -mHorizontalBounds)
        {
            mPosX = -mHorizontalBounds;
            mVelX = -mVelX * COR;
        }

        if (mPosY > mVerticalBounds)
        {
            mPosY = mHorizontalBounds;
            mVelY = -mVelY * COR;
        }
        else if (mPosY < -mVerticalBounds)
        {
            mPosY = -mVerticalBounds;
            mVelY = -mVelY * COR;
        }
    }
}
