package android.csulb.edu.accgame;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.Display;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;

public class SimulationView extends View implements SensorEventListener
{
    int mWidth, mHeight;
    private Bitmap mField, mBasket, mBitmap;
    private static final int BALL_SIZE = 64;
    private static final int BASKET_SIZE = 80;
    private float mXOrigin, mYOrigin, mHorizontalBound, mVerticalBound;
    private float x, y, z;
    private long t;
    Display mDisplay;
    SensorManager sensorManager;
    Particle mBall = new Particle();

    public SimulationView(Context context)
    {
        super(context);

        Bitmap ball = BitmapFactory.decodeResource(context.getResources(), R.drawable.ball);
        mBitmap = Bitmap.createScaledBitmap(ball, BALL_SIZE, BALL_SIZE, true);
        Bitmap basket = BitmapFactory.decodeResource(context.getResources(), R.drawable.basket);
        mBasket = Bitmap.createScaledBitmap(basket, BASKET_SIZE, BASKET_SIZE, true);

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inDither = true;
        options.inPreferredConfig = Bitmap.Config.RGB_565;

        mField = BitmapFactory.decodeResource(context.getResources(), R.drawable.field, options);

        WindowManager windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        mDisplay = windowManager.getDefaultDisplay();

        sensorManager = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME);

    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh)
    {
        super.onSizeChanged(w, h, oldw, oldh);
        Bitmap ball = BitmapFactory.decodeResource(getContext().getResources(), R.drawable.ball);
        mBitmap = Bitmap.createScaledBitmap(ball, BALL_SIZE, BALL_SIZE, true);
        Bitmap basket = BitmapFactory.decodeResource(getContext().getResources(), R.drawable.basket);
        mBasket = Bitmap.createScaledBitmap(basket, BASKET_SIZE, BASKET_SIZE, true);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inDither = true;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        mField = BitmapFactory.decodeResource(getContext().getResources(), R.drawable.field, options);
        WindowManager windowManager = (WindowManager) SimulationView.this.getContext().getSystemService(Context.WINDOW_SERVICE);
        mDisplay = windowManager.getDefaultDisplay();
    }

    @Override
    public void onSensorChanged(SensorEvent event)
    {
        if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
        {
            t = event.timestamp;

            if(getRotation() == Surface.ROTATION_0)
            {
                x = event.values[0];
                y = event.values[1];
                z = event.values[2];
            }
            else if(getRotation() == Surface.ROTATION_90)
            {
                x = -event.values[1];
                y = event.values[0];
            }
            else if(getRotation() == Surface.ROTATION_180)
            {
                x = -event.values[0];
                y = -event.values[1];
            }
            else if(getRotation() == Surface.ROTATION_270)
            {
                x = event.values[1];
                y = -event.values[0];
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy)
    {

    }

    public void startSimulation()
    {
        sensorManager.registerListener(this, sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_GAME);
    }

    public void stopSimulation()
    {
        sensorManager.unregisterListener(this);
    }

    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);

        canvas.drawBitmap(mField, (mWidth - mField.getWidth()) / 2, (mHeight - mField.getHeight()) / 2, null);
        canvas.drawBitmap(mBasket, (mWidth - BASKET_SIZE) / 2, 75, null);

        mBall.updatePosition(x, y, z, t);
        mBall.resolveCollisionWithBounds(mField.getWidth() / 2, mField.getHeight() / 2);

        canvas.drawBitmap(mBitmap, ((mWidth - BALL_SIZE) / 2) + mBall.mPosX, ((mHeight - BALL_SIZE) / 2) - mBall.mPosY, null);

        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
        mWidth = View.MeasureSpec.getSize(widthMeasureSpec);
        mHeight = View.MeasureSpec.getSize(heightMeasureSpec);

        setMeasuredDimension(mWidth, mHeight);
    }
}
