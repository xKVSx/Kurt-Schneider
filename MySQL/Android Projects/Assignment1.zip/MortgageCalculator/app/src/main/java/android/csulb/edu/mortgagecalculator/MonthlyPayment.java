package android.csulb.edu.mortgagecalculator;

public class MonthlyPayment
{
    public static double calcInterestWithTax (double p, int intAnnual, int n, double taxRate)
    {
        double monthlyPayment, monthlyInterest, result, taxes;

        taxes = p * taxRate;
        monthlyInterest = (intAnnual / 1200.0);
        result = Math.pow((1.0 + monthlyInterest), -(n * 12.0));
        monthlyPayment = (p * (monthlyInterest / (1.0 - result))) + taxes;

        return monthlyPayment;
    }

    public static double calcNoInterest (double p, int n, double taxRate)
    {
        double monthlyPayment, taxes;

        taxes = p * taxRate;
        monthlyPayment = (p / (n * 12)) + taxes;

        return monthlyPayment;
    }
}

