package android.csulb.edu.mortgagecalculator;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity
{
    EditText borrowed;
    TextView rate, mPayment;
    SeekBar interest;
    int term;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        borrowed = (EditText) findViewById(R.id.borrowed);
        rate = (TextView) findViewById(R.id.iLabel2);
        interest = (SeekBar) findViewById(R.id.interest);
        mPayment = (TextView) findViewById(R.id.mPayment);

        rate.setText(Integer.toString(interest.getProgress()));

        interest.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
        {
            int progressChanged = 0;

            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser)
            {
                progressChanged = progress;
                rate.setText(Integer.toString(progressChanged));
            }

            public void onStartTrackingTouch(SeekBar seekBar)
            {
                return;
            }

            public void onStopTrackingTouch(SeekBar seekBar)
            {
                return;
            }
        });
    }

    public void onClick (View view)
    {
        switch (view.getId())
        {
            case R.id.calculate:
                RadioButton fifteen = (RadioButton) findViewById(R.id.loan15);
                RadioButton twenty = (RadioButton) findViewById(R.id.loan20);
                RadioButton twentyFive = (RadioButton) findViewById(R.id.loan30);
                CheckBox taxes = (CheckBox) findViewById(R.id.taxes);

                if(checkZero(borrowed))
                {
                    double amount = Double.parseDouble(borrowed.getText().toString());

                    if (fifteen.isChecked() == true)
                        term = Integer.parseInt(fifteen.getText().toString());
                    else if (twenty.isChecked() == true)
                        term = Integer.parseInt(twenty.getText().toString());
                    else if (twentyFive.isChecked() == true)
                        term = Integer.parseInt(twentyFive.getText().toString());

                    if(interest.getProgress() > 0)
                    {
                        if (taxes.isChecked() == true)
                            mPayment.setText(String.valueOf(MonthlyPayment.calcInterestWithTax(amount,interest.getProgress(), term, 0.1)));
                        else
                            mPayment.setText(String.valueOf(MonthlyPayment.calcInterestWithTax(amount,interest.getProgress(), term, 0.0)));
                    }
                    else
                    {
                        if (taxes.isChecked() == true)
                            mPayment.setText(String.valueOf(MonthlyPayment.calcNoInterest(amount, term, 0.1)));
                        else
                            mPayment.setText(String.valueOf(MonthlyPayment.calcNoInterest(amount, term, 0.0)));
                    }
                }
        }
    }
    public boolean checkZero(EditText text)
    {
        if(text.getText().length() != 0)
        {
            float inputValue = Float.parseFloat(text.getText().toString());

            if (inputValue <= 0)
            {
                Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_LONG).show();
                return false;
            } else
                return true;
        }
        else
        {
            Toast.makeText(this, "Please enter a valid number.", Toast.LENGTH_LONG).show();
            return false;
        }
    }
}

