package android.csulb.edu.displayjoke;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class DisplayJokeActivity extends AppCompatActivity {
    public static String JOKE_START_KEY = "jokeStart";
    public static String JOKE_END_KEY = "jokeEnd";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_joke);
        TextView mStartJokeView = findViewById(R.id.joke_start_view);
        TextView mEndJokeView = findViewById(R.id.joke_punchline_view);

        Intent jokeIntent = getIntent();

        if(jokeIntent != null){
            String joke = jokeIntent.getStringExtra(DisplayJokeActivity.JOKE_START_KEY);
            mStartJokeView.setText(joke);
            /*String jokeStart = jokeIntent.getStringExtra(DisplayJokeActivity.JOKE_START_KEY);
            String jokeEnd = jokeIntent.getStringExtra(DisplayJokeActivity.JOKE_END_KEY);
            mStartJokeView.setText(jokeStart);
            mEndJokeView.setText(jokeEnd);*/
        }
    }
}
