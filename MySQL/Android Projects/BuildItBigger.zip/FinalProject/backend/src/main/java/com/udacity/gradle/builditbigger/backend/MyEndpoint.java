package com.udacity.gradle.builditbigger.backend;

import android.csulb.edu.jokeprovider.JokeFinder;
import android.csulb.edu.jokeprovider.POJO.Joke;

import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiNamespace;

import java.util.ArrayList;

/** An endpoint class we are exposing */
@Api(
        name = "myApi",
        version = "v1",
        namespace = @ApiNamespace(
                ownerDomain = "backend.builditbigger.gradle.udacity.com",
                ownerName = "backend.builditbigger.gradle.udacity.com",
                packagePath = ""
        )
)
public class MyEndpoint {

    @ApiMethod(name = "getJoke")
    public MyBean getJoke() {
        ArrayList<Joke> jokeList;
        JokeFinder jokeFinder = new JokeFinder();
        int randomJoke;

        jokeList = jokeFinder.getJokes();
        randomJoke = (int) (Math.random() * ((jokeList.size()) - 0)) + 0;

        MyBean response = new MyBean();
        response.setData("Joke:, " + jokeList.get(randomJoke).getTitle() + '\n' + jokeList.get(randomJoke).getBody());

        return response;
    }
}
