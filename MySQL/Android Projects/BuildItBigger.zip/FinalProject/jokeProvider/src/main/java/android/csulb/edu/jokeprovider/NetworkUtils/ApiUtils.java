package android.csulb.edu.jokeprovider.NetworkUtils;

public class ApiUtils {
    public static final String BASE_URL = "https://raw.githubusercontent.com/";

    public static JokeService getJokeService() {
        return RetrofitClient.getClient(BASE_URL).create(JokeService.class);
    }
}
