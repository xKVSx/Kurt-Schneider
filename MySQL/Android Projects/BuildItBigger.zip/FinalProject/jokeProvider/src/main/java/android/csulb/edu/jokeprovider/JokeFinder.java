package android.csulb.edu.jokeprovider;

import android.csulb.edu.jokeprovider.POJO.Joke;

import java.util.ArrayList;

public class JokeFinder {
    String[] jokeStart = {"Why did the chicken cross the road?", "A ghost walks into a bar", "What is the craziest type of bread?",
                            "Why don't object oriented programmers use foul language?"};

    String[] jokeEnd = {"To get to the other side.", "The bartender says we don't serve spirits here", "Banana nut bread", "They are classier than that"};

    public ArrayList<Joke> getJokes(){
        ArrayList<Joke> jokeList = new ArrayList<>();

        for(int i = 0; i < jokeStart.length; i++){
            Joke joke = new Joke();
            joke.setTitle(jokeStart[i]);
            joke.setBody(jokeEnd[i]);
            jokeList.add(joke);
        }

        return jokeList;
    }
}
