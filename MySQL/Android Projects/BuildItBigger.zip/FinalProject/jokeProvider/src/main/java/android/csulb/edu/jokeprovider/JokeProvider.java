package android.csulb.edu.jokeprovider;

import android.csulb.edu.jokeprovider.NetworkUtils.ApiUtils;
import android.csulb.edu.jokeprovider.NetworkUtils.JokeService;
import android.csulb.edu.jokeprovider.POJO.Joke;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class JokeProvider {
    private JokeService mJokeService;
    private ArrayList<Joke> mJokeList = new ArrayList<>();

    public JokeProvider(){
        mJokeService = ApiUtils.getJokeService();
    }

    public ArrayList<Joke> getJokeList(){
        return mJokeList;
    }

    public void loadJokes(){
        mJokeService.getJokes().enqueue(new Callback<ArrayList<Joke>>() {
            @Override
            public void onResponse(Call<ArrayList<Joke>> call, Response<ArrayList<Joke>> response) {

                for(int i = 0; i < response.body().size(); i++){
                    Joke joke = response.body().get(i);
                    mJokeList.add(joke);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Joke>> call, Throwable t) {
                System.out.println("JokeProvider.class" + t.getCause().getMessage());
            }
        });
    }
}
