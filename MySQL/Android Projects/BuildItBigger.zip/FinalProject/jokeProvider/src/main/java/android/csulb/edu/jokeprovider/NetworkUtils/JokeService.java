package android.csulb.edu.jokeprovider.NetworkUtils;

import android.csulb.edu.jokeprovider.POJO.Joke;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;

public interface JokeService {

    @GET("/taivop/joke-dataset/master/reddit_jokes.json")
    Call<ArrayList<Joke>> getJokes();
}
