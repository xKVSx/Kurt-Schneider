package com.udacity.gradle.builditbigger;

import android.content.Intent;
import android.csulb.edu.displayjoke.DisplayJokeActivity;
import android.csulb.edu.jokeprovider.JokeProvider;
import android.csulb.edu.jokeprovider.POJO.Joke;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.util.ArrayList;

/*This was the old Main Activity. This uses the jokeProvider API and the JokeProvider class.
The JokeProvider class uses Retro2 to pull jokes from a joke dataset found on Reddit. However,
because Retrofit2 is coupled directly to OkHttp, it is not compatible with GAE
 */
public class GetJokeActivity extends AppCompatActivity {

    private ArrayList<Joke> jokeList = new ArrayList<>();
    private JokeProvider jokeProvider = new JokeProvider();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        jokeProvider.loadJokes();
        jokeList = jokeProvider.getJokeList();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void tellJoke(View view) {
        int min = 0;
        int max;
        int randomJoke = 0;
        String jokeStart = new String();
        String jokeFinish = new String();

        if(jokeList.size() > 0) {
            max = jokeList.size() - 1;
            randomJoke = (int) (Math.random() * (max - min)) + min;
            Joke joke = jokeList.get(randomJoke);
            jokeStart = joke.getTitle();
            jokeFinish = joke.getBody();

            Intent intent = new Intent(this, DisplayJokeActivity.class);
            intent.putExtra(DisplayJokeActivity.JOKE_START_KEY, jokeStart);
            intent.putExtra(DisplayJokeActivity.JOKE_END_KEY, jokeFinish);
            startActivity(intent);

            //Toast.makeText(this, jokeStart + "\n" + jokeFinish, Toast.LENGTH_LONG).show();
        }
    }
}

