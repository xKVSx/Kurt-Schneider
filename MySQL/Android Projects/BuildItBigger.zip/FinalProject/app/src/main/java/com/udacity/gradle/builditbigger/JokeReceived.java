package com.udacity.gradle.builditbigger;

public interface JokeReceived {
    void onJokeReceived(String joke);
}
