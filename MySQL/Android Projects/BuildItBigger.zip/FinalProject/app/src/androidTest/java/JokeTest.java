package com.udacity.gradle.builditbigger;


import android.support.test.runner.AndroidJUnit4;
import android.util.Log;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;

@RunWith(AndroidJUnit4.class)
public class JokeTest {
    MainActivity.EndpointsAsyncTask endpointsAsyncTask;
    CountDownLatch signal;
    String mJoke;

    @Test
    public void testNullJoke() {
        try {
            signal = new CountDownLatch(1);
            endpointsAsyncTask = new MainActivity.EndpointsAsyncTask();
            endpointsAsyncTask.execute(new JokeReceived() {
                @Override
                public void onJokeReceived(String joke) {
                    mJoke = joke;
                    signal.countDown();
                }
            });

            signal.await(30, TimeUnit.SECONDS);
            assertNotNull("The joke is null", mJoke);
        } catch (Exception ex) {
            Log.e("JokeTest", ex.getMessage());
            fail();
        }
    }
}
