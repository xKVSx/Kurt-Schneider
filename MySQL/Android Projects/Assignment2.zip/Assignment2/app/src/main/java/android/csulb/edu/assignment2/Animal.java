package android.csulb.edu.assignment2;

public class Animal
{
    private String name;
    private Integer key;

    public Animal (Integer key, String name)
    {
        this.name = name;
        this.key = key;
    }

    public void setAnimal (Integer key, String name)
    {
        this.name = name;
        this.key = key;
    }

    public void setName (String name)
    {
        this.name = name;
    }

    public void setKey (Integer key)
    {
        this.key = key;
    }

    public String getName()
    {
      return name;
    }

    public Integer getKey()
    {
        return key;
    }
}
