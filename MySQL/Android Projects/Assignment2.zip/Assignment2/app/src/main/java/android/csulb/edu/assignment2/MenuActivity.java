package android.csulb.edu.assignment2;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

public class MenuActivity extends AppCompatActivity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.uninstall:
                Uri packageURI = Uri.parse("package:" + MenuActivity.class.getPackage().getName());
                Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI);
                startActivity(uninstallIntent);
                return true;
            case R.id.information:
                Intent zooInfo = new Intent(MenuActivity.this, ZooInformationActivity.class);
                startActivity(zooInfo);
                return true;
            case R.id.phone:
                String number = "8888888";
                Intent dial = new Intent(Intent.ACTION_CALL);
                dial.setData(Uri.parse("tel:" + number));
                int permissionCheck = ContextCompat.checkSelfPermission(MenuActivity.this, Manifest.permission.CALL_PHONE);
                if (permissionCheck != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(MenuActivity.this,
                            new String[]{Manifest.permission.CALL_PHONE},
                            0);
                }
                else if (permissionCheck == PackageManager.PERMISSION_GRANTED)
                    startActivity(dial);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
