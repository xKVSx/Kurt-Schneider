package android.csulb.edu.assignment2;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Intent;
import android.support.v4.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

public class ScaryDialogFragment extends DialogFragment
{
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setMessage(R.string.scary).setPositiveButton(R.string.enter, new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                //User chose to enter.
                Intent intent = new Intent(ScaryDialogFragment.this.getActivity(), AnimalDetailActivity.class);
                intent.putExtra(AnimalListing.EXTRA_MESSAGE, getString(R.string.honeyb));

                startActivity(intent);

            }
        }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                //User was too scared.

            }
        });

        return builder.create();
    }
}
