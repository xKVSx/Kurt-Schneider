package android.csulb.edu.assignment2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;
import java.util.ArrayList;
import java.util.List;

public class AnimalListing extends MenuActivity
{
    List<Animal> animalList = new ArrayList<Animal>();
    public final static String EXTRA_MESSAGE = "edu.csulb.assignment2.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_listing);
        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);
        initList();
        ListView listView = (ListView) findViewById(R.id.animalList);
        listView.setAdapter(new CustomerAdapter(this, R.layout.custom_row, animalList));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parentAdapter, View view, int position, long id) {
                if (position == 4)
                {
                    ScaryDialogFragment fragment = new ScaryDialogFragment();
                    fragment.show(getSupportFragmentManager(), "question");
                }
                else
                {
                    Intent intent = new Intent(AnimalListing.this, AnimalDetailActivity.class);
                    TextView textView = (TextView) view.findViewById(R.id.rowText);
                    intent.putExtra(EXTRA_MESSAGE, textView.getText());

                    startActivity(intent);
                }
            }
        });
    }

    private Animal createAnimal (Integer key, String name)
    {
        Animal animal = new Animal(key, name);

        return animal;
    }

    private void initList()
    {
        animalList.add(createAnimal(R.drawable.wolf, "Wolf"));
        animalList.add(createAnimal(R.drawable.bear, "Bear"));
        animalList.add(createAnimal(R.drawable.crocodile, "Crocodile"));
        animalList.add(createAnimal(R.drawable.lion, "Lion"));
        animalList.add(createAnimal(R.drawable.honeybadger, "Honey Badger"));
    }
}
