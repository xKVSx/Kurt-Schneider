package android.csulb.edu.assignment2;

import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.TextView;

public class AnimalDetailActivity extends MenuActivity
{
    String animalName;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(toolbar);

        Bundle myInput = this.getIntent().getExtras();

        TextView name = (TextView) findViewById(R.id.textName);
        name.setText(myInput.getString(AnimalListing.EXTRA_MESSAGE));

        ImageView imageView = (ImageView) findViewById(R.id.imageView2);

        TextView description = (TextView) findViewById(R.id.descriptView);

        animalName = name.getText().toString();

        if (animalName.equals(getString(R.string.wolf)))
        {
            imageView.setImageResource(R.drawable.wolflrg);
            description.setText(getString(R.string.wolfd));
        }
        else if (animalName.equals(getString(R.string.bear)))
        {
            imageView.setImageResource(R.drawable.bearlrg);
            description.setText(getString(R.string.beard));
        }
        else if (animalName.equals(getString(R.string.croc)))
        {
            imageView.setImageResource(R.drawable.crocodilelrg);
            description.setText(getString(R.string.crocd));
        }
        else if (animalName.equals(getString(R.string.honeyb)))
        {
            imageView.setImageResource(R.drawable.honeybadgerlrg);
            description.setText(getString(R.string.honeyd));
        }
        else if (animalName.equals(getString(R.string.lion)))
        {
            imageView.setImageResource(R.drawable.lionlrg);
            description.setText(getString(R.string.liond));
        }
    }
}
