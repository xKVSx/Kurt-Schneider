package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    private static final String NAME = "name";
    private static final String MAIN_NAME = "mainName";
    private static final String ALSO_KNOWN_AS = "alsoKnownAs";
    private static final String PLACE_OF_ORIGIN = "placeOfOrigin";
    private static final String DESCRIPTION = "description";
    private static final String IMAGE = "image";
    private static final String INGREDIENTS = "ingredients";

    public static Sandwich parseSandwichJson(String json) throws JSONException{

        Sandwich sandwich = new Sandwich();
        JSONObject sandwich_details = new JSONObject(json);

        //get the main name
        JSONObject name = sandwich_details.getJSONObject(NAME);
        String mainName = name.getString(MAIN_NAME);
        sandwich.setMainName(mainName);

        //get AKA
        JSONArray aka = name.getJSONArray(ALSO_KNOWN_AS);
        List<String> akaList = new ArrayList<>();
        for(int i = 0; i < aka.length(); i++) {
            akaList.add(aka.getString(i));
        }

        sandwich.setAlsoKnownAs(akaList);

        //get place of origin
        String placeOfOrigin = sandwich_details.getString(PLACE_OF_ORIGIN);
        sandwich.setPlaceOfOrigin(placeOfOrigin);

        //get description
        String description = sandwich_details.getString(DESCRIPTION);
        sandwich.setDescription(description);

        //get image
        String image = sandwich_details.getString(IMAGE);
        sandwich.setImage(image);

        //get ingredients
        JSONArray ingredients = sandwich_details.getJSONArray(INGREDIENTS);
        List<String> ingredientsList = new ArrayList<>();
        for(int i = 0; i < ingredients.length(); i++)
            ingredientsList.add(ingredients.getString(i));

        sandwich.setIngredients(ingredientsList);


        return sandwich;



    }

}
