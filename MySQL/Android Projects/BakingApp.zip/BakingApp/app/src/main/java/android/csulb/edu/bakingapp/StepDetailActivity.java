package android.csulb.edu.bakingapp;

import android.content.Intent;
import android.csulb.edu.bakingapp.POJO.Step;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import java.util.ArrayList;

public class StepDetailActivity extends AppCompatActivity {
    public static final String STEP_LIST = "step_list";
    public static final String STEP_INDEX = "step_index";
    public static final String STEP = "step";
    FragmentManager mFragmentManager;
    ArrayList<Step> mStepList;
    Step mStep;
    int mCickedItemIndex;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.step_main);

        Intent intent = getIntent();
        if (intent == null) {
            closeOnError();
        }

        if(mStepList == null)
            mStepList = intent.getParcelableArrayListExtra(STEP_LIST);
        mCickedItemIndex = intent.getIntExtra(STEP_INDEX, -1);

        if(mCickedItemIndex >=0) {
            mStep = mStepList.get(mCickedItemIndex);
        }
        else
            closeOnError();

        if(savedInstanceState == null) {
            Bundle stepBundle = new Bundle();
            stepBundle.putParcelableArrayList(STEP_LIST, mStepList);
            stepBundle.putInt(STEP_INDEX, mCickedItemIndex);
            mFragmentManager = getSupportFragmentManager();
            StepDetailFragment stepDetailFragment = new StepDetailFragment();
            stepDetailFragment.setArguments(stepBundle);
            mFragmentManager.beginTransaction().replace(R.id.step_detail_fragment, stepDetailFragment).commit();
        }
    }

    private void closeOnError() {
        finish();
        Toast.makeText(this, R.string.step_detail_error_message, Toast.LENGTH_SHORT).show();
    }
}
