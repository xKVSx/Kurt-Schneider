package android.csulb.edu.bakingapp.Adapters;

import android.content.Context;
import android.csulb.edu.bakingapp.R;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.RecipeViewHolder> {
    private Context mContext;
    private ArrayList<String> mRecipeName;
    final private ListItemClickListener mOnClickListener;

    public RecipeAdapter(Context context, ListItemClickListener listener){
        mContext = context;
        mOnClickListener = listener;
    }

    @Override
    public RecipeAdapter.RecipeViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View recipeView = inflater.inflate(R.layout.recipe_layout, parent, false);
        RecipeViewHolder viewHolder = new RecipeViewHolder(recipeView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecipeAdapter.RecipeViewHolder holder, int position) {
        TextView name = holder.recipeName;
        ImageView image = holder.recipeImage;

        name.setText(mRecipeName.get(position));
    }

    @Override
    public int getItemCount() {
        if(mRecipeName != null)
            return mRecipeName.size();
        else
            return 0;
    }

    public void setRecipeList(ArrayList<String> recipeList) {
        mRecipeName = recipeList;
        notifyDataSetChanged();
    }

    public interface ListItemClickListener{
        void onListItemClick(int clickedItemIndex);
    }

    public class RecipeViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        public final TextView recipeName;
        public final ImageView recipeImage;

        public RecipeViewHolder(View itemView){
            super(itemView);
            recipeName = itemView.findViewById(R.id.recipe_name);
            recipeImage = itemView.findViewById(R.id.recipe_image);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int clickedPosition = getAdapterPosition();
            mOnClickListener.onListItemClick(clickedPosition);
        }
    }
}

