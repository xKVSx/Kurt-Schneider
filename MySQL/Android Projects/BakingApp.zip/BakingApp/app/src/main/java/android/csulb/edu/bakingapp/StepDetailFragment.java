package android.csulb.edu.bakingapp;

import android.csulb.edu.bakingapp.POJO.Step;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.exoplayer2.C;
import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.ExoPlayerFactory;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory;
import com.google.android.exoplayer2.source.ExtractorMediaSource;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.trackselection.TrackSelector;
import com.google.android.exoplayer2.ui.SimpleExoPlayerView;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.google.android.exoplayer2.util.Util;

import java.util.ArrayList;

public class StepDetailFragment extends Fragment {
    private ArrayList<Step> mStepList;
    private Step mStep;
    private SimpleExoPlayer mExoPlayer;
    private SimpleExoPlayerView mPlayerView;
    private int mStepIndexClicked;
    private String videoUrl;
    private String description;

    private int mCurrentWindow = 0;
    private long mPlaybackPosition = C.TIME_UNSET;
    private boolean mPlayWhenReady = true;
    private final static String CURRENT_WINDOW = "current_window";
    private final static String PLAYBACK_POSITION = "playback_position";
    private final static String PLAY_WHEN_READY = "play_when_ready";
    private final static String STEP_LIST = "step_list";
    private final static String INDEX_CLICKED = "index";

    public StepDetailFragment(){
        super();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_step_detail_layout, container, false);

        final TextView stepDescriptionView = rootView.findViewById(R.id.step_detail_description_view);
        final TextView pageView = rootView.findViewById(R.id.page_number_view);
        final Button nextStep = rootView.findViewById(R.id.next_step_button);
        final Button previousStep = rootView.findViewById(R.id.previous_step_button);

        mPlayerView = rootView.findViewById(R.id.exoplayer_step_video);

        if(savedInstanceState != null) {
            mPlaybackPosition = savedInstanceState.getLong(PLAYBACK_POSITION);
            mCurrentWindow = savedInstanceState.getInt(CURRENT_WINDOW);
            mPlayWhenReady = savedInstanceState.getBoolean(PLAY_WHEN_READY);
            mStepList = savedInstanceState.getParcelableArrayList(STEP_LIST);
            mStepIndexClicked = savedInstanceState.getInt(INDEX_CLICKED);
        }
        else{
            if (getArguments() != null) {
                mStepList = getArguments().getParcelableArrayList(StepDetailActivity.STEP_LIST);
                mStepIndexClicked = getArguments().getInt(StepDetailActivity.STEP_INDEX);
            }
        }

        mStep = mStepList.get(mStepIndexClicked);
        description = mStep.getDescription();
        videoUrl = mStep.getVideoURL();

        stepDescriptionView.setText(description);
        pageView.setText(Integer.toString(mStepIndexClicked));
        setButtonVisibility(nextStep, previousStep);
        initializePlayer(Uri.parse(videoUrl));

        nextStep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mStepIndexClicked < mStepList.size() - 1) {
                    mStepIndexClicked = mStepIndexClicked + 1;
                    mStep = mStepList.get(mStepIndexClicked);
                    String description = mStep.getDescription();
                    videoUrl = mStep.getVideoURL();
                    setButtonVisibility(nextStep, previousStep);
                    stepDescriptionView.setText(description);
                    pageView.setText(Integer.toString(mStepIndexClicked));
                    newMediaSource(Uri.parse(videoUrl));
                }
            }
        });

        previousStep.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mStepIndexClicked > 0){
                    mStepIndexClicked = mStepIndexClicked - 1;
                    mStep = mStepList.get(mStepIndexClicked);
                    String description = mStep.getDescription();
                    String videoUrl = mStep.getVideoURL();
                    setButtonVisibility(nextStep, previousStep);
                    stepDescriptionView.setText(description);
                    pageView.setText(Integer.toString(mStepIndexClicked));
                    newMediaSource(Uri.parse(videoUrl));
                }
            }
        });

        return rootView;
    }

    public void setButtonVisibility(Button next, Button previous){
        if(mStepIndexClicked == mStepList.size() - 1)
            next.setVisibility(View.INVISIBLE);
        else
            next.setVisibility(View.VISIBLE);

        if(mStepIndexClicked == 0)
            previous.setVisibility(View.INVISIBLE);
        else
            previous.setVisibility(View.VISIBLE);
    }

    private void initializePlayer(Uri mediaUri) {
        if (mExoPlayer == null) {
            // Create an instance of the ExoPlayer.
            Log.d("onSaveInstanceState", "msg: " + mediaUri);
            TrackSelector trackSelector = new DefaultTrackSelector();
            LoadControl loadControl = new DefaultLoadControl();
            mExoPlayer = ExoPlayerFactory.newSimpleInstance(getActivity(), trackSelector, loadControl);
            mPlayerView.setPlayer(mExoPlayer);
            mExoPlayer.setPlayWhenReady(mPlayWhenReady);
            boolean haveResumePosition = mPlaybackPosition != C.INDEX_UNSET;
            if((mPlaybackPosition != C.TIME_UNSET) && (haveResumePosition))
                mExoPlayer.seekTo(mCurrentWindow, mPlaybackPosition);
            // Prepare the MediaSource.
            String userAgent = Util.getUserAgent(getActivity(), "recipeVideo");
            MediaSource mediaSource = new ExtractorMediaSource(mediaUri, new DefaultDataSourceFactory(getActivity(), userAgent), new DefaultExtractorsFactory(), null, null);
            mExoPlayer.prepare(mediaSource, !haveResumePosition, false);
        }
    }

    private void newMediaSource(Uri mediaUri){
        mExoPlayer.stop();
        String userAgent = Util.getUserAgent(getActivity(), "recipeVideo");
        MediaSource mediaSource = new ExtractorMediaSource(mediaUri, new DefaultDataSourceFactory(getActivity(), userAgent), new DefaultExtractorsFactory(), null, null);
        mExoPlayer.prepare(mediaSource);
        mExoPlayer.setPlayWhenReady(true);
    }

    private void releasePlayer() {
        if(mExoPlayer != null) {
            mExoPlayer.stop();
            mExoPlayer.release();
            mExoPlayer = null;
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        mPlaybackPosition = mExoPlayer.getCurrentPosition();
        mCurrentWindow = mExoPlayer.getCurrentWindowIndex();
        mPlayWhenReady = mExoPlayer.getPlayWhenReady();

        outState.putLong(PLAYBACK_POSITION, mPlaybackPosition);
        outState.putInt(CURRENT_WINDOW, mCurrentWindow);
        outState.putBoolean(PLAY_WHEN_READY, mPlayWhenReady);
        outState.putParcelableArrayList(STEP_LIST, mStepList);
        outState.putInt(INDEX_CLICKED, mStepIndexClicked);

        releasePlayer();
    }
}
