package android.csulb.edu.bakingapp;

import android.content.Intent;
import android.csulb.edu.bakingapp.POJO.Recipe;
import android.csulb.edu.bakingapp.POJO.Step;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import java.util.ArrayList;

public class RecipeDetailActivity extends AppCompatActivity {
    public static final String RECIPE = "recipe_list";
    public static final String STEP_LIST = "step_list";
    public static final String STEP_INDEX = "step_index";
    public static final String STEP = "step";
    public static final String TWO_PANE = "two_pane";

    FragmentManager mFragmentManager;
    Recipe mRecipe;
    private boolean mTwoPane = false;
    ArrayList<Step> mStepList;
    Step mStep;
    int mCickedItemIndex = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recipe_main);

        Intent intent = getIntent();
        if (intent == null) {
            closeOnError();
        }

        mRecipe = intent.getParcelableExtra(RECIPE);

        if(findViewById(R.id.step_detail_fragment) != null){
            mTwoPane = true;
            mStepList = mRecipe.getSteps();
            mStep = mStepList.get(mCickedItemIndex);
            Bundle stepBundle = new Bundle();
            stepBundle.putParcelableArrayList(STEP_LIST, mStepList);
            stepBundle.putInt(STEP_INDEX, mCickedItemIndex);
            mFragmentManager = getSupportFragmentManager();
            StepDetailFragment stepDetailFragment = new StepDetailFragment();
            stepDetailFragment.setArguments(stepBundle);
            mFragmentManager.beginTransaction().replace(R.id.step_detail_fragment, stepDetailFragment).commit();
        }

        Bundle recipeBundle = new Bundle();
        recipeBundle.putParcelable(RECIPE, mRecipe);
        recipeBundle.putBoolean(TWO_PANE, mTwoPane);

        mFragmentManager = getSupportFragmentManager();
        RecipeDetailFragment recipeDetailFragment = new RecipeDetailFragment();
        recipeDetailFragment.setArguments(recipeBundle);
        mFragmentManager.beginTransaction().replace(R.id.recipe_detail_fragment, recipeDetailFragment).commit();
    }

    private void closeOnError() {
        finish();
        Toast.makeText(this, R.string.step_detail_error_message, Toast.LENGTH_SHORT).show();
    }
}
