package android.csulb.edu.bakingapp.Widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.csulb.edu.bakingapp.R;
import android.widget.RemoteViews;

/**
 * Implementation of App Widget functionality.
 */
public class BakingWidgetProvider extends AppWidgetProvider {
    private  static int mIndex = 0;

    static void updateAppWidget(Context context, AppWidgetManager appWidgetManager, StringBuilder ingredientList,
                                int recipeId, int appWidgetId) {

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.baking_widget_provider);
        views.setTextViewText(R.id.recipe_list_widget, ingredientList);
        mIndex = recipeId + 1;

        Intent ingredientIntent = new Intent(context, BakingWidgetService.class);
        ingredientIntent.setAction(BakingWidgetService.ACTION_INCREMENT_RECIPE);
        ingredientIntent.putExtra(BakingWidgetService.RECIPE_ID, recipeId);
        PendingIntent ingredientPendingIntent = PendingIntent.getService(context,
                0, ingredientIntent, PendingIntent.FLAG_UPDATE_CURRENT);
        views.setOnClickPendingIntent(R.id.widget_bake_image, ingredientPendingIntent);

        // Instruct the widget manager to update the widget*/
        appWidgetManager.updateAppWidget(appWidgetId, views);
    }


    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        BakingWidgetService.startActionUpdateWidget(context, mIndex);
    }

    @Override
    public void onEnabled(Context context) {
        // Enter relevant functionality for when the first widget is created
    }

    @Override
    public void onDisabled(Context context) {
        // Enter relevant functionality for when the last widget is disabled
    }

    public static void updateBakingWidget(Context context, AppWidgetManager appWidgetManager, StringBuilder ingredientList, int recipeId, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateAppWidget(context, appWidgetManager, ingredientList, recipeId, appWidgetId);
        }
    }
}

