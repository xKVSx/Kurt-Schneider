package android.csulb.edu.bakingapp.Widget;

import android.app.IntentService;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.csulb.edu.bakingapp.POJO.Ingredient;
import android.csulb.edu.bakingapp.POJO.Recipe;
import android.support.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;

public class BakingWidgetService extends IntentService {
    public static final String ACTION_INCREMENT_RECIPE = "android.csulb.edu.bakingapp.Widget.action.increment_recipe";
    public static final String RECIPE_ID = "recipe_id";
    //private int mCounter = 0;
    private ArrayList<Recipe> mRecipeList = new ArrayList<>();
    public static String[] mNutellaPie = {"Recipe Introduction", "Starting prep", "Prep the cookie crust"};

    public BakingWidgetService() {
        super("BakingWidgetService");

    }

    public static void startActionUpdateWidget(Context context, int recipeId) {
        Intent intent = new Intent(context, BakingWidgetService.class);
        intent.setAction(ACTION_INCREMENT_RECIPE);
        intent.putExtra(RECIPE_ID, recipeId);
        context.startService(intent);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        if (intent != null) {
            final String action = intent.getAction();
            if (ACTION_INCREMENT_RECIPE.equals(action)) {
                int recipeId = intent.getIntExtra(RECIPE_ID, 0);
                handleActionIncrementRecipe(recipeId);
            }
        }
    }

    private void handleActionIncrementRecipe(int recipeId) {
        StringBuilder ingredientList;
        mRecipeList = getSharedPreference();
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(this);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(new ComponentName(this, BakingWidgetProvider.class));

        if(recipeId < getSavedRecipeSize()) {
            ingredientList = getRecipeSteps(recipeId++);
        }
        else {
            recipeId = 0;
            ingredientList = getRecipeSteps(recipeId++);
        }

        BakingWidgetProvider.updateBakingWidget(this, appWidgetManager, ingredientList, recipeId, appWidgetIds);
    }

    private ArrayList<Recipe> getSharedPreference(){
        SharedPreferences mPrefs = getApplicationContext().getSharedPreferences("RecipeList", MODE_PRIVATE);

        Gson gson = new Gson();
        String json = mPrefs.getString("Recipes", "");
        ArrayList<Recipe> recipes = gson.fromJson(json, new TypeToken<ArrayList<Recipe>>(){}.getType());

        return recipes;
    }

    public StringBuilder getRecipeSteps(int index){
        StringBuilder stringBuilder = new StringBuilder();
        ArrayList<Ingredient> ingredientList = mRecipeList.get(index).getIngredients();
        String ingredient = new String();

        for(Ingredient  i: ingredientList){
            ingredient = i.getIngredient();
            stringBuilder.append(ingredient);
            stringBuilder.append("\n");
        }

        return stringBuilder;
    }

    public int getSavedRecipeSize(){

        return mRecipeList.size();
    }


}
