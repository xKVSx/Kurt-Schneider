package android.csulb.edu.bakingapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.csulb.edu.bakingapp.Adapters.RecipeAdapter;
import android.csulb.edu.bakingapp.NetworkUtils.ApiUtils;
import android.csulb.edu.bakingapp.NetworkUtils.RecipeService;
import android.csulb.edu.bakingapp.POJO.Recipe;
import android.csulb.edu.bakingapp.Widget.BakingWidgetProvider;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.util.Log;

import com.google.gson.Gson;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements RecipeAdapter.ListItemClickListener {
    private RecipeService mRecipeService;
    private RecyclerView mRecipeRecyclerView;
    private RecipeAdapter mRecipeAdapter;
    private static ArrayList<Recipe> mRecipes;
    private ArrayList<String> mRecipeNames = new ArrayList<>();
    private static ArrayList<Recipe> mSavedRecipes;
    private boolean mTwoPane; //used to determine tablet from phone


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecipeAdapter = new RecipeAdapter(this,this);
        mRecipeRecyclerView = findViewById(R.id.recipe_recycler_view);

        if(findViewById(R.id.tablet_view) != null)
            mTwoPane = true;
        else
            mTwoPane = false;

        if(mTwoPane) {
            GridLayoutManager gridLayoutManager = new GridLayoutManager(this, numberOfColumns(), GridLayoutManager.VERTICAL, false);
            mRecipeRecyclerView.setLayoutManager(gridLayoutManager);
        }
        else{
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
            mRecipeRecyclerView.setLayoutManager(layoutManager);
        }

        mRecipeRecyclerView.setHasFixedSize(true);
        mRecipeRecyclerView.setAdapter(mRecipeAdapter);

        mRecipeService = ApiUtils.getRecipeService();

        loadRecipes();
    }

    public void loadRecipes(){
        mRecipeService.getRecipes().enqueue(new Callback<ArrayList<Recipe>>() {
            @Override
            public void onResponse(Call<ArrayList<Recipe>> call, Response<ArrayList<Recipe>> response) {
                mRecipes = response.body();
                String name;

                for(int i = 0; i < mRecipes.size(); i++){
                    name = mRecipes.get(i).getName();

                    if(name != null)
                        mRecipeNames.add(name);
                }

                mRecipeAdapter.setRecipeList(mRecipeNames);
            }

            @Override
            public void onFailure(Call<ArrayList<Recipe>> call, Throwable t) {
                Log.d("MainActivity.class", t.getCause().getMessage());
            }
        });
    }

    private int numberOfColumns(){
        //method to dynamically calculate the number of columns for screen size and orientation
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int widthDivider = 800;
        int width = displayMetrics.widthPixels;
        int nColumns = width / widthDivider;
        if(nColumns < 2)
            return 2;

        return nColumns;
    }

    private static ArrayList<Recipe> getRecipes(){

        return mRecipes;
    }

    @Override
    public void onListItemClick(int clickedItemIndex) {
        Intent widgetIntent = new Intent(this, BakingWidgetProvider.class);

        Intent intent = new Intent(this, RecipeDetailActivity.class);
        Recipe recipe = getRecipes().get(clickedItemIndex);
        intent.putExtra(RecipeDetailActivity.RECIPE, recipe);
        widgetIntent.putExtra(RecipeDetailActivity.RECIPE, recipe);
        startActivity(intent);
    }

    private void setSharedPreference(){
        SharedPreferences mPrefs = getSharedPreferences("RecipeList", MODE_PRIVATE);
        SharedPreferences.Editor prefsEditor = mPrefs.edit();

        Gson gson = new Gson();
        String json = gson.toJson(getRecipes());

        prefsEditor.putString("Recipes", json);
        prefsEditor.commit();
    }

    @Override
    protected void onPause() {
        super.onPause();
        setSharedPreference();
    }
}
