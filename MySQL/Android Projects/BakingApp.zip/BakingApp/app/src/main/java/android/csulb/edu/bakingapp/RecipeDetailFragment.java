package android.csulb.edu.bakingapp;

import android.content.Context;
import android.content.Intent;
import android.csulb.edu.bakingapp.Adapters.IngredientAdapter;
import android.csulb.edu.bakingapp.Adapters.RecipeDetailAdapter;
import android.csulb.edu.bakingapp.POJO.Recipe;
import android.csulb.edu.bakingapp.POJO.Step;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class RecipeDetailFragment extends Fragment implements RecipeDetailAdapter.ListItemClickListener {
    public static final String RECIPE = "recipe_list";
    public static final String STEP_LIST = "step_list";
    public static final String STEP_INDEX = "step_index";
    public static final String STEP = "step";
    public static final String TWO_PANE = "two_pane";
    Recipe recipe;
    Boolean mTwoPane;
    ArrayList<Step> recipeSteps;
    ArrayList<String> stepDescriptions = new ArrayList<>();

    public RecipeDetailFragment(){
        super();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_master_recipe_detail_list, container, false);

        RecyclerView mRecipeDetailRecyclerView = rootView.findViewById(R.id.step_description_recycler_view);
        RecipeDetailAdapter mRecipeDetailAdapter = new RecipeDetailAdapter(getActivity(),RecipeDetailFragment.this);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        mRecipeDetailRecyclerView.setLayoutManager(layoutManager);
        mRecipeDetailRecyclerView.setHasFixedSize(true);
        mRecipeDetailRecyclerView.setAdapter(mRecipeDetailAdapter);

        RecyclerView mIngredientRecyclerView = rootView.findViewById(R.id.ingredients_recycler_view);
        IngredientAdapter mIngredientAdapter = new IngredientAdapter(getActivity());
        RecyclerView.LayoutManager hLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        mIngredientRecyclerView.setLayoutManager(hLayoutManager);
        mIngredientRecyclerView.setHasFixedSize(true);
        mIngredientRecyclerView.setAdapter(mIngredientAdapter);

        if(getArguments() != null){
            recipe = getArguments().getParcelable(RecipeDetailActivity.RECIPE);
            recipeSteps = recipe.getSteps();
            mTwoPane = getArguments().getBoolean(RecipeDetailActivity.TWO_PANE);

            for(int i = 0; i < recipeSteps.size(); i++){
                String description = recipeSteps.get(i).getShortDescription();
                Log.d("getArguments", "description: " + description);
                stepDescriptions.add(description);
            }
            mRecipeDetailAdapter.setStepList(stepDescriptions);
            mIngredientAdapter.setIngredientList(recipe.getIngredients());
        }

        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onListItemClick(int clickedItemIndex) {
        if (!mTwoPane) {
            Intent intent = new Intent(getContext(), StepDetailActivity.class);
            intent.putExtra(StepDetailActivity.STEP_LIST, recipeSteps);
            intent.putExtra(StepDetailActivity.STEP_INDEX, clickedItemIndex);
            startActivity(intent);
        }
        else{
            Bundle stepBundle = new Bundle();
            stepBundle.putParcelableArrayList(STEP_LIST, recipeSteps);
            stepBundle.putInt(STEP_INDEX, clickedItemIndex);
            FragmentManager mFragmentManager = getActivity().getSupportFragmentManager();
            StepDetailFragment stepDetailFragment = new StepDetailFragment();
            stepDetailFragment.setArguments(stepBundle);
            mFragmentManager.beginTransaction().replace(R.id.step_detail_fragment, stepDetailFragment).commit();
        }
    }
}
