package android.csulb.edu.bakingapp.Adapters;

import android.content.Context;
import android.csulb.edu.bakingapp.R;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class RecipeDetailAdapter extends RecyclerView.Adapter<RecipeDetailAdapter.RecipeDetailViewHolder> {
    private Context mContext;
    private ArrayList<String> mStepDescription;
    final private RecipeDetailAdapter.ListItemClickListener mOnClickListener;

    public RecipeDetailAdapter(Context context, ListItemClickListener listener){
        mContext = context;
        mOnClickListener = listener;
    }

    @Override
    public RecipeDetailAdapter.RecipeDetailViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View stepView = inflater.inflate(R.layout.step_description_layout, parent, false);
        RecipeDetailViewHolder viewHolder = new RecipeDetailViewHolder(stepView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecipeDetailAdapter.RecipeDetailViewHolder holder, int position) {
        TextView stepDescription = holder.stepDescriptionTextView;

        stepDescription.setText(mStepDescription.get(position));
    }

    @Override
    public int getItemCount() {
        if(mStepDescription != null)
            return mStepDescription.size();
        else
            return 0;
    }

    public class RecipeDetailViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        public final TextView stepDescriptionTextView;

        public RecipeDetailViewHolder(View itemView) {
            super(itemView);
            stepDescriptionTextView = itemView.findViewById(R.id.step_description_text_view);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int clickedPosition = getAdapterPosition();
            mOnClickListener.onListItemClick(clickedPosition);
        }
    }

    public interface ListItemClickListener{
        void onListItemClick(int clickedItemIndex);
    }

    public void setStepList(ArrayList<String> stepList) {
        mStepDescription = stepList;
        notifyDataSetChanged();
    }
}
