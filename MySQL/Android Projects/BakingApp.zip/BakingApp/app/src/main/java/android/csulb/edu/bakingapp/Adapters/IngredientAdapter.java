package android.csulb.edu.bakingapp.Adapters;

import android.content.Context;
import android.csulb.edu.bakingapp.POJO.Ingredient;
import android.csulb.edu.bakingapp.R;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class IngredientAdapter extends RecyclerView.Adapter<IngredientAdapter.IngredientViewHolder> {
    private Context mContext;
    private ArrayList<Ingredient> mIngredients;

    public IngredientAdapter(Context context){
        mContext = context;
    }

    @Override
    public IngredientAdapter.IngredientViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View ingredientView = inflater.inflate(R.layout.ingredients_layout, parent, false);
        IngredientAdapter.IngredientViewHolder viewHolder = new IngredientAdapter.IngredientViewHolder(ingredientView);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(IngredientAdapter.IngredientViewHolder holder, int position) {
        TextView ingredientsTextView = holder.ingredientsTextView;
        TextView quantityMeasureTextView = holder.quantityMeasureTextView;

        Ingredient ingredient = mIngredients.get(position);
        String quantityMeasure;
        quantityMeasure =  Float.toString(ingredient.getQuantity()) + " " + ingredient.getMeasure();

        ingredientsTextView.setText(ingredient.getIngredient());
        quantityMeasureTextView.setText(quantityMeasure);
    }

    @Override
    public int getItemCount() {
        if(mIngredients != null)
            return mIngredients.size();
        else
            return 0;
    }

    public class IngredientViewHolder extends RecyclerView.ViewHolder {
        public final TextView ingredientsTextView;
        public final TextView quantityMeasureTextView;

        public IngredientViewHolder(View itemView) {
            super(itemView);
            ingredientsTextView = itemView.findViewById(R.id.ingredient_text_view);
            quantityMeasureTextView = itemView.findViewById(R.id.quantity_measure_text_view);
        }
    }

    public void setIngredientList(ArrayList<Ingredient> ingredientList){
        mIngredients = ingredientList;
        notifyDataSetChanged();
    }
}
