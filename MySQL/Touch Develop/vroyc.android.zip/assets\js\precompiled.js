﻿var TDev;
if (!TDev) TDev = {};
TDev.precompiledScript = {
"this": (function (cs) {
'use strict';
var libs = cs.libs = {};
var lib = TDev.RT;
var callstackcurdepth = 0;
cs.scriptTitle = "Hero";
cs.scriptColor = "\u00239955bb";
/* ACTION: main */
function a_Apxoi0VesSBXIz9PLx65FHFL(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Apxoi0VesSBXIz9PLx65FHFL$0;
  s.name = "main";
  s.$board = undefined;
  return s;
}
cs.registerAction("main", "Apxoi0VesSBXIz9PLx65FHFL", a_Apxoi0VesSBXIz9PLx65FHFL, true);

function a_Apxoi0VesSBXIz9PLx65FHFL$0(s) {
  (s.pc = "0.60");
  return s.rt.enter(a_o6wz9cw6d0VkhvmxUo2WMKmr(s, a_Apxoi0VesSBXIz9PLx65FHFL$1));
}
cs.registerStep(a_Apxoi0VesSBXIz9PLx65FHFL$0, 'a_Apxoi0VesSBXIz9PLx65FHFL$0');

function a_Apxoi0VesSBXIz9PLx65FHFL$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  t_actRes_0;
  (s.pc = "0.63");
  var t_libcall_1 = s.libs["game"]["start"](s);
  return s.rt.enter(t_libcall_1.invoke(t_libcall_1, a_Apxoi0VesSBXIz9PLx65FHFL$2));
}
cs.registerStep(a_Apxoi0VesSBXIz9PLx65FHFL$1, 'a_Apxoi0VesSBXIz9PLx65FHFL$1');

function a_Apxoi0VesSBXIz9PLx65FHFL$2(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_2);
  (s.pc = "0.66");
  return s.rt.enter(a_TKAAjyn1pMUXqVG0FQSsjeCq(s, a_Apxoi0VesSBXIz9PLx65FHFL$3));
}
cs.registerStep(a_Apxoi0VesSBXIz9PLx65FHFL$2, 'a_Apxoi0VesSBXIz9PLx65FHFL$2');

function a_Apxoi0VesSBXIz9PLx65FHFL$3(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  t_actRes_3;
  return s.rt.leave();
}
cs.registerStep(a_Apxoi0VesSBXIz9PLx65FHFL$3, 'a_Apxoi0VesSBXIz9PLx65FHFL$3');

/* ACTION: menu */
function a_o6wz9cw6d0VkhvmxUo2WMKmr(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_o6wz9cw6d0VkhvmxUo2WMKmr$0;
  s.name = "menu";
  s.$start_level = undefined;
  s.$level = undefined;
  return s;
}
cs.registerAction("menu", "o6wz9cw6d0VkhvmxUo2WMKmr", a_o6wz9cw6d0VkhvmxUo2WMKmr, true);

function ok1(s, a0) {
  return (a0 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_o6wz9cw6d0VkhvmxUo2WMKmr$0(s) {
  (s.pc = "0.j40");
  var t_lmbProxy_0 = s.libs.mkLambdaProxy;
  (s.$start_level = function(la0, la1, la2) { return a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1(t_lmbProxy_0(la0), la1, la2) });
  (s.pc = "0.j0");
  var t_libcall_1 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["initialize"](s);
  return s.rt.enter(t_libcall_1.invoke(t_libcall_1, a_o6wz9cw6d0VkhvmxUo2WMKmr$2, "Hero", "Destroy the aliens and save the Earth.", 2, s.$start_level));
}
cs.registerStep(a_o6wz9cw6d0VkhvmxUo2WMKmr$0, 'a_o6wz9cw6d0VkhvmxUo2WMKmr$0');

function a_o6wz9cw6d0VkhvmxUo2WMKmr$2(s) {
  (s.pc = "0.j4");
  var t_libcall_2 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["page theme"](s);
  return s.rt.enter(t_libcall_2.invoke(t_libcall_2, a_o6wz9cw6d0VkhvmxUo2WMKmr$3));
}
cs.registerStep(a_o6wz9cw6d0VkhvmxUo2WMKmr$2, 'a_o6wz9cw6d0VkhvmxUo2WMKmr$2');

function a_o6wz9cw6d0VkhvmxUo2WMKmr$3(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  var t_call_4 = lib.Colors.white(s);
  var t_libcall_5 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["set foreground"](s);
  return s.rt.enter(t_libcall_5.invoke(t_libcall_5, a_o6wz9cw6d0VkhvmxUo2WMKmr$4, t_actRes_3, t_call_4));
}
cs.registerStep(a_o6wz9cw6d0VkhvmxUo2WMKmr$3, 'a_o6wz9cw6d0VkhvmxUo2WMKmr$3');

function a_o6wz9cw6d0VkhvmxUo2WMKmr$4(s) {
  (s.pc = "0.j7");
  var t_libcall_6 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["page theme"](s);
  return s.rt.enter(t_libcall_6.invoke(t_libcall_6, a_o6wz9cw6d0VkhvmxUo2WMKmr$5));
}
cs.registerStep(a_o6wz9cw6d0VkhvmxUo2WMKmr$4, 'a_o6wz9cw6d0VkhvmxUo2WMKmr$4');

function a_o6wz9cw6d0VkhvmxUo2WMKmr$5(s) {
  var t_actRes_7 = s.rt.returnedFrom.result;
  var t_libcall_8 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["set background picture"](s);
  return s.rt.enter(t_libcall_8.invoke(t_libcall_8, a_o6wz9cw6d0VkhvmxUo2WMKmr$6, t_actRes_7, /* earth */ s.d.$i7v2elsf8ywqFMSgiS4SNI6p));
}
cs.registerStep(a_o6wz9cw6d0VkhvmxUo2WMKmr$5, 'a_o6wz9cw6d0VkhvmxUo2WMKmr$5');

function a_o6wz9cw6d0VkhvmxUo2WMKmr$6(s) {
  (s.pc = "0.ja");
  var t_libcall_9 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["set instructions"](s);
  return s.rt.enter(t_libcall_9.invoke(t_libcall_9, a_o6wz9cw6d0VkhvmxUo2WMKmr$7, "Use the arrow keys to move the hero and the space bar to attack."));
}
cs.registerStep(a_o6wz9cw6d0VkhvmxUo2WMKmr$6, 'a_o6wz9cw6d0VkhvmxUo2WMKmr$6');

function a_o6wz9cw6d0VkhvmxUo2WMKmr$7(s) {
  (s.pc = "0.jd");
  var t_libcall_10 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["level by id"](s);
  return s.rt.enter(t_libcall_10.invoke(t_libcall_10, a_o6wz9cw6d0VkhvmxUo2WMKmr$8, 1));
}
cs.registerStep(a_o6wz9cw6d0VkhvmxUo2WMKmr$7, 'a_o6wz9cw6d0VkhvmxUo2WMKmr$7');

function a_o6wz9cw6d0VkhvmxUo2WMKmr$8(s) {
  var t_actRes_11 = s.rt.returnedFrom.result;
  var t_libcall_12 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["set description"](s);
  return s.rt.enter(t_libcall_12.invoke(t_libcall_12, a_o6wz9cw6d0VkhvmxUo2WMKmr$9, t_actRes_11, "After the failure of the star ship fleet\u002c the only hope left to save Earth was to send its most powerful hero."));
}
cs.registerStep(a_o6wz9cw6d0VkhvmxUo2WMKmr$8, 'a_o6wz9cw6d0VkhvmxUo2WMKmr$8');

function a_o6wz9cw6d0VkhvmxUo2WMKmr$9(s) {
  (s.pc = "0.jg");
  s.rt.forceNonRender();
  s.rt.forcePageRefresh();
  s.rt.postAutoPage("d2bbpYdDq6mcoCpqp1dEtgbi", "start");
  return s.rt.leave();
}
cs.registerStep(a_o6wz9cw6d0VkhvmxUo2WMKmr$9, 'a_o6wz9cw6d0VkhvmxUo2WMKmr$9');

/* ACTION: a_o6wz9cw6d0VkhvmxUo2WMKmr::lambda::1 */
function a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$0;
  s.name = "menu";
  s.$level = $level;
  return s;
}
cs.registerLambda("a_o6wz9cw6d0VkhvmxUo2WMKmr\u003a\u003alambda\u003a\u003a1", "a_o6wz9cw6d0VkhvmxUo2WMKmr$1", a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1, true);

function ok2(s, a0, a1) {
  return (a0 == undefined || a1 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$0(s) {
  s.t_elseIf_0 = true;
  (s.pc = "0.j420");
  var t_libcall_1 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["index"](s);
  return s.rt.enter(t_libcall_1.invoke(t_libcall_1, a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$1, s.$level));
}
cs.registerStep(a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$0, 'a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$0');

function a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$1(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  var t_infix_3 = (ok1(s, t_actRes_2) && (t_actRes_2 === 1));
  ok1(s, t_infix_3);
  if (t_infix_3) {
  (s.t_elseIf_0 = false);
  (s.pc = "0.j4240");
  return s.rt.enter(a_KWEdInOmFFtYq7XxKZFGF4JM(s, a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$3));
  }
  return a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$2;
}
cs.registerStep(a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$1, 'a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$1');

function a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$3(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  t_actRes_4;
  return a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$2;
}
cs.registerStep(a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$3, 'a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$3');

function a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$2(s) {
  if (s.t_elseIf_0) {
  (s.pc = "0.j425");
  var t_libcall_5 = s.libs["d2bbpYdDq6mcoCpqp1dEtgbi"]["index"](s);
  return s.rt.enter(t_libcall_5.invoke(t_libcall_5, a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$4, s.$level));
  }
  return a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$7;
}
cs.registerStep(a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$2, 'a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$2');

function a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$4(s) {
  var t_actRes_6 = s.rt.returnedFrom.result;
  var t_infix_7 = (ok1(s, t_actRes_6) && (t_actRes_6 === 2));
  ok1(s, t_infix_7);
  if (t_infix_7) {
  (s.pc = "0.j4290");
  return s.rt.enter(a_m765qPK47NI4RKhXfWkje5rG(s, a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$6));
  } else {
  (s.pc = "0.j42a0");
  null;
  }
  return a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$5;
}
cs.registerStep(a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$4, 'a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$4');

function a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$7(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$7, 'a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$7');

function a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$6(s) {
  var t_actRes_8 = s.rt.returnedFrom.result;
  t_actRes_8;
  return a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$5;
}
cs.registerStep(a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$6, 'a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$6');

function a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$5(s) {
  return a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$7;
}
cs.registerStep(a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$5, 'a_a_o6wz9cw6d0VkhvmxUo2WMKmr$1$5');

/* ACTION: level 1 */
function a_KWEdInOmFFtYq7XxKZFGF4JM(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_KWEdInOmFFtYq7XxKZFGF4JM$0;
  s.name = "level 1";
  return s;
}
cs.registerAction("level 1", "KWEdInOmFFtYq7XxKZFGF4JM", a_KWEdInOmFFtYq7XxKZFGF4JM, true);

function a_KWEdInOmFFtYq7XxKZFGF4JM$0(s) {
  (s.pc = "0.o0");
  return s.rt.enter(a_TKAAjyn1pMUXqVG0FQSsjeCq(s, a_KWEdInOmFFtYq7XxKZFGF4JM$1));
}
cs.registerStep(a_KWEdInOmFFtYq7XxKZFGF4JM$0, 'a_KWEdInOmFFtYq7XxKZFGF4JM$0');

function a_KWEdInOmFFtYq7XxKZFGF4JM$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  t_actRes_0;
  return s.rt.leave();
}
cs.registerStep(a_KWEdInOmFFtYq7XxKZFGF4JM$1, 'a_KWEdInOmFFtYq7XxKZFGF4JM$1');

/* ACTION: create board */
function a_TKAAjyn1pMUXqVG0FQSsjeCq(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_TKAAjyn1pMUXqVG0FQSsjeCq$0;
  s.name = "create board";
  s.$board = undefined;
  s.$lcoll = undefined;
  s.$coll2 = undefined;
  s.$coll = undefined;
  s.$coll3 = undefined;
  s.$hero = undefined;
  s.$herofly = undefined;
  s.$lifebo = undefined;
  s.$heroattack = undefined;
  s.$perform = undefined;
  return s;
}
cs.registerAction("create board", "TKAAjyn1pMUXqVG0FQSsjeCq", a_TKAAjyn1pMUXqVG0FQSsjeCq, true);

function ok3(s, a0, a1, a2) {
  return (a0 == undefined || a1 == undefined || a2 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok4(s, a0, a1, a2, a3) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok5(s, a0, a1, a2, a3, a4) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok6(s, a0, a1, a2, a3, a4, a5) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined || a5 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_TKAAjyn1pMUXqVG0FQSsjeCq$0(s) {
  (s.pc = "0.t0");
  var t_libcall_0 = s.libs["game"]["start with fixed size"](s);
  return s.rt.enter(t_libcall_0.invoke(t_libcall_0, a_TKAAjyn1pMUXqVG0FQSsjeCq$1, 620, 820));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$0, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$0');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_1);
  (s.pc = "0.t3");
  var t_libcall_2 = s.libs["game"]["start timer"](s);
  return s.rt.enter(t_libcall_2.invoke(t_libcall_2, a_TKAAjyn1pMUXqVG0FQSsjeCq$2));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$1, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$1');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$2(s) {
  (s.pc = "0.t6");
  var t_libcall_3 = s.libs["game"]["set life"](s);
  return s.rt.enter(t_libcall_3.invoke(t_libcall_3, a_TKAAjyn1pMUXqVG0FQSsjeCq$3, 100));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$2, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$2');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$3(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  t_actRes_4;
  (s.pc = "0.t9");
  var t_libcall_5 = s.libs["olZOoTBBwZaQT3B4fbkU2Y2c"]["initialize"](s);
  return s.rt.enter(t_libcall_5.invoke(t_libcall_5, a_TKAAjyn1pMUXqVG0FQSsjeCq$4, s.$board));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$3, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$3');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$4(s) {
  var t_actRes_6 = s.rt.returnedFrom.result;
  t_actRes_6;
  (s.pc = "0.tc");
  (/* lifeb */ s.d.$xqFpkxfy7q3EOvlgPho5S2K2 = true);
  s.rt.logDataWrite();
  (s.pc = "0.tf");
  (/* lifen */ s.d.$avoUwZDw7D0WKejA4Jr9PbAX = 50);
  s.rt.logDataWrite();
  (s.pc = "0.ti");
  (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI = 0);
  s.rt.logDataWrite();
  (s.pc = "0.tl");
  var t_call_7 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && lib.Number_.to_string(/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI, s));
  var t_call_8 = (ok1(s, t_call_7) && lib.String_.concat("Height\u003a  ", t_call_7, s));
  var t_call_9 = (ok2(s, s.$board, t_call_8) && s.$board.create_text(100, 20, 30, t_call_8, s));
  s.rt.markAllocated(t_call_9);
  (/* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe = t_call_9);
  s.rt.logDataWrite();
  (s.pc = "0.to");
  s.rt.logObjectMutation(/* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe);
  (ok1(s, /* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe) && /* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe.set_y(40, s));
  (s.pc = "0.tr");
  var t_call_10 = (ok1(s, /* life */ s.d.$lVcc2aDS6HhHBmwTa7kdaOop) && /* life */ s.d.$lVcc2aDS6HhHBmwTa7kdaOop.create_collection(s));
  (s.$lcoll = t_call_10);
  (s.pc = "0.tu");
  var t_call_11 = (ok1(s, /* bomb */ s.d.$xqFaS9qU87n5kVZ81LVFbo7X) && /* bomb */ s.d.$xqFaS9qU87n5kVZ81LVFbo7X.create_collection(s));
  (s.$coll2 = t_call_11);
  (s.pc = "0.tx");
  var t_call_12 = (ok1(s, /* bullet */ s.d.$BdGhpbmca) && /* bullet */ s.d.$BdGhpbmca.create_collection(s));
  (s.$coll = t_call_12);
  (s.pc = "0.tA");
  var t_call_13 = (ok1(s, /* laser */ s.d.$GJTCTeAJoSwxOp22t9U9Qo5X) && /* laser */ s.d.$GJTCTeAJoSwxOp22t9U9Qo5X.create_collection(s));
  (s.$coll3 = t_call_13);
  (s.pc = "0.tD");
  var t_resumeCtx_14 = s.rt.getBlockingResumeCtx(a_TKAAjyn1pMUXqVG0FQSsjeCq$5);
  var t_call_15 = (ok2(s, s.$board, /* herostill2 */ s.d.$SdO5gmsaVBpyFSCM2obtUH16) && s.$board.create_picture(/* herostill2 */ s.d.$SdO5gmsaVBpyFSCM2obtUH16, t_resumeCtx_14));
  return a_TKAAjyn1pMUXqVG0FQSsjeCq$5;
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$4, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$4');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$5(s) {
  var t_pauseRes_16 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_16);
  (s.$hero = t_pauseRes_16);
  (s.pc = "0.tG");
  return s.rt.enter(a_N6ZV7cruVdeTnRjdjkGPF8NI(s, a_TKAAjyn1pMUXqVG0FQSsjeCq$6, s.$board, s.$hero));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$5, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$5');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$6(s) {
  var t_actRes_17 = s.rt.returnedFrom.result;
  (/* scene1 */ s.d.$sPTs4ukUDjhCqQYNO6fN4iRa = t_actRes_17);
  s.rt.logDataWrite();
  (s.pc = "0.tJ");
  var t_resumeCtx_18 = s.rt.getBlockingResumeCtx(a_TKAAjyn1pMUXqVG0FQSsjeCq$7);
  var t_call_19 = (ok2(s, s.$board, /* herofly2 */ s.d.$HDSUkuLyhDFibKg27i0hlj4U) && s.$board.create_picture(/* herofly2 */ s.d.$HDSUkuLyhDFibKg27i0hlj4U, t_resumeCtx_18));
  return a_TKAAjyn1pMUXqVG0FQSsjeCq$7;
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$6, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$6');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$7(s) {
  var t_pauseRes_20 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_20);
  (s.$herofly = t_pauseRes_20);
  (s.pc = "0.tM");
  var t_call_21 = (ok1(s, s.$hero) && s.$hero.width(s));
  (s.$lifebo = t_call_21);
  (s.pc = "0.tP");
  s.rt.logObjectMutation(s.$herofly);
  (ok1(s, s.$herofly) && s.$herofly.hide(s));
  (s.pc = "0.tS");
  var t_libcall_22 = s.libs["olZOoTBBwZaQT3B4fbkU2Y2c"]["set sheet"](s);
  return s.rt.enter(t_libcall_22.invoke(t_libcall_22, a_TKAAjyn1pMUXqVG0FQSsjeCq$8, "attack", /* heroattack */ s.d.$ITg9IATeH1Zu9Lj7VBroP3uB, 1, 5));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$7, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$7');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$8(s) {
  var t_actRes_23 = s.rt.returnedFrom.result;
  t_actRes_23;
  (s.pc = "0.tV");
  var t_libcall_24 = s.libs["olZOoTBBwZaQT3B4fbkU2Y2c"]["set sheet"](s);
  return s.rt.enter(t_libcall_24.invoke(t_libcall_24, a_TKAAjyn1pMUXqVG0FQSsjeCq$9, "explode", /* fire explosion animation */ s.d.$gIktcmxXlop1JFScyuuQFFRx, 4, 5));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$8, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$8');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$9(s) {
  var t_actRes_25 = s.rt.returnedFrom.result;
  t_actRes_25;
  (s.pc = "0.tY");
  var t_infix_26 = (0 - 1);
  var t_libcall_27 = s.libs["olZOoTBBwZaQT3B4fbkU2Y2c"]["create animation"](s);
  return s.rt.enter(t_libcall_27.invoke(t_libcall_27, a_TKAAjyn1pMUXqVG0FQSsjeCq$10, "attack", 1, t_infix_26, 1, 1, 1, 5));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$9, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$9');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$10(s) {
  var t_actRes_28 = s.rt.returnedFrom.result;
  (s.$heroattack = t_actRes_28);
  (s.pc = "0.t63.");
  s.rt.logObjectMutation(s.$heroattack);
  (ok1(s, s.$heroattack) && s.$heroattack.hide(s));
  (s.pc = "0.t66.");
  return s.rt.enter(a_KZbpL7uc1r4AX4wh124AoOXM(s, a_TKAAjyn1pMUXqVG0FQSsjeCq$11, s.$board, 5, s.$coll));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$10, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$10');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$11(s) {
  var t_actRes_29 = s.rt.returnedFrom.result;
  t_actRes_29;
  (s.pc = "0.t69.");
  return s.rt.enter(a_IWEtJXU6WLOVw6Qb4RcaH63o(s, a_TKAAjyn1pMUXqVG0FQSsjeCq$12, s.$board, s.$coll2, 10));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$11, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$11');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$12(s) {
  var t_actRes_30 = s.rt.returnedFrom.result;
  t_actRes_30;
  (s.pc = "0.t72.");
  return s.rt.enter(a_yyNxrvidtxzb9mFtB3yTqY4E(s, a_TKAAjyn1pMUXqVG0FQSsjeCq$13, s.$board, s.$coll3));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$12, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$12');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$13(s) {
  var t_actRes_31 = s.rt.returnedFrom.result;
  t_actRes_31;
  (s.pc = "0.t75.");
  var t_libcall_32 = s.libs["vk4YirHiqGbPTNTjv1IL5dsL"]["control sprite"](s);
  return s.rt.enter(t_libcall_32.invoke(t_libcall_32, a_TKAAjyn1pMUXqVG0FQSsjeCq$14, s.$hero, 500, 500));
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$13, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$13');

function a_TKAAjyn1pMUXqVG0FQSsjeCq$14(s) {
  (s.pc = "0.t82.0");
  var t_lmbv_33 = s.$board;
  var t_lmbv_34 = s.$hero;
  var t_lmbv_35 = s.$herofly;
  var t_lmbv_36 = s.$lifebo;
  var t_lmbv_37 = s.$heroattack;
  var t_lmbv_38 = s.$coll;
  var t_lmbv_39 = s.$coll2;
  var t_lmbv_40 = s.$lcoll;
  var t_lmbv_41 = s.$coll3;
  var t_lmbProxy_42 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15(t_lmbProxy_42(la0), la1, t_lmbv_33, t_lmbv_34, t_lmbv_35, t_lmbv_36, t_lmbv_37, t_lmbv_38, t_lmbv_39, t_lmbv_40, t_lmbv_41) });
  (s.pc = "0.t78.");
  var t_call_43 = (ok2(s, s.$board, s.$perform) && s.$board.add_on_every_frame(s.$perform, s));
  t_call_43;
  return s.rt.leave();
}
cs.registerStep(a_TKAAjyn1pMUXqVG0FQSsjeCq$14, 'a_TKAAjyn1pMUXqVG0FQSsjeCq$14');

/* ACTION: a_TKAAjyn1pMUXqVG0FQSsjeCq::lambda::15 */
function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15(previous, returnAddr, $board, $hero, $herofly, $lifebo, $heroattack, $coll, $coll2, $lcoll, $coll3) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$0;
  s.name = "create board";
  s.$board = $board;
  s.$hero = $hero;
  s.$herofly = $herofly;
  s.$lifebo = $lifebo;
  s.$heroattack = $heroattack;
  s.$coll = $coll;
  s.$coll2 = $coll2;
  s.$lcoll = $lcoll;
  s.$coll3 = $coll3;
  return s;
}
cs.registerLambda("a_TKAAjyn1pMUXqVG0FQSsjeCq\u003a\u003alambda\u003a\u003a15", "a_TKAAjyn1pMUXqVG0FQSsjeCq$15", a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15, true);

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.t82.20");
  var t_infix_1 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI === 1000));
  ok1(s, t_infix_1);
  if (t_infix_1) {
  (s.pc = "0.t82.240");
  return s.rt.enter(a_N6ZV7cruVdeTnRjdjkGPF8NI(s, a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$2, s.$board, s.$hero));
  } else {
  (s.pc = "0.t82.250");
  null;
  }
  return a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$1;
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$0, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$0');

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$2(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  (/* scene1 */ s.d.$sPTs4ukUDjhCqQYNO6fN4iRa = t_actRes_2);
  s.rt.logDataWrite();
  return a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$1;
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$2, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$2');

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$1(s) {
  (s.pc = "0.t82.25");
  return s.rt.enter(a_r2cOsCI0XISZEc2u9nTf75yC(s, a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$3, s.$hero, s.$herofly, s.$lifebo));
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$1, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$1');

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$3(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  t_actRes_3;
  (s.pc = "0.t82.28");
  return s.rt.enter(a_xLitSpsqh4LDyoJxjOn0h4Se(s, a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$4, s.$hero, /* scene1 */ s.d.$sPTs4ukUDjhCqQYNO6fN4iRa));
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$3, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$3');

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$4(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  t_actRes_4;
  (s.pc = "0.t82.2b");
  return s.rt.enter(a_uhbt2L24evD2psoKRsllzxpd(s, a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$5, s.$hero, s.$heroattack, s.$herofly));
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$4, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$4');

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$5(s) {
  var t_actRes_5 = s.rt.returnedFrom.result;
  t_actRes_5;
  (s.pc = "0.t82.2e");
  return s.rt.enter(a_XCl21fWKRBXYc7Xv4OZQ0kbs(s, a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$6, s.$heroattack, s.$coll));
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$5, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$5');

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$6(s) {
  var t_actRes_6 = s.rt.returnedFrom.result;
  t_actRes_6;
  (s.pc = "0.t82.2h");
  return s.rt.enter(a_fz2d5loZTMTcwMAIWG5r2ULG(s, a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$7, s.$heroattack, s.$coll2));
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$6, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$6');

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$7(s) {
  var t_actRes_7 = s.rt.returnedFrom.result;
  t_actRes_7;
  (s.pc = "0.t82.2k");
  return s.rt.enter(a_j7stOaJcJGNYx3ekIDLauZgo(s, a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$8, s.$coll, s.$hero, s.$herofly, s.$coll2, s.$lcoll, s.$coll3));
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$7, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$7');

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$8(s) {
  var t_actRes_8 = s.rt.returnedFrom.result;
  t_actRes_8;
  (s.pc = "0.t82.2n");
  return s.rt.enter(a_jwzHZLACN8twZy3ltoyz6Mj2(s, a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$9, 25, s.$board, s.$lcoll));
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$8, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$8');

function a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$9(s) {
  var t_actRes_9 = s.rt.returnedFrom.result;
  t_actRes_9;
  return s.rt.leave();
}
cs.registerStep(a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$9, 'a_a_TKAAjyn1pMUXqVG0FQSsjeCq$15$9');

cs.registerArtResource("Picture", "$xM4pbTFgPmM5XqbcueYcRDIA", ".\u002fart\u002f$0$$xM4pbTFgPmM5XqbcueYcRDIA");
cs.registerArtResource("Picture", "$SdO5gmsaVBpyFSCM2obtUH16", ".\u002fart\u002f$0$$SdO5gmsaVBpyFSCM2obtUH16");
cs.registerArtResource("Picture", "$HDSUkuLyhDFibKg27i0hlj4U", ".\u002fart\u002f$0$$HDSUkuLyhDFibKg27i0hlj4U");
/* ACTION: move hero */
function a_r2cOsCI0XISZEc2u9nTf75yC(previous, returnAddr, $hero, $herofly, $x) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_r2cOsCI0XISZEc2u9nTf75yC$0;
  s.name = "move hero";
  s.$hero = $hero;
  s.$herofly = $herofly;
  s.$x = $x;
  return s;
}
cs.registerAction("move hero", "r2cOsCI0XISZEc2u9nTf75yC", a_r2cOsCI0XISZEc2u9nTf75yC, true);

function a_r2cOsCI0XISZEc2u9nTf75yC$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.B0");
  var t_call_1 = (ok1(s, s.$hero) && s.$hero.speed_y(s));
  var t_infix_2 = (ok1(s, t_call_1) && (t_call_1 < 0));
  ok1(s, t_infix_2);
  if (t_infix_2) {
  (s.pc = "0.B40");
  var t_call_3 = (ok1(s, s.$hero) && s.$hero.x(s));
  var t_call_4 = (ok1(s, s.$hero) && s.$hero.y(s));
  s.rt.logObjectMutation(s.$herofly);
  (ok3(s, s.$herofly, t_call_3, t_call_4) && s.$herofly.set_pos(t_call_3, t_call_4, s));
  (s.pc = "0.B43");
  s.rt.logObjectMutation(s.$hero);
  (ok1(s, s.$hero) && s.$hero.set_width(0, s));
  (s.pc = "0.B46");
  s.rt.logObjectMutation(s.$herofly);
  (ok1(s, s.$herofly) && s.$herofly.show(s));
  (s.pc = "0.B49");
  var t_infix_5 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI + 1));
  (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI = t_infix_5);
  s.rt.logDataWrite();
  (s.pc = "0.B4c");
  var t_call_6 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && lib.Number_.to_string(/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI, s));
  var t_call_7 = (ok1(s, t_call_6) && lib.String_.concat("Height\u003a  ", t_call_6, s));
  s.rt.logObjectMutation(/* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe);
  (ok2(s, /* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe, t_call_7) && /* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe.set_text(t_call_7, s));
  } else {
  (s.pc = "0.B50");
  s.rt.logObjectMutation(s.$herofly);
  (ok1(s, s.$herofly) && s.$herofly.hide(s));
  (s.pc = "0.B53");
  s.rt.logObjectMutation(s.$hero);
  (ok2(s, s.$hero, s.$x) && s.$hero.set_width(s.$x, s));
  }
  var t_elseIf_8 = true;
  (s.pc = "0.B5");
  var t_call_9 = (ok1(s, s.$hero) && s.$hero.speed_y(s));
  var t_infix_10 = (ok1(s, t_call_9) && (t_call_9 > 0));
  ok1(s, t_infix_10);
  if (t_infix_10) {
  (s.pc = "0.B90");
  var t_infix_11 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI - 1));
  (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI = t_infix_11);
  s.rt.logDataWrite();
  (s.pc = "0.B93");
  var t_call_12 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && lib.Number_.to_string(/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI, s));
  var t_call_13 = (ok1(s, t_call_12) && lib.String_.concat("Height\u003a  ", t_call_12, s));
  s.rt.logObjectMutation(/* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe);
  (ok2(s, /* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe, t_call_13) && /* heights */ s.d.$AtFa8mf0t1cTCggoWNMyUXUe.set_text(t_call_13, s));
  } else {
  (s.pc = "0.Ba0");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_r2cOsCI0XISZEc2u9nTf75yC$0, 'a_r2cOsCI0XISZEc2u9nTf75yC$0');

/* ACTION: scroll scene */
function a_xLitSpsqh4LDyoJxjOn0h4Se(previous, returnAddr, $hero, $scene) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xLitSpsqh4LDyoJxjOn0h4Se$0;
  s.name = "scroll scene";
  s.$hero = $hero;
  s.$scene = $scene;
  return s;
}
cs.registerAction("scroll scene", "xLitSpsqh4LDyoJxjOn0h4Se", a_xLitSpsqh4LDyoJxjOn0h4Se, true);

function a_xLitSpsqh4LDyoJxjOn0h4Se$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.G0");
  var t_call_1 = (ok1(s, s.$hero) && s.$hero.speed_y(s));
  var t_infix_2 = (ok1(s, t_call_1) && (t_call_1 < 0));
  ok1(s, t_infix_2);
  if (t_infix_2) {
  (t_elseIf_0 = false);
  (s.pc = "0.G40");
  var t_call_3 = (ok1(s, s.$scene) && s.$scene.view_y(s));
  var t_infix_4 = (ok1(s, t_call_3) && (t_call_3 - 10));
  s.rt.logObjectMutation(s.$scene);
  (ok2(s, s.$scene, t_infix_4) && s.$scene.set_view_y(t_infix_4, s));
  }
  if (t_elseIf_0) {
  (s.pc = "0.G5");
  var t_call_5 = (ok1(s, s.$hero) && s.$hero.speed_y(s));
  var t_infix_6 = (ok1(s, t_call_5) && (t_call_5 > 0));
  ok1(s, t_infix_6);
  if (t_infix_6) {
  (s.pc = "0.G90");
  var t_call_7 = (ok1(s, s.$scene) && s.$scene.view_y(s));
  var t_infix_8 = (ok1(s, t_call_7) && (t_call_7 + 10));
  s.rt.logObjectMutation(s.$scene);
  (ok2(s, s.$scene, t_infix_8) && s.$scene.set_view_y(t_infix_8, s));
  } else {
  (s.pc = "0.Ga0");
  null;
  }
  }
  return s.rt.leave();
}
cs.registerStep(a_xLitSpsqh4LDyoJxjOn0h4Se$0, 'a_xLitSpsqh4LDyoJxjOn0h4Se$0');

cs.registerArtResource("Picture", "$ITg9IATeH1Zu9Lj7VBroP3uB", ".\u002fart\u002f$0$$ITg9IATeH1Zu9Lj7VBroP3uB");
/* ACTION: attack */
function a_uhbt2L24evD2psoKRsllzxpd(previous, returnAddr, $hero, $heroattack, $herofly) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_uhbt2L24evD2psoKRsllzxpd$0;
  s.name = "attack";
  s.$hero = $hero;
  s.$heroattack = $heroattack;
  s.$herofly = $herofly;
  return s;
}
cs.registerAction("attack", "uhbt2L24evD2psoKRsllzxpd", a_uhbt2L24evD2psoKRsllzxpd, true);

function a_uhbt2L24evD2psoKRsllzxpd$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.M0");
  var t_call_1 = lib.Senses.is_key_pressed("space", s);
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.pc = "0.M40");
  var t_call_2 = (ok1(s, s.$hero) && s.$hero.x(s));
  var t_call_3 = (ok1(s, s.$hero) && s.$hero.y(s));
  s.rt.logObjectMutation(s.$heroattack);
  (ok3(s, s.$heroattack, t_call_2, t_call_3) && s.$heroattack.set_pos(t_call_2, t_call_3, s));
  (s.pc = "0.M43");
  s.rt.logObjectMutation(s.$heroattack);
  (ok1(s, s.$heroattack) && s.$heroattack.show(s));
  (s.pc = "0.M46");
  s.rt.logObjectMutation(s.$hero);
  (ok1(s, s.$hero) && s.$hero.set_width(0, s));
  (s.pc = "0.M49");
  s.rt.logObjectMutation(s.$herofly);
  (ok1(s, s.$herofly) && s.$herofly.hide(s));
  } else {
  (s.pc = "0.M50");
  s.rt.logObjectMutation(s.$heroattack);
  (ok1(s, s.$heroattack) && s.$heroattack.hide(s));
  var t_elseIf_4 = true;
  (s.pc = "0.M53");
  var t_call_5 = (ok1(s, s.$hero) && s.$hero.is_visible(s));
  var t_call_6 = (ok1(s, t_call_5) && lib.Boolean_.not(t_call_5, s));
  ok1(s, t_call_6);
  if (t_call_6) {
  (s.pc = "0.M570");
  s.rt.logObjectMutation(s.$herofly);
  (ok1(s, s.$herofly) && s.$herofly.show(s));
  } else {
  (s.pc = "0.M580");
  null;
  }
  }
  return s.rt.leave();
}
cs.registerStep(a_uhbt2L24evD2psoKRsllzxpd$0, 'a_uhbt2L24evD2psoKRsllzxpd$0');


//Ent_BdGhpbmca
function Ent_BdGhpbmca(p) {
  this.parent = p;
}
Ent_BdGhpbmca.prototype = new lib.ObjectEntry();
Ent_BdGhpbmca.prototype.keys = [];
Ent_BdGhpbmca.prototype.values = ["Z41E2DubmAMHlxkPgRosVsI4", "EAd1KA7NlpGsS3TK2VBvxbvz", "JDEve44j9kFo6wXL4QFtMSMf"];
Ent_BdGhpbmca.prototype.fields = ["Z41E2DubmAMHlxkPgRosVsI4", "EAd1KA7NlpGsS3TK2VBvxbvz", "JDEve44j9kFo6wXL4QFtMSMf"];
Ent_BdGhpbmca.prototype.Z41E2DubmAMHlxkPgRosVsI4_realname = "bullet";
Ent_BdGhpbmca.prototype.EAd1KA7NlpGsS3TK2VBvxbvz_realname = "hp";
Ent_BdGhpbmca.prototype.JDEve44j9kFo6wXL4QFtMSMf_realname = "speed";
Ent_BdGhpbmca.prototype.EAd1KA7NlpGsS3TK2VBvxbvz = 0;
Ent_BdGhpbmca.prototype.JDEve44j9kFo6wXL4QFtMSMf = 0;
//Col_BdGhpbmca
function Col_BdGhpbmca(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_BdGhpbmca.prototype = lib.RecordCollection.prototype;
//Tbl_BdGhpbmca
function Tbl_BdGhpbmca(l) {
  this.libName = l;
  this.initParent();
}
Tbl_BdGhpbmca.prototype = new lib.ObjectSingleton();
Tbl_BdGhpbmca.prototype.entryCtor = Ent_BdGhpbmca;
Tbl_BdGhpbmca.prototype.selfCtor = Tbl_BdGhpbmca;
Tbl_BdGhpbmca.prototype.collectionCtor = Col_BdGhpbmca;
Tbl_BdGhpbmca.prototype.stableName = "BdGhpbmca";
Tbl_BdGhpbmca.prototype.entryKindName = "bullet";

// jsonimport
Ent_BdGhpbmca.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("EAd1KA7NlpGsS3TK2VBvxbvz", ctx.importNumber(json, "hp"), s);
  this.perform_set("JDEve44j9kFo6wXL4QFtMSMf", ctx.importNumber(json, "speed"), s);
}
cs.registerGlobal("$BdGhpbmca");
cs.registerArtResource("Picture", "$hVt6nP4deOtXlD0aJRnT1S9L", ".\u002fart\u002f$0$$hVt6nP4deOtXlD0aJRnT1S9L");
/* ACTION: initialize bullet */
function a_O5AchFA4DRQnkRWgtnAinrTT(previous, returnAddr, $board) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_O5AchFA4DRQnkRWgtnAinrTT$0;
  s.name = "initialize bullet";
  s.$board = $board;
  s.result = undefined;
  s.$sprite = undefined;
  s.$hp = undefined;
  s.$speed = undefined;
  s.$bullet = undefined;
  return s;
}
cs.registerAction("initialize bullet", "O5AchFA4DRQnkRWgtnAinrTT", a_O5AchFA4DRQnkRWgtnAinrTT, true);

function a_O5AchFA4DRQnkRWgtnAinrTT$0(s) {
  (s.pc = "0.T0");
  var t_resumeCtx_0 = s.rt.getBlockingResumeCtx(a_O5AchFA4DRQnkRWgtnAinrTT$1);
  var t_call_1 = (ok2(s, s.$board, /* bullet2 */ s.d.$hVt6nP4deOtXlD0aJRnT1S9L) && s.$board.create_picture(/* bullet2 */ s.d.$hVt6nP4deOtXlD0aJRnT1S9L, t_resumeCtx_0));
  return a_O5AchFA4DRQnkRWgtnAinrTT$1;
}
cs.registerStep(a_O5AchFA4DRQnkRWgtnAinrTT$0, 'a_O5AchFA4DRQnkRWgtnAinrTT$0');

function a_O5AchFA4DRQnkRWgtnAinrTT$1(s) {
  var t_pauseRes_2 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_2);
  (s.$sprite = t_pauseRes_2);
  (s.pc = "0.T3");
  (s.$hp = 10);
  (s.pc = "0.T6");
  var t_call_3 = lib.Math_.random_range(50, 200, s);
  (s.$speed = t_call_3);
  (s.pc = "0.T9");
  var t_call_4 = (ok1(s, /* bullet */ s.d.$BdGhpbmca) && /* bullet */ s.d.$BdGhpbmca.create(s));
  s.rt.markAllocated(t_call_4);
  (s.$bullet = t_call_4);
  (s.pc = "0.Tc");
  if (s.$bullet) {
  s.$bullet.perform_set("Z41E2DubmAMHlxkPgRosVsI4", s.$sprite, s);
  }
  (s.pc = "0.Tf");
  if (s.$bullet) {
  var t_recOp_5 = s.$bullet[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  var t_infix_6 = (0 - 1);
  s.rt.logObjectMutation(t_recOp_5);
  (ok2(s, t_recOp_5, t_infix_6) && t_recOp_5.set_x(t_infix_6, s));
  (s.pc = "0.Ti");
  if (s.$bullet) {
  var t_recOp_7 = s.$bullet[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  var t_infix_8 = (0 - 1);
  var t_call_9 = (ok1(s, s.$board) && s.$board.height(s));
  var t_infix_10 = (ok1(s, t_call_9) && (t_call_9 + 1));
  var t_call_11 = (ok2(s, t_infix_8, t_infix_10) && lib.Math_.random_range(t_infix_8, t_infix_10, s));
  s.rt.logObjectMutation(t_recOp_7);
  (ok2(s, t_recOp_7, t_call_11) && t_recOp_7.set_y(t_call_11, s));
  (s.pc = "0.Tl");
  if (s.$bullet) {
  s.$bullet.perform_set("EAd1KA7NlpGsS3TK2VBvxbvz", s.$hp, s);
  }
  (s.pc = "0.To");
  if (s.$bullet) {
  var t_recOp_12 = s.$bullet[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  s.rt.logObjectMutation(t_recOp_12);
  (ok2(s, t_recOp_12, s.$speed) && t_recOp_12.set_speed_x(s.$speed, s));
  (s.pc = "0.Tr");
  (s.result = s.$bullet);
  return s.rt.leave();
}
cs.registerStep(a_O5AchFA4DRQnkRWgtnAinrTT$1, 'a_O5AchFA4DRQnkRWgtnAinrTT$1');


//Ent_G5oQuHDyj1Cqydixu1lYbuzm
function Ent_G5oQuHDyj1Cqydixu1lYbuzm(p) {
  this.parent = p;
}
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype = new lib.ObjectEntry();
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype.keys = [];
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype.values = ["KtEOXKrxj06gSd8dHI8omYYD", "xR7hZWzHD9VzarkFkibRhNe1", "xgqwlNknxGDbY4E8rv3nbZOY"];
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype.fields = ["KtEOXKrxj06gSd8dHI8omYYD", "xR7hZWzHD9VzarkFkibRhNe1", "xgqwlNknxGDbY4E8rv3nbZOY"];
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype.KtEOXKrxj06gSd8dHI8omYYD_realname = "hero";
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype.xR7hZWzHD9VzarkFkibRhNe1_realname = "hp";
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype.xgqwlNknxGDbY4E8rv3nbZOY_realname = "energy";
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype.xR7hZWzHD9VzarkFkibRhNe1 = 0;
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype.xgqwlNknxGDbY4E8rv3nbZOY = 0;
//Col_G5oQuHDyj1Cqydixu1lYbuzm
function Col_G5oQuHDyj1Cqydixu1lYbuzm(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_G5oQuHDyj1Cqydixu1lYbuzm.prototype = lib.RecordCollection.prototype;
//Tbl_G5oQuHDyj1Cqydixu1lYbuzm
function Tbl_G5oQuHDyj1Cqydixu1lYbuzm(l) {
  this.libName = l;
  this.initParent();
}
Tbl_G5oQuHDyj1Cqydixu1lYbuzm.prototype = new lib.ObjectSingleton();
Tbl_G5oQuHDyj1Cqydixu1lYbuzm.prototype.entryCtor = Ent_G5oQuHDyj1Cqydixu1lYbuzm;
Tbl_G5oQuHDyj1Cqydixu1lYbuzm.prototype.selfCtor = Tbl_G5oQuHDyj1Cqydixu1lYbuzm;
Tbl_G5oQuHDyj1Cqydixu1lYbuzm.prototype.collectionCtor = Col_G5oQuHDyj1Cqydixu1lYbuzm;
Tbl_G5oQuHDyj1Cqydixu1lYbuzm.prototype.stableName = "G5oQuHDyj1Cqydixu1lYbuzm";
Tbl_G5oQuHDyj1Cqydixu1lYbuzm.prototype.entryKindName = "hero";

// jsonimport
Ent_G5oQuHDyj1Cqydixu1lYbuzm.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("xR7hZWzHD9VzarkFkibRhNe1", ctx.importNumber(json, "hp"), s);
  this.perform_set("xgqwlNknxGDbY4E8rv3nbZOY", ctx.importNumber(json, "energy"), s);
}
cs.registerGlobal("$G5oQuHDyj1Cqydixu1lYbuzm");
/* ACTION: remove bullet */
function a_XCl21fWKRBXYc7Xv4OZQ0kbs(previous, returnAddr, $heroattack, $bullet) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_XCl21fWKRBXYc7Xv4OZQ0kbs$0;
  s.name = "remove bullet";
  s.$heroattack = $heroattack;
  s.$bullet = $bullet;
  s.$bullet2 = undefined;
  s.$explosion = undefined;
  s.$b = undefined;
  return s;
}
cs.registerAction("remove bullet", "XCl21fWKRBXYc7Xv4OZQ0kbs", a_XCl21fWKRBXYc7Xv4OZQ0kbs, true);

function a_XCl21fWKRBXYc7Xv4OZQ0kbs$0(s) {
  (s.pc = "0.Z0");
  s.t_collArr_0 = (ok1(s, s.$bullet) && s.$bullet.get_enumerator());
  s.t_idx_1 = 0;
  return a_XCl21fWKRBXYc7Xv4OZQ0kbs$1;
}
cs.registerStep(a_XCl21fWKRBXYc7Xv4OZQ0kbs$0, 'a_XCl21fWKRBXYc7Xv4OZQ0kbs$0');

function a_XCl21fWKRBXYc7Xv4OZQ0kbs$1(s) {
  if ((s.t_idx_1 < (s.t_collArr_0.length))) {
  (s.$bullet2 = s.t_collArr_0[(s.t_idx_1)]);
  (s.t_idx_1++);
  if (s.$bullet2) {
  var t_recOp_2 = s.$bullet2[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  var t_call_3 = (ok2(s, s.$heroattack, t_recOp_2) && s.$heroattack.overlaps_with(t_recOp_2, s));
  if (t_call_3) {
  var t_elseIf_4 = true;
  (s.pc = "0.Z50");
  var t_call_5 = (ok1(s, s.$heroattack) && s.$heroattack.is_visible(s));
  ok1(s, t_call_5);
  if (t_call_5) {
  (s.pc = "0.Z540");
  if (s.$bullet2) {
  var t_recOp_6 = s.$bullet2[("EAd1KA7NlpGsS3TK2VBvxbvz")];
  }
  var t_infix_7 = (ok1(s, t_recOp_6) && (t_recOp_6 - 1));
  if (s.$bullet2) {
  s.$bullet2.perform_set("EAd1KA7NlpGsS3TK2VBvxbvz", t_infix_7, s);
  }
  var t_elseIf_8 = true;
  (s.pc = "0.Z543");
  if (s.$bullet2) {
  var t_recOp_9 = s.$bullet2[("EAd1KA7NlpGsS3TK2VBvxbvz")];
  }
  var t_infix_10 = (ok1(s, t_recOp_9) && (t_recOp_9 === 0));
  ok1(s, t_infix_10);
  if (t_infix_10) {
  (s.pc = "0.Z5470");
  var t_libcall_11 = s.libs["game"]["add score"](s);
  return s.rt.enter(t_libcall_11.invoke(t_libcall_11, a_XCl21fWKRBXYc7Xv4OZQ0kbs$10, 10));
  } else {
  (s.pc = "0.Z5480");
  null;
  }
  return a_XCl21fWKRBXYc7Xv4OZQ0kbs$9;
  } else {
  (s.pc = "0.Z550");
  null;
  }
  return a_XCl21fWKRBXYc7Xv4OZQ0kbs$5;
  }
  return a_XCl21fWKRBXYc7Xv4OZQ0kbs$3;
  }
  return s.rt.leave();
}
cs.registerStep(a_XCl21fWKRBXYc7Xv4OZQ0kbs$1, 'a_XCl21fWKRBXYc7Xv4OZQ0kbs$1');

function a_XCl21fWKRBXYc7Xv4OZQ0kbs$10(s) {
  (s.pc = "0.Z5473");
  var t_libcall_12 = s.libs["olZOoTBBwZaQT3B4fbkU2Y2c"]["create animation"](s);
  return s.rt.enter(t_libcall_12.invoke(t_libcall_12, a_XCl21fWKRBXYc7Xv4OZQ0kbs$11, "explode", 1, 1, 1, 1, 4, 5));
}
cs.registerStep(a_XCl21fWKRBXYc7Xv4OZQ0kbs$10, 'a_XCl21fWKRBXYc7Xv4OZQ0kbs$10');

function a_XCl21fWKRBXYc7Xv4OZQ0kbs$9(s) {
  return a_XCl21fWKRBXYc7Xv4OZQ0kbs$5;
}
cs.registerStep(a_XCl21fWKRBXYc7Xv4OZQ0kbs$9, 'a_XCl21fWKRBXYc7Xv4OZQ0kbs$9');

function a_XCl21fWKRBXYc7Xv4OZQ0kbs$5(s) {
  return a_XCl21fWKRBXYc7Xv4OZQ0kbs$3;
}
cs.registerStep(a_XCl21fWKRBXYc7Xv4OZQ0kbs$5, 'a_XCl21fWKRBXYc7Xv4OZQ0kbs$5');

function a_XCl21fWKRBXYc7Xv4OZQ0kbs$3(s) {
  return a_XCl21fWKRBXYc7Xv4OZQ0kbs$1;
}
cs.registerStep(a_XCl21fWKRBXYc7Xv4OZQ0kbs$3, 'a_XCl21fWKRBXYc7Xv4OZQ0kbs$3');

function a_XCl21fWKRBXYc7Xv4OZQ0kbs$11(s) {
  var t_actRes_13 = s.rt.returnedFrom.result;
  (s.$explosion = t_actRes_13);
  (s.pc = "0.Z5476");
  if (s.$bullet2) {
  var t_recOp_14 = s.$bullet2[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  var t_call_15 = (ok1(s, t_recOp_14) && t_recOp_14.x(s));
  if (s.$bullet2) {
  var t_recOp_16 = s.$bullet2[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  var t_call_17 = (ok1(s, t_recOp_16) && t_recOp_16.y(s));
  s.rt.logObjectMutation(s.$explosion);
  (ok3(s, s.$explosion, t_call_15, t_call_17) && s.$explosion.set_pos(t_call_15, t_call_17, s));
  (s.pc = "0.Z5479");
  if (s.$bullet2) {
  var t_recOp_18 = s.$bullet2[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  var t_call_19 = (ok1(s, t_recOp_18) && t_recOp_18.width(s));
  s.rt.logObjectMutation(s.$explosion);
  (ok2(s, s.$explosion, t_call_19) && s.$explosion.set_width(t_call_19, s));
  (s.pc = "0.Z547c");
  if (s.$bullet2) {
  var t_recOp_20 = s.$bullet2[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  s.rt.logObjectMutation(t_recOp_20);
  (ok1(s, t_recOp_20) && t_recOp_20.delete_(s));
  (s.pc = "0.Z547f");
  s.rt.logObjectMutation(s.$bullet);
  var t_call_21 = (ok2(s, s.$bullet, s.$bullet2) && s.$bullet.remove(s.$bullet2, s));
  (s.$b = t_call_21);
  return a_XCl21fWKRBXYc7Xv4OZQ0kbs$9;
}
cs.registerStep(a_XCl21fWKRBXYc7Xv4OZQ0kbs$11, 'a_XCl21fWKRBXYc7Xv4OZQ0kbs$11');

/* ACTION: create scene */
function a_N6ZV7cruVdeTnRjdjkGPF8NI(previous, returnAddr, $board, $hero2) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_N6ZV7cruVdeTnRjdjkGPF8NI$0;
  s.name = "create scene";
  s.$board = $board;
  s.$hero2 = $hero2;
  s.result = undefined;
  s.$scene2 = undefined;
  s.$pic = undefined;
  s.$layer = undefined;
  s.$pic2 = undefined;
  return s;
}
cs.registerAction("create scene", "N6ZV7cruVdeTnRjdjkGPF8NI", a_N6ZV7cruVdeTnRjdjkGPF8NI, true);

function a_N6ZV7cruVdeTnRjdjkGPF8NI$0(s) {
  (s.pc = "0.66.0");
  var t_call_0 = (ok1(s, s.$board) && s.$board.background_scene(s));
  (s.result = t_call_0);
  (s.pc = "0.66.3");
  var t_call_1 = (ok1(s, s.$hero2) && s.$hero2.height(s));
  var t_infix_2 = (ok1(s, t_call_1) && (0 - t_call_1));
  var t_infix_3 = (ok1(s, t_infix_2) && (t_infix_2 / 3));
  s.rt.logObjectMutation(s.$board);
  (ok2(s, s.$board, t_infix_3) && s.$board.create_boundary(t_infix_3, s));
  (s.pc = "0.66.6");
  var t_call_4 = (ok1(s, s.$board) && s.$board.background_scene(s));
  (s.$scene2 = t_call_4);
  (s.pc = "0.66.9");
  var t_resumeCtx_5 = s.rt.getBlockingResumeCtx(a_N6ZV7cruVdeTnRjdjkGPF8NI$1);
  var t_call_6 = (ok1(s, /* long sky */ s.d.$xM4pbTFgPmM5XqbcueYcRDIA) && /* long sky */ s.d.$xM4pbTFgPmM5XqbcueYcRDIA.clone(t_resumeCtx_5));
  return a_N6ZV7cruVdeTnRjdjkGPF8NI$1;
}
cs.registerStep(a_N6ZV7cruVdeTnRjdjkGPF8NI$0, 'a_N6ZV7cruVdeTnRjdjkGPF8NI$0');

function a_N6ZV7cruVdeTnRjdjkGPF8NI$1(s) {
  var t_pauseRes_7 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_7);
  (s.$pic = t_pauseRes_7);
  (s.pc = "0.66.c");
  s.rt.logObjectMutation(s.$pic);
  var t_resumeCtx_8 = s.rt.getBlockingResumeCtx(a_N6ZV7cruVdeTnRjdjkGPF8NI$2);
  (ok1(s, s.$pic) && s.$pic.flip_vertical(t_resumeCtx_8));
  return a_N6ZV7cruVdeTnRjdjkGPF8NI$2;
}
cs.registerStep(a_N6ZV7cruVdeTnRjdjkGPF8NI$1, 'a_N6ZV7cruVdeTnRjdjkGPF8NI$1');

function a_N6ZV7cruVdeTnRjdjkGPF8NI$2(s) {
  (s.pc = "0.66.f");
  s.rt.logObjectMutation(s.result);
  var t_resumeCtx_9 = s.rt.getBlockingResumeCtx(a_N6ZV7cruVdeTnRjdjkGPF8NI$3);
  var t_call_10 = (ok2(s, s.result, s.$pic) && s.result.create_layer(0, s.$pic, t_resumeCtx_9));
  return a_N6ZV7cruVdeTnRjdjkGPF8NI$3;
}
cs.registerStep(a_N6ZV7cruVdeTnRjdjkGPF8NI$2, 'a_N6ZV7cruVdeTnRjdjkGPF8NI$2');

function a_N6ZV7cruVdeTnRjdjkGPF8NI$3(s) {
  var t_pauseRes_11 = s.pauseValue;
  (s.$layer = t_pauseRes_11);
  var t_elseIf_12 = true;
  (s.pc = "0.66.i");
  var t_infix_13 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI >= 1000));
  ok1(s, t_infix_13);
  if (t_infix_13) {
  (s.pc = "0.66.m0");
  (ok1(s, s.$board) && s.$board.clear_background_picture(s));
  (s.pc = "0.66.m3");
  (ok1(s, s.result) && s.result.clear(s));
  (s.pc = "0.66.m6");
  var t_call_14 = (ok1(s, s.$board) && s.$board.background_scene(s));
  (s.result = t_call_14);
  (s.pc = "0.66.m9");
  (s.$pic2 = /* Space Background (460x800) */ s.d.$G4FSGH7QbiLfIRtkzNPKmHCW);
  (s.pc = "0.66.mc");
  s.rt.logObjectMutation(s.result);
  var t_resumeCtx_15 = s.rt.getBlockingResumeCtx(a_N6ZV7cruVdeTnRjdjkGPF8NI$5);
  var t_call_16 = (ok2(s, s.result, s.$pic2) && s.result.create_layer(0, s.$pic2, t_resumeCtx_15));
  return a_N6ZV7cruVdeTnRjdjkGPF8NI$5;
  } else {
  (s.pc = "0.66.n0");
  null;
  }
  return a_N6ZV7cruVdeTnRjdjkGPF8NI$4;
}
cs.registerStep(a_N6ZV7cruVdeTnRjdjkGPF8NI$3, 'a_N6ZV7cruVdeTnRjdjkGPF8NI$3');

function a_N6ZV7cruVdeTnRjdjkGPF8NI$5(s) {
  var t_pauseRes_17 = s.pauseValue;
  (s.$layer = t_pauseRes_17);
  return a_N6ZV7cruVdeTnRjdjkGPF8NI$4;
}
cs.registerStep(a_N6ZV7cruVdeTnRjdjkGPF8NI$5, 'a_N6ZV7cruVdeTnRjdjkGPF8NI$5');

function a_N6ZV7cruVdeTnRjdjkGPF8NI$4(s) {
  return s.rt.leave();
}
cs.registerStep(a_N6ZV7cruVdeTnRjdjkGPF8NI$4, 'a_N6ZV7cruVdeTnRjdjkGPF8NI$4');

/* ACTION: remove life */
function a_j7stOaJcJGNYx3ekIDLauZgo(previous, returnAddr, $bullet, $hero, $herofly, $coll, $coll2, $coll3) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_j7stOaJcJGNYx3ekIDLauZgo$0;
  s.name = "remove life";
  s.$bullet = $bullet;
  s.$hero = $hero;
  s.$herofly = $herofly;
  s.$coll = $coll;
  s.$coll2 = $coll2;
  s.$coll3 = $coll3;
  s.$bullet2 = undefined;
  s.$bomb = undefined;
  s.$life = undefined;
  s.$laser = undefined;
  return s;
}
cs.registerAction("remove life", "j7stOaJcJGNYx3ekIDLauZgo", a_j7stOaJcJGNYx3ekIDLauZgo, true);

function a_j7stOaJcJGNYx3ekIDLauZgo$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.71.0");
  true;
  if ((s.$bullet == undefined)) {
  (s.pc = "0.71.40");
  null;
  } else {
  (s.pc = "0.71.50");
  s.t_collArr_1 = (ok1(s, s.$bullet) && s.$bullet.get_enumerator());
  s.t_idx_2 = 0;
  return a_j7stOaJcJGNYx3ekIDLauZgo$2;
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$1;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$0, 'a_j7stOaJcJGNYx3ekIDLauZgo$0');

function a_j7stOaJcJGNYx3ekIDLauZgo$2(s) {
  if ((s.t_idx_2 < (s.t_collArr_1.length))) {
  (s.$bullet2 = s.t_collArr_1[(s.t_idx_2)]);
  (s.t_idx_2++);
  if (s.$bullet2) {
  var t_recOp_3 = s.$bullet2[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  var t_call_4 = (ok2(s, s.$hero, t_recOp_3) && s.$hero.overlaps_with(t_recOp_3, s));
  var t_lazy_5 = t_call_4;
  if ((ok1(s, t_lazy_5) && (!t_lazy_5))) {
  if (s.$bullet2) {
  var t_recOp_6 = s.$bullet2[("Z41E2DubmAMHlxkPgRosVsI4")];
  }
  var t_call_7 = (ok2(s, s.$herofly, t_recOp_6) && s.$herofly.overlaps_with(t_recOp_6, s));
  (t_lazy_5 = t_call_7);
  }
  if (t_lazy_5) {
  (s.pc = "0.71.550");
  var t_libcall_8 = s.libs["game"]["remove life"](s);
  return s.rt.enter(t_libcall_8.invoke(t_libcall_8, a_j7stOaJcJGNYx3ekIDLauZgo$8, 1));
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$4;
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$1;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$2, 'a_j7stOaJcJGNYx3ekIDLauZgo$2');

function a_j7stOaJcJGNYx3ekIDLauZgo$1(s) {
  var t_elseIf_10 = true;
  (s.pc = "0.71.5");
  true;
  if ((s.$coll == undefined)) {
  (s.pc = "0.71.90");
  null;
  } else {
  (s.pc = "0.71.a0");
  s.t_collArr_11 = (ok1(s, s.$coll) && s.$coll.get_enumerator());
  s.t_idx_12 = 0;
  return a_j7stOaJcJGNYx3ekIDLauZgo$10;
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$9;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$1, 'a_j7stOaJcJGNYx3ekIDLauZgo$1');

function a_j7stOaJcJGNYx3ekIDLauZgo$8(s) {
  var t_actRes_9 = s.rt.returnedFrom.result;
  t_actRes_9;
  return a_j7stOaJcJGNYx3ekIDLauZgo$4;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$8, 'a_j7stOaJcJGNYx3ekIDLauZgo$8');

function a_j7stOaJcJGNYx3ekIDLauZgo$4(s) {
  return a_j7stOaJcJGNYx3ekIDLauZgo$2;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$4, 'a_j7stOaJcJGNYx3ekIDLauZgo$4');

function a_j7stOaJcJGNYx3ekIDLauZgo$10(s) {
  if ((s.t_idx_12 < (s.t_collArr_11.length))) {
  (s.$bomb = s.t_collArr_11[(s.t_idx_12)]);
  (s.t_idx_12++);
  if (s.$bomb) {
  var t_recOp_13 = s.$bomb[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  var t_call_14 = (ok2(s, s.$hero, t_recOp_13) && s.$hero.overlaps_with(t_recOp_13, s));
  var t_lazy_15 = t_call_14;
  if ((ok1(s, t_lazy_15) && (!t_lazy_15))) {
  if (s.$bomb) {
  var t_recOp_16 = s.$bomb[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  var t_call_17 = (ok2(s, s.$herofly, t_recOp_16) && s.$herofly.overlaps_with(t_recOp_16, s));
  (t_lazy_15 = t_call_17);
  }
  if (t_lazy_15) {
  (s.pc = "0.71.a50");
  var t_libcall_18 = s.libs["game"]["remove life"](s);
  return s.rt.enter(t_libcall_18.invoke(t_libcall_18, a_j7stOaJcJGNYx3ekIDLauZgo$16, 1));
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$12;
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$9;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$10, 'a_j7stOaJcJGNYx3ekIDLauZgo$10');

function a_j7stOaJcJGNYx3ekIDLauZgo$9(s) {
  var t_elseIf_20 = true;
  (s.pc = "0.71.a");
  true;
  if ((s.$coll2 == undefined)) {
  (s.pc = "0.71.e0");
  null;
  } else {
  (s.pc = "0.71.f0");
  s.t_collArr_21 = (ok1(s, s.$coll2) && s.$coll2.get_enumerator());
  s.t_idx_22 = 0;
  return a_j7stOaJcJGNYx3ekIDLauZgo$18;
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$17;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$9, 'a_j7stOaJcJGNYx3ekIDLauZgo$9');

function a_j7stOaJcJGNYx3ekIDLauZgo$16(s) {
  var t_actRes_19 = s.rt.returnedFrom.result;
  t_actRes_19;
  return a_j7stOaJcJGNYx3ekIDLauZgo$12;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$16, 'a_j7stOaJcJGNYx3ekIDLauZgo$16');

function a_j7stOaJcJGNYx3ekIDLauZgo$12(s) {
  return a_j7stOaJcJGNYx3ekIDLauZgo$10;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$12, 'a_j7stOaJcJGNYx3ekIDLauZgo$12');

function a_j7stOaJcJGNYx3ekIDLauZgo$18(s) {
  if ((s.t_idx_22 < (s.t_collArr_21.length))) {
  (s.$life = s.t_collArr_21[(s.t_idx_22)]);
  (s.t_idx_22++);
  if (s.$life) {
  var t_recOp_23 = s.$life[("xNbZDhcxzZ5xttFiEIS5AU7y")];
  }
  var t_call_24 = (ok2(s, s.$hero, t_recOp_23) && s.$hero.overlaps_with(t_recOp_23, s));
  var t_lazy_25 = t_call_24;
  if ((ok1(s, t_lazy_25) && (!t_lazy_25))) {
  if (s.$life) {
  var t_recOp_26 = s.$life[("xNbZDhcxzZ5xttFiEIS5AU7y")];
  }
  var t_call_27 = (ok2(s, s.$herofly, t_recOp_26) && s.$herofly.overlaps_with(t_recOp_26, s));
  (t_lazy_25 = t_call_27);
  }
  if (t_lazy_25) {
  (s.pc = "0.71.f50");
  if (s.$life) {
  var t_recOp_28 = s.$life[("ZojQ13mdIh2vF4tadRK4tner")];
  }
  var t_libcall_29 = s.libs["game"]["add life"](s);
  return s.rt.enter(t_libcall_29.invoke(t_libcall_29, a_j7stOaJcJGNYx3ekIDLauZgo$25, t_recOp_28));
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$20;
  }
  var t_elseIf_33 = true;
  (s.pc = "0.71.f5");
  true;
  if ((s.$coll3 == undefined)) {
  (s.pc = "0.71.f90");
  null;
  } else {
  (s.pc = "0.71.fa0");
  s.t_collArr_34 = (ok1(s, s.$coll3) && s.$coll3.get_enumerator());
  s.t_idx_35 = 0;
  return a_j7stOaJcJGNYx3ekIDLauZgo$28;
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$27;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$18, 'a_j7stOaJcJGNYx3ekIDLauZgo$18');

function a_j7stOaJcJGNYx3ekIDLauZgo$17(s) {
  return s.rt.leave();
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$17, 'a_j7stOaJcJGNYx3ekIDLauZgo$17');

function a_j7stOaJcJGNYx3ekIDLauZgo$25(s) {
  var t_actRes_30 = s.rt.returnedFrom.result;
  t_actRes_30;
  (s.pc = "0.71.f53");
  if (s.$life) {
  var t_recOp_31 = s.$life[("xNbZDhcxzZ5xttFiEIS5AU7y")];
  }
  s.rt.logObjectMutation(t_recOp_31);
  (ok1(s, t_recOp_31) && t_recOp_31.delete_(s));
  (s.pc = "0.71.f56");
  s.rt.logObjectMutation(s.$coll2);
  var t_call_32 = (ok2(s, s.$coll2, s.$life) && s.$coll2.remove(s.$life, s));
  t_call_32;
  return a_j7stOaJcJGNYx3ekIDLauZgo$20;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$25, 'a_j7stOaJcJGNYx3ekIDLauZgo$25');

function a_j7stOaJcJGNYx3ekIDLauZgo$20(s) {
  return a_j7stOaJcJGNYx3ekIDLauZgo$18;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$20, 'a_j7stOaJcJGNYx3ekIDLauZgo$20');

function a_j7stOaJcJGNYx3ekIDLauZgo$28(s) {
  if ((s.t_idx_35 < (s.t_collArr_34.length))) {
  (s.$laser = s.t_collArr_34[(s.t_idx_35)]);
  (s.t_idx_35++);
  if (s.$laser) {
  var t_recOp_36 = s.$laser[("xS8C4g0g3NyaN3dDHZaEsNCK")];
  }
  var t_call_37 = (ok2(s, s.$hero, t_recOp_36) && s.$hero.overlaps_with(t_recOp_36, s));
  var t_lazy_38 = t_call_37;
  if ((ok1(s, t_lazy_38) && (!t_lazy_38))) {
  if (s.$laser) {
  var t_recOp_39 = s.$laser[("xS8C4g0g3NyaN3dDHZaEsNCK")];
  }
  var t_call_40 = (ok2(s, s.$herofly, t_recOp_39) && s.$herofly.overlaps_with(t_recOp_39, s));
  (t_lazy_38 = t_call_40);
  }
  if (t_lazy_38) {
  (s.pc = "0.71.fa50");
  var t_libcall_41 = s.libs["game"]["remove life"](s);
  return s.rt.enter(t_libcall_41.invoke(t_libcall_41, a_j7stOaJcJGNYx3ekIDLauZgo$34, 0.5));
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$30;
  }
  return a_j7stOaJcJGNYx3ekIDLauZgo$27;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$28, 'a_j7stOaJcJGNYx3ekIDLauZgo$28');

function a_j7stOaJcJGNYx3ekIDLauZgo$27(s) {
  return a_j7stOaJcJGNYx3ekIDLauZgo$17;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$27, 'a_j7stOaJcJGNYx3ekIDLauZgo$27');

function a_j7stOaJcJGNYx3ekIDLauZgo$34(s) {
  var t_actRes_42 = s.rt.returnedFrom.result;
  t_actRes_42;
  return a_j7stOaJcJGNYx3ekIDLauZgo$30;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$34, 'a_j7stOaJcJGNYx3ekIDLauZgo$34');

function a_j7stOaJcJGNYx3ekIDLauZgo$30(s) {
  return a_j7stOaJcJGNYx3ekIDLauZgo$28;
}
cs.registerStep(a_j7stOaJcJGNYx3ekIDLauZgo$30, 'a_j7stOaJcJGNYx3ekIDLauZgo$30');

/* ACTION: fire bullets */
function a_KZbpL7uc1r4AX4wh124AoOXM(previous, returnAddr, $board, $max, $coll) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_KZbpL7uc1r4AX4wh124AoOXM$0;
  s.name = "fire bullets";
  s.$board = $board;
  s.$max = $max;
  s.$coll = $coll;
  s.$perform2 = undefined;
  s.$i = undefined;
  return s;
}
cs.registerAction("fire bullets", "KZbpL7uc1r4AX4wh124AoOXM", a_KZbpL7uc1r4AX4wh124AoOXM, true);

function a_KZbpL7uc1r4AX4wh124AoOXM$0(s) {
  (s.pc = "0.77.0");
  return s.rt.enter(a_O5AchFA4DRQnkRWgtnAinrTT(s, a_KZbpL7uc1r4AX4wh124AoOXM$1, s.$board));
}
cs.registerStep(a_KZbpL7uc1r4AX4wh124AoOXM$0, 'a_KZbpL7uc1r4AX4wh124AoOXM$0');

function a_KZbpL7uc1r4AX4wh124AoOXM$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  s.rt.logObjectMutation(s.$coll);
  (ok2(s, s.$coll, t_actRes_0) && s.$coll.add(t_actRes_0, s));
  (s.pc = "0.77.70");
  var t_lmbv_1 = s.$max;
  var t_lmbv_2 = s.$coll;
  var t_lmbv_3 = s.$board;
  var t_lmbProxy_4 = s.libs.mkLambdaProxy;
  (s.$perform2 = function(la0, la1) { return a_a_KZbpL7uc1r4AX4wh124AoOXM$2(t_lmbProxy_4(la0), la1, t_lmbv_1, t_lmbv_2, t_lmbv_3) });
  (s.pc = "0.77.3");
  s.rt.logObjectMutation(null);
  var t_call_5 = (ok1(s, s.$perform2) && lib.Time.run_every(15, s.$perform2, s));
  t_call_5;
  return s.rt.leave();
}
cs.registerStep(a_KZbpL7uc1r4AX4wh124AoOXM$1, 'a_KZbpL7uc1r4AX4wh124AoOXM$1');

/* ACTION: a_KZbpL7uc1r4AX4wh124AoOXM::lambda::2 */
function a_a_KZbpL7uc1r4AX4wh124AoOXM$2(previous, returnAddr, $max, $coll, $board) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_KZbpL7uc1r4AX4wh124AoOXM$2$0;
  s.name = "fire bullets";
  s.$max = $max;
  s.$coll = $coll;
  s.$board = $board;
  s.$i = undefined;
  return s;
}
cs.registerLambda("a_KZbpL7uc1r4AX4wh124AoOXM\u003a\u003alambda\u003a\u003a2", "a_KZbpL7uc1r4AX4wh124AoOXM$2", a_a_KZbpL7uc1r4AX4wh124AoOXM$2, true);

function a_a_KZbpL7uc1r4AX4wh124AoOXM$2$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.77.720");
  var t_infix_1 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI < 1000));
  ok1(s, t_infix_1);
  if (t_infix_1) {
  (s.pc = "0.77.7240");
  s.t_bnd_2 = s.$max;
  (s.$i = 0);
  return a_a_KZbpL7uc1r4AX4wh124AoOXM$2$2;
  } else {
  (s.pc = "0.77.7250");
  null;
  }
  return a_a_KZbpL7uc1r4AX4wh124AoOXM$2$1;
}
cs.registerStep(a_a_KZbpL7uc1r4AX4wh124AoOXM$2$0, 'a_a_KZbpL7uc1r4AX4wh124AoOXM$2$0');

function a_a_KZbpL7uc1r4AX4wh124AoOXM$2$2(s) {
  if ((s.$i < s.t_bnd_2)) {
  (s.pc = "0.77.72440");
  return s.rt.enter(a_O5AchFA4DRQnkRWgtnAinrTT(s, a_a_KZbpL7uc1r4AX4wh124AoOXM$2$4, s.$board));
  }
  return a_a_KZbpL7uc1r4AX4wh124AoOXM$2$1;
}
cs.registerStep(a_a_KZbpL7uc1r4AX4wh124AoOXM$2$2, 'a_a_KZbpL7uc1r4AX4wh124AoOXM$2$2');

function a_a_KZbpL7uc1r4AX4wh124AoOXM$2$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_KZbpL7uc1r4AX4wh124AoOXM$2$1, 'a_a_KZbpL7uc1r4AX4wh124AoOXM$2$1');

function a_a_KZbpL7uc1r4AX4wh124AoOXM$2$4(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  s.rt.logObjectMutation(s.$coll);
  (ok2(s, s.$coll, t_actRes_3) && s.$coll.add(t_actRes_3, s));
  (s.$i++);
  return a_a_KZbpL7uc1r4AX4wh124AoOXM$2$2;
}
cs.registerStep(a_a_KZbpL7uc1r4AX4wh124AoOXM$2$4, 'a_a_KZbpL7uc1r4AX4wh124AoOXM$2$4');

cs.registerArtResource("Picture", "$d6EZHojvh2Vq4REKUh1JZHq6", ".\u002fart\u002f$0$$d6EZHojvh2Vq4REKUh1JZHq6");

//Ent_xqFaS9qU87n5kVZ81LVFbo7X
function Ent_xqFaS9qU87n5kVZ81LVFbo7X(p) {
  this.parent = p;
}
Ent_xqFaS9qU87n5kVZ81LVFbo7X.prototype = new lib.ObjectEntry();
Ent_xqFaS9qU87n5kVZ81LVFbo7X.prototype.keys = [];
Ent_xqFaS9qU87n5kVZ81LVFbo7X.prototype.values = ["xzZJpP2kJ4IH9SEn4x3nLkB0", "PiZCLngwIIagl2tCtwr0HSYq", "lJyX3x1vsRbnw9eQxKh9siXM"];
Ent_xqFaS9qU87n5kVZ81LVFbo7X.prototype.fields = ["xzZJpP2kJ4IH9SEn4x3nLkB0", "PiZCLngwIIagl2tCtwr0HSYq", "lJyX3x1vsRbnw9eQxKh9siXM"];
Ent_xqFaS9qU87n5kVZ81LVFbo7X.prototype.xzZJpP2kJ4IH9SEn4x3nLkB0_realname = "bomb";
Ent_xqFaS9qU87n5kVZ81LVFbo7X.prototype.PiZCLngwIIagl2tCtwr0HSYq_realname = "hp";
Ent_xqFaS9qU87n5kVZ81LVFbo7X.prototype.lJyX3x1vsRbnw9eQxKh9siXM_realname = "timer";
Ent_xqFaS9qU87n5kVZ81LVFbo7X.prototype.PiZCLngwIIagl2tCtwr0HSYq = 0;
//Col_xqFaS9qU87n5kVZ81LVFbo7X
function Col_xqFaS9qU87n5kVZ81LVFbo7X(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_xqFaS9qU87n5kVZ81LVFbo7X.prototype = lib.RecordCollection.prototype;
//Tbl_xqFaS9qU87n5kVZ81LVFbo7X
function Tbl_xqFaS9qU87n5kVZ81LVFbo7X(l) {
  this.libName = l;
  this.initParent();
}
Tbl_xqFaS9qU87n5kVZ81LVFbo7X.prototype = new lib.ObjectSingleton();
Tbl_xqFaS9qU87n5kVZ81LVFbo7X.prototype.entryCtor = Ent_xqFaS9qU87n5kVZ81LVFbo7X;
Tbl_xqFaS9qU87n5kVZ81LVFbo7X.prototype.selfCtor = Tbl_xqFaS9qU87n5kVZ81LVFbo7X;
Tbl_xqFaS9qU87n5kVZ81LVFbo7X.prototype.collectionCtor = Col_xqFaS9qU87n5kVZ81LVFbo7X;
Tbl_xqFaS9qU87n5kVZ81LVFbo7X.prototype.stableName = "xqFaS9qU87n5kVZ81LVFbo7X";
Tbl_xqFaS9qU87n5kVZ81LVFbo7X.prototype.entryKindName = "bomb";

// jsonimport
Ent_xqFaS9qU87n5kVZ81LVFbo7X.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("PiZCLngwIIagl2tCtwr0HSYq", ctx.importNumber(json, "hp"), s);
}
cs.registerGlobal("$xqFaS9qU87n5kVZ81LVFbo7X");
/* ACTION: initialize bomb */
function a_eIR6TRDiRMEv9ZPjCFNFeOXU(previous, returnAddr, $hp, $board) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_eIR6TRDiRMEv9ZPjCFNFeOXU$0;
  s.name = "initialize bomb";
  s.$hp = $hp;
  s.$board = $board;
  s.result = undefined;
  s.$bomb = undefined;
  s.$bomb2 = undefined;
  s.$perform = undefined;
  return s;
}
cs.registerAction("initialize bomb", "eIR6TRDiRMEv9ZPjCFNFeOXU", a_eIR6TRDiRMEv9ZPjCFNFeOXU, true);

function a_eIR6TRDiRMEv9ZPjCFNFeOXU$0(s) {
  (s.pc = "0.84.0");
  var t_resumeCtx_0 = s.rt.getBlockingResumeCtx(a_eIR6TRDiRMEv9ZPjCFNFeOXU$1);
  var t_call_1 = (ok2(s, s.$board, /* joker bomb */ s.d.$d6EZHojvh2Vq4REKUh1JZHq6) && s.$board.create_picture(/* joker bomb */ s.d.$d6EZHojvh2Vq4REKUh1JZHq6, t_resumeCtx_0));
  return a_eIR6TRDiRMEv9ZPjCFNFeOXU$1;
}
cs.registerStep(a_eIR6TRDiRMEv9ZPjCFNFeOXU$0, 'a_eIR6TRDiRMEv9ZPjCFNFeOXU$0');

function a_eIR6TRDiRMEv9ZPjCFNFeOXU$1(s) {
  var t_pauseRes_2 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_2);
  (s.$bomb = t_pauseRes_2);
  (s.pc = "0.84.3");
  s.rt.logObjectMutation(s.$bomb);
  (ok1(s, s.$bomb) && s.$bomb.set_width(200, s));
  (s.pc = "0.84.6");
  var t_call_3 = (ok1(s, /* bomb */ s.d.$xqFaS9qU87n5kVZ81LVFbo7X) && /* bomb */ s.d.$xqFaS9qU87n5kVZ81LVFbo7X.create(s));
  s.rt.markAllocated(t_call_3);
  (s.$bomb2 = t_call_3);
  (s.pc = "0.84.d0");
  var t_lmbv_4 = s.$bomb2;
  var t_lmbProxy_5 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_eIR6TRDiRMEv9ZPjCFNFeOXU$2(t_lmbProxy_5(la0), la1, t_lmbv_4) });
  (s.pc = "0.84.9");
  var t_call_6 = lib.Math_.random_range(10, 20, s);
  s.rt.logObjectMutation(null);
  var t_call_7 = (ok2(s, t_call_6, s.$perform) && lib.Time.run_after(t_call_6, s.$perform, s));
  if (s.$bomb2) {
  s.$bomb2.perform_set("lJyX3x1vsRbnw9eQxKh9siXM", t_call_7, s);
  }
  (s.pc = "0.84.d");
  if (s.$bomb2) {
  s.$bomb2.perform_set("xzZJpP2kJ4IH9SEn4x3nLkB0", s.$bomb, s);
  }
  (s.pc = "0.84.g");
  if (s.$bomb2) {
  s.$bomb2.perform_set("PiZCLngwIIagl2tCtwr0HSYq", s.$hp, s);
  }
  (s.pc = "0.84.j");
  if (s.$bomb2) {
  var t_recOp_8 = s.$bomb2[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  s.rt.logObjectMutation(t_recOp_8);
  (ok1(s, t_recOp_8) && t_recOp_8.set_speed_y(200, s));
  (s.pc = "0.84.m");
  if (s.$bomb2) {
  var t_recOp_9 = s.$bomb2[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  var t_call_10 = (ok1(s, s.$board) && s.$board.width(s));
  var t_call_11 = (ok1(s, t_call_10) && lib.Math_.random(t_call_10, s));
  s.rt.logObjectMutation(t_recOp_9);
  (ok2(s, t_recOp_9, t_call_11) && t_recOp_9.set_x(t_call_11, s));
  (s.pc = "0.84.p");
  if (s.$bomb2) {
  var t_recOp_12 = s.$bomb2[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  var t_infix_13 = (0 - 1);
  var t_infix_14 = (0 - 5000);
  var t_call_15 = (ok2(s, t_infix_13, t_infix_14) && lib.Math_.random_range(t_infix_13, t_infix_14, s));
  s.rt.logObjectMutation(t_recOp_12);
  (ok2(s, t_recOp_12, t_call_15) && t_recOp_12.set_y(t_call_15, s));
  (s.pc = "0.84.s");
  (s.result = s.$bomb2);
  return s.rt.leave();
}
cs.registerStep(a_eIR6TRDiRMEv9ZPjCFNFeOXU$1, 'a_eIR6TRDiRMEv9ZPjCFNFeOXU$1');

/* ACTION: a_eIR6TRDiRMEv9ZPjCFNFeOXU::lambda::2 */
function a_a_eIR6TRDiRMEv9ZPjCFNFeOXU$2(previous, returnAddr, $bomb2) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_eIR6TRDiRMEv9ZPjCFNFeOXU$2$0;
  s.name = "initialize bomb";
  s.$bomb2 = $bomb2;
  return s;
}
cs.registerLambda("a_eIR6TRDiRMEv9ZPjCFNFeOXU\u003a\u003alambda\u003a\u003a2", "a_eIR6TRDiRMEv9ZPjCFNFeOXU$2", a_a_eIR6TRDiRMEv9ZPjCFNFeOXU$2, true);

function a_a_eIR6TRDiRMEv9ZPjCFNFeOXU$2$0(s) {
  (s.pc = "0.84.d20");
  if (s.$bomb2) {
  var t_recOp_0 = s.$bomb2[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  if (s.$bomb2) {
  var t_recOp_1 = s.$bomb2[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  var t_call_2 = (ok1(s, t_recOp_1) && t_recOp_1.width(s));
  var t_infix_3 = (ok1(s, t_call_2) && (t_call_2 * 2));
  s.rt.logObjectMutation(t_recOp_0);
  (ok2(s, t_recOp_0, t_infix_3) && t_recOp_0.set_width(t_infix_3, s));
  return s.rt.leave();
}
cs.registerStep(a_a_eIR6TRDiRMEv9ZPjCFNFeOXU$2$0, 'a_a_eIR6TRDiRMEv9ZPjCFNFeOXU$2$0');

/* ACTION: drop bomb */
function a_IWEtJXU6WLOVw6Qb4RcaH63o(previous, returnAddr, $board, $coll, $max) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_IWEtJXU6WLOVw6Qb4RcaH63o$0;
  s.name = "drop bomb";
  s.$board = $board;
  s.$coll = $coll;
  s.$max = $max;
  s.$perform2 = undefined;
  s.$i = undefined;
  return s;
}
cs.registerAction("drop bomb", "IWEtJXU6WLOVw6Qb4RcaH63o", a_IWEtJXU6WLOVw6Qb4RcaH63o, true);

function a_IWEtJXU6WLOVw6Qb4RcaH63o$0(s) {
  (s.pc = "0.89.40");
  var t_lmbv_0 = s.$max;
  var t_lmbv_1 = s.$coll;
  var t_lmbv_2 = s.$board;
  var t_lmbProxy_3 = s.libs.mkLambdaProxy;
  (s.$perform2 = function(la0, la1) { return a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1(t_lmbProxy_3(la0), la1, t_lmbv_0, t_lmbv_1, t_lmbv_2) });
  (s.pc = "0.89.0");
  s.rt.logObjectMutation(null);
  var t_call_4 = (ok1(s, s.$perform2) && lib.Time.run_every(45, s.$perform2, s));
  t_call_4;
  return s.rt.leave();
}
cs.registerStep(a_IWEtJXU6WLOVw6Qb4RcaH63o$0, 'a_IWEtJXU6WLOVw6Qb4RcaH63o$0');

/* ACTION: a_IWEtJXU6WLOVw6Qb4RcaH63o::lambda::1 */
function a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1(previous, returnAddr, $max, $coll, $board) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$0;
  s.name = "drop bomb";
  s.$max = $max;
  s.$coll = $coll;
  s.$board = $board;
  s.$i = undefined;
  return s;
}
cs.registerLambda("a_IWEtJXU6WLOVw6Qb4RcaH63o\u003a\u003alambda\u003a\u003a1", "a_IWEtJXU6WLOVw6Qb4RcaH63o$1", a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1, true);

function a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.89.420");
  var t_infix_1 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI <= 1000));
  ok1(s, t_infix_1);
  if (t_infix_1) {
  (s.pc = "0.89.4240");
  s.t_bnd_2 = s.$max;
  (s.$i = 0);
  return a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$2;
  } else {
  (s.pc = "0.89.4250");
  null;
  }
  return a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$1;
}
cs.registerStep(a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$0, 'a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$0');

function a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$2(s) {
  if ((s.$i < s.t_bnd_2)) {
  (s.pc = "0.89.42440");
  return s.rt.enter(a_eIR6TRDiRMEv9ZPjCFNFeOXU(s, a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$4, 3, s.$board));
  }
  return a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$1;
}
cs.registerStep(a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$2, 'a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$2');

function a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$1, 'a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$1');

function a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$4(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  s.rt.logObjectMutation(s.$coll);
  (ok2(s, s.$coll, t_actRes_3) && s.$coll.add(t_actRes_3, s));
  (s.$i++);
  return a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$2;
}
cs.registerStep(a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$4, 'a_a_IWEtJXU6WLOVw6Qb4RcaH63o$1$4');

/* ACTION: drop life */
function a_jwzHZLACN8twZy3ltoyz6Mj2(previous, returnAddr, $life, $board, $coll) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_jwzHZLACN8twZy3ltoyz6Mj2$0;
  s.name = "drop life";
  s.$life = $life;
  s.$board = $board;
  s.$coll = $coll;
  return s;
}
cs.registerAction("drop life", "jwzHZLACN8twZy3ltoyz6Mj2", a_jwzHZLACN8twZy3ltoyz6Mj2, true);

function a_jwzHZLACN8twZy3ltoyz6Mj2$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.95.0");
  var t_libcall_1 = s.libs["game"]["score"](s);
  return s.rt.enter(t_libcall_1.invoke(t_libcall_1, a_jwzHZLACN8twZy3ltoyz6Mj2$1));
}
cs.registerStep(a_jwzHZLACN8twZy3ltoyz6Mj2$0, 'a_jwzHZLACN8twZy3ltoyz6Mj2$0');

function a_jwzHZLACN8twZy3ltoyz6Mj2$1(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  var t_infix_3 = (ok2(s, t_actRes_2, /* lifen */ s.d.$avoUwZDw7D0WKejA4Jr9PbAX) && (t_actRes_2 >= /* lifen */ s.d.$avoUwZDw7D0WKejA4Jr9PbAX));
  ok1(s, t_infix_3);
  if (t_infix_3) {
  var t_elseIf_4 = true;
  (s.pc = "0.95.40");
  var t_call_5 = (ok1(s, /* lifeb */ s.d.$xqFpkxfy7q3EOvlgPho5S2K2) && lib.Boolean_.equals(/* lifeb */ s.d.$xqFpkxfy7q3EOvlgPho5S2K2, true, s));
  ok1(s, t_call_5);
  if (t_call_5) {
  (s.pc = "0.95.440");
  (/* lifeb */ s.d.$xqFpkxfy7q3EOvlgPho5S2K2 = false);
  s.rt.logDataWrite();
  (s.pc = "0.95.443");
  var t_infix_6 = (ok1(s, /* lifen */ s.d.$avoUwZDw7D0WKejA4Jr9PbAX) && (/* lifen */ s.d.$avoUwZDw7D0WKejA4Jr9PbAX + 50));
  (/* lifen */ s.d.$avoUwZDw7D0WKejA4Jr9PbAX = t_infix_6);
  s.rt.logDataWrite();
  (s.pc = "0.95.446");
  return s.rt.enter(a_xXyuTSkrzYHeFtYyv7q2ZmT6(s, a_jwzHZLACN8twZy3ltoyz6Mj2$4, s.$life, s.$board));
  } else {
  (s.pc = "0.95.450");
  null;
  }
  return a_jwzHZLACN8twZy3ltoyz6Mj2$3;
  } else {
  (s.pc = "0.95.50");
  (/* lifeb */ s.d.$xqFpkxfy7q3EOvlgPho5S2K2 = true);
  s.rt.logDataWrite();
  }
  return a_jwzHZLACN8twZy3ltoyz6Mj2$2;
}
cs.registerStep(a_jwzHZLACN8twZy3ltoyz6Mj2$1, 'a_jwzHZLACN8twZy3ltoyz6Mj2$1');

function a_jwzHZLACN8twZy3ltoyz6Mj2$4(s) {
  var t_actRes_7 = s.rt.returnedFrom.result;
  s.rt.logObjectMutation(s.$coll);
  (ok2(s, s.$coll, t_actRes_7) && s.$coll.add(t_actRes_7, s));
  return a_jwzHZLACN8twZy3ltoyz6Mj2$3;
}
cs.registerStep(a_jwzHZLACN8twZy3ltoyz6Mj2$4, 'a_jwzHZLACN8twZy3ltoyz6Mj2$4');

function a_jwzHZLACN8twZy3ltoyz6Mj2$3(s) {
  return a_jwzHZLACN8twZy3ltoyz6Mj2$2;
}
cs.registerStep(a_jwzHZLACN8twZy3ltoyz6Mj2$3, 'a_jwzHZLACN8twZy3ltoyz6Mj2$3');

function a_jwzHZLACN8twZy3ltoyz6Mj2$2(s) {
  return s.rt.leave();
}
cs.registerStep(a_jwzHZLACN8twZy3ltoyz6Mj2$2, 'a_jwzHZLACN8twZy3ltoyz6Mj2$2');

/* ACTION: remove bomb */
function a_fz2d5loZTMTcwMAIWG5r2ULG(previous, returnAddr, $heroattack, $bomb) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_fz2d5loZTMTcwMAIWG5r2ULG$0;
  s.name = "remove bomb";
  s.$heroattack = $heroattack;
  s.$bomb = $bomb;
  s.$bomb2 = undefined;
  s.$explosion = undefined;
  s.$b2 = undefined;
  return s;
}
cs.registerAction("remove bomb", "fz2d5loZTMTcwMAIWG5r2ULG", a_fz2d5loZTMTcwMAIWG5r2ULG, true);

function a_fz2d5loZTMTcwMAIWG5r2ULG$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.100.0");
  true;
  if ((s.$bomb == undefined)) {
  (s.pc = "0.100.40");
  null;
  } else {
  (s.pc = "0.100.50");
  s.t_collArr_1 = (ok1(s, s.$bomb) && s.$bomb.get_enumerator());
  s.t_idx_2 = 0;
  return a_fz2d5loZTMTcwMAIWG5r2ULG$2;
  }
  return a_fz2d5loZTMTcwMAIWG5r2ULG$1;
}
cs.registerStep(a_fz2d5loZTMTcwMAIWG5r2ULG$0, 'a_fz2d5loZTMTcwMAIWG5r2ULG$0');

function a_fz2d5loZTMTcwMAIWG5r2ULG$2(s) {
  if ((s.t_idx_2 < (s.t_collArr_1.length))) {
  (s.$bomb2 = s.t_collArr_1[(s.t_idx_2)]);
  (s.t_idx_2++);
  if (s.$bomb2) {
  var t_recOp_3 = s.$bomb2[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  var t_call_4 = (ok2(s, s.$heroattack, t_recOp_3) && s.$heroattack.overlaps_with(t_recOp_3, s));
  if (t_call_4) {
  var t_elseIf_5 = true;
  (s.pc = "0.100.550");
  var t_call_6 = (ok1(s, s.$heroattack) && s.$heroattack.is_visible(s));
  ok1(s, t_call_6);
  if (t_call_6) {
  (s.pc = "0.100.5540");
  if (s.$bomb2) {
  var t_recOp_7 = s.$bomb2[("PiZCLngwIIagl2tCtwr0HSYq")];
  }
  var t_infix_8 = (ok1(s, t_recOp_7) && (t_recOp_7 - 1));
  if (s.$bomb2) {
  s.$bomb2.perform_set("PiZCLngwIIagl2tCtwr0HSYq", t_infix_8, s);
  }
  var t_elseIf_9 = true;
  (s.pc = "0.100.5543");
  if (s.$bomb2) {
  var t_recOp_10 = s.$bomb2[("PiZCLngwIIagl2tCtwr0HSYq")];
  }
  var t_infix_11 = (ok1(s, t_recOp_10) && (t_recOp_10 === 0));
  ok1(s, t_infix_11);
  if (t_infix_11) {
  (s.pc = "0.100.55470");
  var t_libcall_12 = s.libs["game"]["add score"](s);
  return s.rt.enter(t_libcall_12.invoke(t_libcall_12, a_fz2d5loZTMTcwMAIWG5r2ULG$11, 25));
  } else {
  (s.pc = "0.100.55480");
  null;
  }
  return a_fz2d5loZTMTcwMAIWG5r2ULG$10;
  } else {
  (s.pc = "0.100.5550");
  null;
  }
  return a_fz2d5loZTMTcwMAIWG5r2ULG$6;
  }
  return a_fz2d5loZTMTcwMAIWG5r2ULG$4;
  }
  return a_fz2d5loZTMTcwMAIWG5r2ULG$1;
}
cs.registerStep(a_fz2d5loZTMTcwMAIWG5r2ULG$2, 'a_fz2d5loZTMTcwMAIWG5r2ULG$2');

function a_fz2d5loZTMTcwMAIWG5r2ULG$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_fz2d5loZTMTcwMAIWG5r2ULG$1, 'a_fz2d5loZTMTcwMAIWG5r2ULG$1');

function a_fz2d5loZTMTcwMAIWG5r2ULG$11(s) {
  (s.pc = "0.100.55473");
  var t_libcall_13 = s.libs["olZOoTBBwZaQT3B4fbkU2Y2c"]["create animation"](s);
  return s.rt.enter(t_libcall_13.invoke(t_libcall_13, a_fz2d5loZTMTcwMAIWG5r2ULG$12, "explode", 1, 1, 1, 1, 4, 5));
}
cs.registerStep(a_fz2d5loZTMTcwMAIWG5r2ULG$11, 'a_fz2d5loZTMTcwMAIWG5r2ULG$11');

function a_fz2d5loZTMTcwMAIWG5r2ULG$10(s) {
  return a_fz2d5loZTMTcwMAIWG5r2ULG$6;
}
cs.registerStep(a_fz2d5loZTMTcwMAIWG5r2ULG$10, 'a_fz2d5loZTMTcwMAIWG5r2ULG$10');

function a_fz2d5loZTMTcwMAIWG5r2ULG$6(s) {
  return a_fz2d5loZTMTcwMAIWG5r2ULG$4;
}
cs.registerStep(a_fz2d5loZTMTcwMAIWG5r2ULG$6, 'a_fz2d5loZTMTcwMAIWG5r2ULG$6');

function a_fz2d5loZTMTcwMAIWG5r2ULG$4(s) {
  return a_fz2d5loZTMTcwMAIWG5r2ULG$2;
}
cs.registerStep(a_fz2d5loZTMTcwMAIWG5r2ULG$4, 'a_fz2d5loZTMTcwMAIWG5r2ULG$4');

function a_fz2d5loZTMTcwMAIWG5r2ULG$12(s) {
  var t_actRes_14 = s.rt.returnedFrom.result;
  (s.$explosion = t_actRes_14);
  (s.pc = "0.100.55476");
  if (s.$bomb2) {
  var t_recOp_15 = s.$bomb2[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  var t_call_16 = (ok1(s, t_recOp_15) && t_recOp_15.x(s));
  if (s.$bomb2) {
  var t_recOp_17 = s.$bomb2[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  var t_call_18 = (ok1(s, t_recOp_17) && t_recOp_17.y(s));
  s.rt.logObjectMutation(s.$explosion);
  (ok3(s, s.$explosion, t_call_16, t_call_18) && s.$explosion.set_pos(t_call_16, t_call_18, s));
  (s.pc = "0.100.55479");
  if (s.$bomb2) {
  var t_recOp_19 = s.$bomb2[("xzZJpP2kJ4IH9SEn4x3nLkB0")];
  }
  s.rt.logObjectMutation(t_recOp_19);
  (ok1(s, t_recOp_19) && t_recOp_19.delete_(s));
  (s.pc = "0.100.5547c");
  s.rt.logObjectMutation(s.$bomb);
  var t_call_20 = (ok2(s, s.$bomb, s.$bomb2) && s.$bomb.remove(s.$bomb2, s));
  (s.$b2 = t_call_20);
  return a_fz2d5loZTMTcwMAIWG5r2ULG$10;
}
cs.registerStep(a_fz2d5loZTMTcwMAIWG5r2ULG$12, 'a_fz2d5loZTMTcwMAIWG5r2ULG$12');


//Ent_lVcc2aDS6HhHBmwTa7kdaOop
function Ent_lVcc2aDS6HhHBmwTa7kdaOop(p) {
  this.parent = p;
}
Ent_lVcc2aDS6HhHBmwTa7kdaOop.prototype = new lib.ObjectEntry();
Ent_lVcc2aDS6HhHBmwTa7kdaOop.prototype.keys = [];
Ent_lVcc2aDS6HhHBmwTa7kdaOop.prototype.values = ["xNbZDhcxzZ5xttFiEIS5AU7y", "ZojQ13mdIh2vF4tadRK4tner"];
Ent_lVcc2aDS6HhHBmwTa7kdaOop.prototype.fields = ["xNbZDhcxzZ5xttFiEIS5AU7y", "ZojQ13mdIh2vF4tadRK4tner"];
Ent_lVcc2aDS6HhHBmwTa7kdaOop.prototype.xNbZDhcxzZ5xttFiEIS5AU7y_realname = "life";
Ent_lVcc2aDS6HhHBmwTa7kdaOop.prototype.ZojQ13mdIh2vF4tadRK4tner_realname = "amount";
Ent_lVcc2aDS6HhHBmwTa7kdaOop.prototype.ZojQ13mdIh2vF4tadRK4tner = 0;
//Col_lVcc2aDS6HhHBmwTa7kdaOop
function Col_lVcc2aDS6HhHBmwTa7kdaOop(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_lVcc2aDS6HhHBmwTa7kdaOop.prototype = lib.RecordCollection.prototype;
//Tbl_lVcc2aDS6HhHBmwTa7kdaOop
function Tbl_lVcc2aDS6HhHBmwTa7kdaOop(l) {
  this.libName = l;
  this.initParent();
}
Tbl_lVcc2aDS6HhHBmwTa7kdaOop.prototype = new lib.ObjectSingleton();
Tbl_lVcc2aDS6HhHBmwTa7kdaOop.prototype.entryCtor = Ent_lVcc2aDS6HhHBmwTa7kdaOop;
Tbl_lVcc2aDS6HhHBmwTa7kdaOop.prototype.selfCtor = Tbl_lVcc2aDS6HhHBmwTa7kdaOop;
Tbl_lVcc2aDS6HhHBmwTa7kdaOop.prototype.collectionCtor = Col_lVcc2aDS6HhHBmwTa7kdaOop;
Tbl_lVcc2aDS6HhHBmwTa7kdaOop.prototype.stableName = "lVcc2aDS6HhHBmwTa7kdaOop";
Tbl_lVcc2aDS6HhHBmwTa7kdaOop.prototype.entryKindName = "life";

// jsonimport
Ent_lVcc2aDS6HhHBmwTa7kdaOop.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("ZojQ13mdIh2vF4tadRK4tner", ctx.importNumber(json, "amount"), s);
}
cs.registerGlobal("$lVcc2aDS6HhHBmwTa7kdaOop");
/* ACTION: initialize life */
function a_xXyuTSkrzYHeFtYyv7q2ZmT6(previous, returnAddr, $life, $board) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xXyuTSkrzYHeFtYyv7q2ZmT6$0;
  s.name = "initialize life";
  s.$life = $life;
  s.$board = $board;
  s.result = undefined;
  s.$life2 = undefined;
  return s;
}
cs.registerAction("initialize life", "xXyuTSkrzYHeFtYyv7q2ZmT6", a_xXyuTSkrzYHeFtYyv7q2ZmT6, true);

function a_xXyuTSkrzYHeFtYyv7q2ZmT6$0(s) {
  (s.pc = "0.106.0");
  var t_call_0 = (ok1(s, /* life */ s.d.$lVcc2aDS6HhHBmwTa7kdaOop) && /* life */ s.d.$lVcc2aDS6HhHBmwTa7kdaOop.create(s));
  s.rt.markAllocated(t_call_0);
  (s.$life2 = t_call_0);
  (s.pc = "0.106.3");
  if (s.$life2) {
  s.$life2.perform_set("ZojQ13mdIh2vF4tadRK4tner", s.$life, s);
  }
  (s.pc = "0.106.6");
  var t_resumeCtx_1 = s.rt.getBlockingResumeCtx(a_xXyuTSkrzYHeFtYyv7q2ZmT6$2);
  var t_call_2 = (ok2(s, s.$board, /* Heart */ s.d.$zDWvqF2S2aQhvxjnQFmYimVF) && s.$board.create_picture(/* Heart */ s.d.$zDWvqF2S2aQhvxjnQFmYimVF, t_resumeCtx_1));
  return a_xXyuTSkrzYHeFtYyv7q2ZmT6$2;
}
cs.registerStep(a_xXyuTSkrzYHeFtYyv7q2ZmT6$0, 'a_xXyuTSkrzYHeFtYyv7q2ZmT6$0');

function a_xXyuTSkrzYHeFtYyv7q2ZmT6$2(s) {
  var t_pauseRes_3 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_3);
  if (s.$life2) {
  s.$life2.perform_set("xNbZDhcxzZ5xttFiEIS5AU7y", t_pauseRes_3, s);
  }
  (s.pc = "0.106.9");
  if (s.$life2) {
  var t_recOp_4 = s.$life2[("xNbZDhcxzZ5xttFiEIS5AU7y")];
  }
  var t_call_5 = (ok1(s, s.$board) && s.$board.width(s));
  var t_call_6 = (ok1(s, t_call_5) && lib.Math_.random(t_call_5, s));
  var t_infix_7 = (0 - 1);
  s.rt.logObjectMutation(t_recOp_4);
  (ok3(s, t_recOp_4, t_call_6, t_infix_7) && t_recOp_4.set_pos(t_call_6, t_infix_7, s));
  (s.pc = "0.106.c");
  if (s.$life2) {
  var t_recOp_8 = s.$life2[("xNbZDhcxzZ5xttFiEIS5AU7y")];
  }
  s.rt.logObjectMutation(t_recOp_8);
  (ok1(s, t_recOp_8) && t_recOp_8.set_speed_y(100, s));
  (s.pc = "0.106.f");
  (s.result = s.$life2);
  return s.rt.leave();
}
cs.registerStep(a_xXyuTSkrzYHeFtYyv7q2ZmT6$2, 'a_xXyuTSkrzYHeFtYyv7q2ZmT6$2');

cs.registerArtResource("Picture", "$zDWvqF2S2aQhvxjnQFmYimVF", ".\u002fart\u002f$0$$zDWvqF2S2aQhvxjnQFmYimVF");
cs.registerArtResource("Picture", "$gIktcmxXlop1JFScyuuQFFRx", ".\u002fart\u002f$0$$gIktcmxXlop1JFScyuuQFFRx");
cs.registerArtResource("Picture", "$G4FSGH7QbiLfIRtkzNPKmHCW", ".\u002fart\u002f$0$$G4FSGH7QbiLfIRtkzNPKmHCW");
cs.registerArtResource("Picture", "$i7v2elsf8ywqFMSgiS4SNI6p", ".\u002fart\u002f$0$$i7v2elsf8ywqFMSgiS4SNI6p");

//Ent_GJTCTeAJoSwxOp22t9U9Qo5X
function Ent_GJTCTeAJoSwxOp22t9U9Qo5X(p) {
  this.parent = p;
}
Ent_GJTCTeAJoSwxOp22t9U9Qo5X.prototype = new lib.ObjectEntry();
Ent_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.keys = [];
Ent_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.values = ["xS8C4g0g3NyaN3dDHZaEsNCK", "TSykhSK5hfDy51K4IWMK2lik"];
Ent_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.fields = ["xS8C4g0g3NyaN3dDHZaEsNCK", "TSykhSK5hfDy51K4IWMK2lik"];
Ent_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.xS8C4g0g3NyaN3dDHZaEsNCK_realname = "laser";
Ent_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.TSykhSK5hfDy51K4IWMK2lik_realname = "hp";
Ent_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.TSykhSK5hfDy51K4IWMK2lik = 0;
//Col_GJTCTeAJoSwxOp22t9U9Qo5X
function Col_GJTCTeAJoSwxOp22t9U9Qo5X(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_GJTCTeAJoSwxOp22t9U9Qo5X.prototype = lib.RecordCollection.prototype;
//Tbl_GJTCTeAJoSwxOp22t9U9Qo5X
function Tbl_GJTCTeAJoSwxOp22t9U9Qo5X(l) {
  this.libName = l;
  this.initParent();
}
Tbl_GJTCTeAJoSwxOp22t9U9Qo5X.prototype = new lib.ObjectSingleton();
Tbl_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.entryCtor = Ent_GJTCTeAJoSwxOp22t9U9Qo5X;
Tbl_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.selfCtor = Tbl_GJTCTeAJoSwxOp22t9U9Qo5X;
Tbl_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.collectionCtor = Col_GJTCTeAJoSwxOp22t9U9Qo5X;
Tbl_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.stableName = "GJTCTeAJoSwxOp22t9U9Qo5X";
Tbl_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.entryKindName = "laser";

// jsonimport
Ent_GJTCTeAJoSwxOp22t9U9Qo5X.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("TSykhSK5hfDy51K4IWMK2lik", ctx.importNumber(json, "hp"), s);
}
cs.registerGlobal("$GJTCTeAJoSwxOp22t9U9Qo5X");
/* ACTION: initialize laser */
function a_aNGHYi5byTAQBlbtkLDZA5S2(previous, returnAddr, $board) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_aNGHYi5byTAQBlbtkLDZA5S2$0;
  s.name = "initialize laser";
  s.$board = $board;
  s.result = undefined;
  s.$sprite = undefined;
  s.$hp = undefined;
  s.$speed = undefined;
  s.$laser2 = undefined;
  return s;
}
cs.registerAction("initialize laser", "aNGHYi5byTAQBlbtkLDZA5S2", a_aNGHYi5byTAQBlbtkLDZA5S2, true);

function a_aNGHYi5byTAQBlbtkLDZA5S2$0(s) {
  (s.pc = "0.122.0");
  var t_resumeCtx_0 = s.rt.getBlockingResumeCtx(a_aNGHYi5byTAQBlbtkLDZA5S2$1);
  var t_call_1 = (ok2(s, s.$board, /* laser beam */ s.d.$T1Omna07YTEGvI7iuNKLN2wo) && s.$board.create_picture(/* laser beam */ s.d.$T1Omna07YTEGvI7iuNKLN2wo, t_resumeCtx_0));
  return a_aNGHYi5byTAQBlbtkLDZA5S2$1;
}
cs.registerStep(a_aNGHYi5byTAQBlbtkLDZA5S2$0, 'a_aNGHYi5byTAQBlbtkLDZA5S2$0');

function a_aNGHYi5byTAQBlbtkLDZA5S2$1(s) {
  var t_pauseRes_2 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_2);
  (s.$sprite = t_pauseRes_2);
  (s.pc = "0.122.3");
  (s.$hp = 10);
  (s.pc = "0.122.6");
  var t_call_3 = lib.Math_.random_range(200, 500, s);
  (s.$speed = t_call_3);
  (s.pc = "0.122.9");
  var t_call_4 = (ok1(s, /* laser */ s.d.$GJTCTeAJoSwxOp22t9U9Qo5X) && /* laser */ s.d.$GJTCTeAJoSwxOp22t9U9Qo5X.create(s));
  s.rt.markAllocated(t_call_4);
  (s.$laser2 = t_call_4);
  (s.pc = "0.122.c");
  if (s.$laser2) {
  s.$laser2.perform_set("xS8C4g0g3NyaN3dDHZaEsNCK", s.$sprite, s);
  }
  (s.pc = "0.122.f");
  if (s.$laser2) {
  s.$laser2.perform_set("TSykhSK5hfDy51K4IWMK2lik", s.$hp, s);
  }
  (s.pc = "0.122.i");
  if (s.$laser2) {
  var t_recOp_5 = s.$laser2[("xS8C4g0g3NyaN3dDHZaEsNCK")];
  }
  s.rt.logObjectMutation(t_recOp_5);
  (ok2(s, t_recOp_5, s.$speed) && t_recOp_5.set_speed_y(s.$speed, s));
  (s.pc = "0.122.l");
  if (s.$laser2) {
  var t_recOp_6 = s.$laser2[("xS8C4g0g3NyaN3dDHZaEsNCK")];
  }
  s.rt.logObjectMutation(t_recOp_6);
  (ok2(s, t_recOp_6, s.$speed) && t_recOp_6.set_speed_x(s.$speed, s));
  (s.pc = "0.122.o");
  if (s.$laser2) {
  var t_recOp_7 = s.$laser2[("xS8C4g0g3NyaN3dDHZaEsNCK")];
  }
  var t_call_8 = (ok1(s, s.$board) && s.$board.width(s));
  var t_call_9 = (ok1(s, t_call_8) && lib.Math_.random(t_call_8, s));
  s.rt.logObjectMutation(t_recOp_7);
  (ok2(s, t_recOp_7, t_call_9) && t_recOp_7.set_x(t_call_9, s));
  (s.pc = "0.122.r");
  if (s.$laser2) {
  var t_recOp_10 = s.$laser2[("xS8C4g0g3NyaN3dDHZaEsNCK")];
  }
  var t_infix_11 = (0 - 1);
  s.rt.logObjectMutation(t_recOp_10);
  (ok2(s, t_recOp_10, t_infix_11) && t_recOp_10.set_y(t_infix_11, s));
  (s.pc = "0.122.u");
  (s.result = s.$laser2);
  return s.rt.leave();
}
cs.registerStep(a_aNGHYi5byTAQBlbtkLDZA5S2$1, 'a_aNGHYi5byTAQBlbtkLDZA5S2$1');

cs.registerArtResource("Picture", "$T1Omna07YTEGvI7iuNKLN2wo", ".\u002fart\u002f$0$$T1Omna07YTEGvI7iuNKLN2wo");
/* ACTION: fire laser */
function a_yyNxrvidtxzb9mFtB3yTqY4E(previous, returnAddr, $board, $coll) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_yyNxrvidtxzb9mFtB3yTqY4E$0;
  s.name = "fire laser";
  s.$board = $board;
  s.$coll = $coll;
  s.$perform2 = undefined;
  s.$perform = undefined;
  return s;
}
cs.registerAction("fire laser", "yyNxrvidtxzb9mFtB3yTqY4E", a_yyNxrvidtxzb9mFtB3yTqY4E, true);

function a_yyNxrvidtxzb9mFtB3yTqY4E$0(s) {
  (s.pc = "0.128.40");
  var t_lmbv_0 = s.$coll;
  var t_lmbv_1 = s.$board;
  var t_lmbProxy_2 = s.libs.mkLambdaProxy;
  (s.$perform2 = function(la0, la1) { return a_a_yyNxrvidtxzb9mFtB3yTqY4E$1(t_lmbProxy_2(la0), la1, t_lmbv_0, t_lmbv_1) });
  (s.pc = "0.128.0");
  s.rt.logObjectMutation(null);
  var t_call_3 = (ok1(s, s.$perform2) && lib.Time.run_every(5, s.$perform2, s));
  t_call_3;
  (s.pc = "0.128.80");
  var t_lmbv_4 = s.$coll;
  var t_lmbProxy_5 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_yyNxrvidtxzb9mFtB3yTqY4E$2(t_lmbProxy_5(la0), la1, t_lmbv_4) });
  (s.pc = "0.128.4");
  s.rt.logObjectMutation(null);
  var t_call_6 = (ok1(s, s.$perform) && lib.Time.run_every(20, s.$perform, s));
  t_call_6;
  return s.rt.leave();
}
cs.registerStep(a_yyNxrvidtxzb9mFtB3yTqY4E$0, 'a_yyNxrvidtxzb9mFtB3yTqY4E$0');

/* ACTION: a_yyNxrvidtxzb9mFtB3yTqY4E::lambda::1 */
function a_a_yyNxrvidtxzb9mFtB3yTqY4E$1(previous, returnAddr, $coll, $board) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$0;
  s.name = "fire laser";
  s.$coll = $coll;
  s.$board = $board;
  return s;
}
cs.registerLambda("a_yyNxrvidtxzb9mFtB3yTqY4E\u003a\u003alambda\u003a\u003a1", "a_yyNxrvidtxzb9mFtB3yTqY4E$1", a_a_yyNxrvidtxzb9mFtB3yTqY4E$1, true);

function a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.128.420");
  var t_infix_1 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI >= 1000));
  ok1(s, t_infix_1);
  if (t_infix_1) {
  (s.pc = "0.128.4240");
  return s.rt.enter(a_aNGHYi5byTAQBlbtkLDZA5S2(s, a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$2, s.$board));
  } else {
  (s.pc = "0.128.4250");
  null;
  }
  return a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$1;
}
cs.registerStep(a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$0, 'a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$0');

function a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$2(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  s.rt.logObjectMutation(s.$coll);
  (ok2(s, s.$coll, t_actRes_2) && s.$coll.add(t_actRes_2, s));
  return a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$1;
}
cs.registerStep(a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$2, 'a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$2');

function a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$1, 'a_a_yyNxrvidtxzb9mFtB3yTqY4E$1$1');

/* ACTION: a_yyNxrvidtxzb9mFtB3yTqY4E::lambda::2 */
function a_a_yyNxrvidtxzb9mFtB3yTqY4E$2(previous, returnAddr, $coll) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_yyNxrvidtxzb9mFtB3yTqY4E$2$0;
  s.name = "fire laser";
  s.$coll = $coll;
  return s;
}
cs.registerLambda("a_yyNxrvidtxzb9mFtB3yTqY4E\u003a\u003alambda\u003a\u003a2", "a_yyNxrvidtxzb9mFtB3yTqY4E$2", a_a_yyNxrvidtxzb9mFtB3yTqY4E$2, true);

function a_a_yyNxrvidtxzb9mFtB3yTqY4E$2$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.128.820");
  var t_infix_1 = (ok1(s, /* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI) && (/* height */ s.d.$x5hWFGs51yTj5CZzqeGcoePI >= 1000));
  ok1(s, t_infix_1);
  if (t_infix_1) {
  var t_elseIf_2 = true;
  (s.pc = "0.128.8240");
  true;
  if ((s.$coll == undefined)) {
  (s.pc = "0.128.82440");
  null;
  } else {
  (s.pc = "0.128.82450");
  var t_call_3 = (ok1(s, s.$coll) && s.$coll.at(0, s));
  if (t_call_3) {
  var t_recOp_4 = t_call_3[("xS8C4g0g3NyaN3dDHZaEsNCK")];
  }
  s.rt.logObjectMutation(t_recOp_4);
  (ok1(s, t_recOp_4) && t_recOp_4.delete_(s));
  (s.pc = "0.128.82453");
  s.rt.logObjectMutation(s.$coll);
  (ok1(s, s.$coll) && s.$coll.remove_at(0, s));
  }
  } else {
  (s.pc = "0.128.8250");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_a_yyNxrvidtxzb9mFtB3yTqY4E$2$0, 'a_a_yyNxrvidtxzb9mFtB3yTqY4E$2$0');

/* ACTION: final boss */
function a_m765qPK47NI4RKhXfWkje5rG(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_m765qPK47NI4RKhXfWkje5rG$0;
  s.name = "final boss";
  s.$board = undefined;
  s.$sprites = undefined;
  s.$bcoll = undefined;
  s.$ship = undefined;
  s.$hero = undefined;
  s.$herofly = undefined;
  s.$lifebo = undefined;
  s.$perform = undefined;
  s.$blaser = undefined;
  return s;
}
cs.registerAction("final boss", "m765qPK47NI4RKhXfWkje5rG", a_m765qPK47NI4RKhXfWkje5rG, true);

function a_m765qPK47NI4RKhXfWkje5rG$0(s) {
  (s.pc = "0.135.0");
  var t_libcall_0 = s.libs["game"]["start with fixed size"](s);
  return s.rt.enter(t_libcall_0.invoke(t_libcall_0, a_m765qPK47NI4RKhXfWkje5rG$1, 1320, 820));
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$0, 'a_m765qPK47NI4RKhXfWkje5rG$0');

function a_m765qPK47NI4RKhXfWkje5rG$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_1);
  (s.pc = "0.135.3");
  var t_libcall_2 = s.libs["game"]["start timer"](s);
  return s.rt.enter(t_libcall_2.invoke(t_libcall_2, a_m765qPK47NI4RKhXfWkje5rG$2));
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$1, 'a_m765qPK47NI4RKhXfWkje5rG$1');

function a_m765qPK47NI4RKhXfWkje5rG$2(s) {
  (s.pc = "0.135.6");
  var t_libcall_3 = s.libs["game"]["set life"](s);
  return s.rt.enter(t_libcall_3.invoke(t_libcall_3, a_m765qPK47NI4RKhXfWkje5rG$3, 100));
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$2, 'a_m765qPK47NI4RKhXfWkje5rG$2');

function a_m765qPK47NI4RKhXfWkje5rG$3(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  t_actRes_4;
  (s.pc = "0.135.9");
  (/* x4 */ s.d.$i3bpQH2YWETYuQpaNxeU27x1 = 0);
  s.rt.logDataWrite();
  (s.pc = "0.135.c");
  var t_call_5 = (ok1(s, s.$board) && s.$board.create_sprite_set(s));
  (s.$sprites = t_call_5);
  (s.pc = "0.135.f");
  var t_call_6 = (ok1(s, /* blaser */ s.d.$a0sjF8dIWzveOtPg64yuyJbW) && /* blaser */ s.d.$a0sjF8dIWzveOtPg64yuyJbW.create_collection(s));
  (s.$bcoll = t_call_6);
  (s.pc = "0.135.i");
  var t_resumeCtx_7 = s.rt.getBlockingResumeCtx(a_m765qPK47NI4RKhXfWkje5rG$4);
  var t_call_8 = (ok2(s, s.$board, /* Raptor space ship */ s.d.$m81gCoMpykeqpyr61lZGFaoh) && s.$board.create_picture(/* Raptor space ship */ s.d.$m81gCoMpykeqpyr61lZGFaoh, t_resumeCtx_7));
  return a_m765qPK47NI4RKhXfWkje5rG$4;
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$3, 'a_m765qPK47NI4RKhXfWkje5rG$3');

function a_m765qPK47NI4RKhXfWkje5rG$4(s) {
  var t_pauseRes_9 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_9);
  (s.$ship = t_pauseRes_9);
  (s.pc = "0.135.l");
  var t_call_10 = (ok1(s, s.$board) && s.$board.width(s));
  var t_call_11 = (ok1(s, s.$ship) && s.$ship.width(s));
  var t_infix_12 = (ok1(s, t_call_11) && (t_call_11 / 2));
  var t_infix_13 = (ok2(s, t_call_10, t_infix_12) && (t_call_10 - t_infix_12));
  s.rt.logObjectMutation(s.$ship);
  (ok2(s, s.$ship, t_infix_13) && s.$ship.set_x(t_infix_13, s));
  (s.pc = "0.135.o");
  var t_infix_14 = (0 - 500);
  s.rt.logObjectMutation(s.$ship);
  (ok2(s, s.$ship, t_infix_14) && s.$ship.set_speed_y(t_infix_14, s));
  (s.pc = "0.135.r");
  var t_resumeCtx_15 = s.rt.getBlockingResumeCtx(a_m765qPK47NI4RKhXfWkje5rG$5);
  var t_call_16 = (ok2(s, s.$board, /* herostill2 */ s.d.$SdO5gmsaVBpyFSCM2obtUH16) && s.$board.create_picture(/* herostill2 */ s.d.$SdO5gmsaVBpyFSCM2obtUH16, t_resumeCtx_15));
  return a_m765qPK47NI4RKhXfWkje5rG$5;
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$4, 'a_m765qPK47NI4RKhXfWkje5rG$4');

function a_m765qPK47NI4RKhXfWkje5rG$5(s) {
  var t_pauseRes_17 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_17);
  (s.$hero = t_pauseRes_17);
  (s.pc = "0.135.u");
  var t_resumeCtx_18 = s.rt.getBlockingResumeCtx(a_m765qPK47NI4RKhXfWkje5rG$6);
  var t_call_19 = (ok2(s, s.$board, /* herofly2 */ s.d.$HDSUkuLyhDFibKg27i0hlj4U) && s.$board.create_picture(/* herofly2 */ s.d.$HDSUkuLyhDFibKg27i0hlj4U, t_resumeCtx_18));
  return a_m765qPK47NI4RKhXfWkje5rG$6;
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$5, 'a_m765qPK47NI4RKhXfWkje5rG$5');

function a_m765qPK47NI4RKhXfWkje5rG$6(s) {
  var t_pauseRes_20 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_20);
  (s.$herofly = t_pauseRes_20);
  (s.pc = "0.135.x");
  var t_call_21 = (ok1(s, s.$hero) && s.$hero.width(s));
  (s.$lifebo = t_call_21);
  (s.pc = "0.135.A");
  s.rt.logObjectMutation(s.$herofly);
  (ok1(s, s.$herofly) && s.$herofly.hide(s));
  (s.pc = "0.135.D");
  var t_libcall_22 = s.libs["vk4YirHiqGbPTNTjv1IL5dsL"]["control sprite"](s);
  return s.rt.enter(t_libcall_22.invoke(t_libcall_22, a_m765qPK47NI4RKhXfWkje5rG$7, s.$hero, 500, 500));
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$6, 'a_m765qPK47NI4RKhXfWkje5rG$6');

function a_m765qPK47NI4RKhXfWkje5rG$7(s) {
  (s.pc = "0.135.K0");
  var t_lmbv_23 = s.$hero;
  var t_lmbv_24 = s.$herofly;
  var t_lmbv_25 = s.$lifebo;
  var t_lmbv_26 = s.$ship;
  var t_lmbv_27 = s.$board;
  var t_lmbv_28 = s.$sprites;
  var t_lmbv_29 = s.$bcoll;
  var t_lmbProxy_30 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_m765qPK47NI4RKhXfWkje5rG$8(t_lmbProxy_30(la0), la1, t_lmbv_23, t_lmbv_24, t_lmbv_25, t_lmbv_26, t_lmbv_27, t_lmbv_28, t_lmbv_29) });
  (s.pc = "0.135.G");
  var t_call_31 = (ok2(s, s.$board, s.$perform) && s.$board.add_on_every_frame(s.$perform, s));
  t_call_31;
  (s.pc = "0.135.K");
  return s.rt.enter(a_vhVL66QIBewgprYlAaPpQXfG(s, a_m765qPK47NI4RKhXfWkje5rG$9, s.$board, s.$bcoll, s.$ship));
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$7, 'a_m765qPK47NI4RKhXfWkje5rG$7');

function a_m765qPK47NI4RKhXfWkje5rG$9(s) {
  var t_actRes_32 = s.rt.returnedFrom.result;
  t_actRes_32;
  (s.pc = "0.135.N");
  return s.rt.enter(a_H2ta1gmIhAkq64kNRiCoHjQl(s, a_m765qPK47NI4RKhXfWkje5rG$10, s.$ship));
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$9, 'a_m765qPK47NI4RKhXfWkje5rG$9');

function a_m765qPK47NI4RKhXfWkje5rG$10(s) {
  var t_actRes_33 = s.rt.returnedFrom.result;
  t_actRes_33;
  (s.pc = "0.135.Q");
  return s.rt.enter(a_TNAg2VTsw36kCIdNnG2QW6x5(s, a_m765qPK47NI4RKhXfWkje5rG$11, s.$board, s.$sprites));
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$10, 'a_m765qPK47NI4RKhXfWkje5rG$10');

function a_m765qPK47NI4RKhXfWkje5rG$11(s) {
  var t_actRes_34 = s.rt.returnedFrom.result;
  t_actRes_34;
  return s.rt.leave();
}
cs.registerStep(a_m765qPK47NI4RKhXfWkje5rG$11, 'a_m765qPK47NI4RKhXfWkje5rG$11');

/* ACTION: a_m765qPK47NI4RKhXfWkje5rG::lambda::8 */
function a_a_m765qPK47NI4RKhXfWkje5rG$8(previous, returnAddr, $hero, $herofly, $lifebo, $ship, $board, $sprites, $bcoll) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_m765qPK47NI4RKhXfWkje5rG$8$0;
  s.name = "final boss";
  s.$hero = $hero;
  s.$herofly = $herofly;
  s.$lifebo = $lifebo;
  s.$ship = $ship;
  s.$board = $board;
  s.$sprites = $sprites;
  s.$bcoll = $bcoll;
  s.$blaser = undefined;
  return s;
}
cs.registerLambda("a_m765qPK47NI4RKhXfWkje5rG\u003a\u003alambda\u003a\u003a8", "a_m765qPK47NI4RKhXfWkje5rG$8", a_a_m765qPK47NI4RKhXfWkje5rG$8, true);

function a_a_m765qPK47NI4RKhXfWkje5rG$8$0(s) {
  (s.pc = "0.135.K20");
  return s.rt.enter(a_r2cOsCI0XISZEc2u9nTf75yC(s, a_a_m765qPK47NI4RKhXfWkje5rG$8$1, s.$hero, s.$herofly, s.$lifebo));
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$0, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$0');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  t_actRes_0;
  (s.pc = "0.135.K23");
  return s.rt.enter(a_a6V1A0XTXw95N9Q1wINcSkTl(s, a_a_m765qPK47NI4RKhXfWkje5rG$8$2, s.$ship, s.$board));
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$1, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$1');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$2(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  t_actRes_1;
  var t_elseIf_2 = true;
  (s.pc = "0.135.K26");
  var t_call_3 = (ok1(s, s.$ship) && s.$ship.x(s));
  var t_infix_4 = (ok1(s, t_call_3) && (t_call_3 <= 0));
  ok1(s, t_infix_4);
  if (t_infix_4) {
  (s.pc = "0.135.K2a0");
  s.rt.logObjectMutation(s.$ship);
  (ok1(s, s.$ship) && s.$ship.set_speed_x(0, s));
  (s.pc = "0.135.K2a3");
  var t_call_5 = (ok1(s, s.$board) && s.$board.width(s));
  var t_call_6 = (ok1(s, s.$ship) && s.$ship.width(s));
  var t_infix_7 = (ok1(s, t_call_6) && (t_call_6 / 2));
  var t_infix_8 = (ok2(s, t_call_5, t_infix_7) && (t_call_5 - t_infix_7));
  s.rt.logObjectMutation(s.$ship);
  (ok2(s, s.$ship, t_infix_8) && s.$ship.set_x(t_infix_8, s));
  } else {
  (s.pc = "0.135.K2b0");
  null;
  }
  (s.pc = "0.135.K2b");
  return s.rt.enter(a_ILWW429ZKoBrlEvVN4qe6GW5(s, a_a_m765qPK47NI4RKhXfWkje5rG$8$4, s.$sprites, s.$hero, s.$herofly));
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$2, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$2');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$4(s) {
  var t_actRes_9 = s.rt.returnedFrom.result;
  t_actRes_9;
  var t_elseIf_10 = true;
  (s.pc = "0.135.K2e");
  var t_infix_11 = (ok1(s, /* x4 */ s.d.$i3bpQH2YWETYuQpaNxeU27x1) && (/* x4 */ s.d.$i3bpQH2YWETYuQpaNxeU27x1 === 5));
  ok1(s, t_infix_11);
  if (t_infix_11) {
  (s.pc = "0.135.K2i0");
  var t_libcall_12 = s.libs["game"]["end"](s);
  return s.rt.enter(t_libcall_12.invoke(t_libcall_12, a_a_m765qPK47NI4RKhXfWkje5rG$8$6));
  } else {
  (s.pc = "0.135.K2j0");
  null;
  }
  return a_a_m765qPK47NI4RKhXfWkje5rG$8$5;
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$4, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$4');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$6(s) {
  var t_actRes_13 = s.rt.returnedFrom.result;
  t_actRes_13;
  return a_a_m765qPK47NI4RKhXfWkje5rG$8$5;
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$6, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$6');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$5(s) {
  (s.pc = "0.135.K2j");
  s.t_collArr_14 = (ok1(s, s.$bcoll) && s.$bcoll.get_enumerator());
  s.t_idx_15 = 0;
  return a_a_m765qPK47NI4RKhXfWkje5rG$8$7;
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$5, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$5');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$7(s) {
  if ((s.t_idx_15 < (s.t_collArr_14.length))) {
  (s.$blaser = s.t_collArr_14[(s.t_idx_15)]);
  (s.t_idx_15++);
  if (s.$blaser) {
  var t_recOp_16 = s.$blaser[("x3uhjTN9iKxI2B0RA4Uv7q43")];
  }
  var t_call_17 = (ok2(s, t_recOp_16, s.$herofly) && t_recOp_16.overlaps_with(s.$herofly, s));
  var t_lazy_18 = t_call_17;
  if ((ok1(s, t_lazy_18) && (!t_lazy_18))) {
  if (s.$blaser) {
  var t_recOp_19 = s.$blaser[("x3uhjTN9iKxI2B0RA4Uv7q43")];
  }
  var t_call_20 = (ok2(s, t_recOp_19, s.$hero) && t_recOp_19.overlaps_with(s.$hero, s));
  (t_lazy_18 = t_call_20);
  }
  if (t_lazy_18) {
  (s.pc = "0.135.K2o0");
  var t_libcall_21 = s.libs["game"]["remove life"](s);
  return s.rt.enter(t_libcall_21.invoke(t_libcall_21, a_a_m765qPK47NI4RKhXfWkje5rG$8$13, 1));
  }
  return a_a_m765qPK47NI4RKhXfWkje5rG$8$9;
  }
  var t_elseIf_23 = true;
  (s.pc = "0.135.K2o");
  var t_call_24 = (ok2(s, s.$ship, s.$herofly) && s.$ship.overlaps_with(s.$herofly, s));
  var t_lazy_25 = t_call_24;
  if ((ok1(s, t_lazy_25) && (!t_lazy_25))) {
  var t_call_26 = (ok2(s, s.$ship, s.$hero) && s.$ship.overlaps_with(s.$hero, s));
  (t_lazy_25 = t_call_26);
  }
  ok1(s, t_lazy_25);
  if (t_lazy_25) {
  (s.pc = "0.135.K2s0");
  var t_libcall_27 = s.libs["game"]["remove life"](s);
  return s.rt.enter(t_libcall_27.invoke(t_libcall_27, a_a_m765qPK47NI4RKhXfWkje5rG$8$16, 2));
  } else {
  (s.pc = "0.135.K2t0");
  null;
  }
  return a_a_m765qPK47NI4RKhXfWkje5rG$8$15;
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$7, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$7');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$13(s) {
  var t_actRes_22 = s.rt.returnedFrom.result;
  t_actRes_22;
  return a_a_m765qPK47NI4RKhXfWkje5rG$8$9;
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$13, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$13');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$9(s) {
  return a_a_m765qPK47NI4RKhXfWkje5rG$8$7;
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$9, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$9');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$16(s) {
  var t_actRes_28 = s.rt.returnedFrom.result;
  t_actRes_28;
  return a_a_m765qPK47NI4RKhXfWkje5rG$8$15;
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$16, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$16');

function a_a_m765qPK47NI4RKhXfWkje5rG$8$15(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_m765qPK47NI4RKhXfWkje5rG$8$15, 'a_a_m765qPK47NI4RKhXfWkje5rG$8$15');

cs.registerArtResource("Picture", "$m81gCoMpykeqpyr61lZGFaoh", ".\u002fart\u002f$0$$m81gCoMpykeqpyr61lZGFaoh");

//Ent_a0sjF8dIWzveOtPg64yuyJbW
function Ent_a0sjF8dIWzveOtPg64yuyJbW(p) {
  this.parent = p;
}
Ent_a0sjF8dIWzveOtPg64yuyJbW.prototype = new lib.ObjectEntry();
Ent_a0sjF8dIWzveOtPg64yuyJbW.prototype.keys = [];
Ent_a0sjF8dIWzveOtPg64yuyJbW.prototype.values = ["x3uhjTN9iKxI2B0RA4Uv7q43", "zN183bpQgbJZlUuVbcvAxTdI"];
Ent_a0sjF8dIWzveOtPg64yuyJbW.prototype.fields = ["x3uhjTN9iKxI2B0RA4Uv7q43", "zN183bpQgbJZlUuVbcvAxTdI"];
Ent_a0sjF8dIWzveOtPg64yuyJbW.prototype.x3uhjTN9iKxI2B0RA4Uv7q43_realname = "blaser";
Ent_a0sjF8dIWzveOtPg64yuyJbW.prototype.zN183bpQgbJZlUuVbcvAxTdI_realname = "hp";
Ent_a0sjF8dIWzveOtPg64yuyJbW.prototype.zN183bpQgbJZlUuVbcvAxTdI = 0;
//Col_a0sjF8dIWzveOtPg64yuyJbW
function Col_a0sjF8dIWzveOtPg64yuyJbW(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_a0sjF8dIWzveOtPg64yuyJbW.prototype = lib.RecordCollection.prototype;
//Tbl_a0sjF8dIWzveOtPg64yuyJbW
function Tbl_a0sjF8dIWzveOtPg64yuyJbW(l) {
  this.libName = l;
  this.initParent();
}
Tbl_a0sjF8dIWzveOtPg64yuyJbW.prototype = new lib.ObjectSingleton();
Tbl_a0sjF8dIWzveOtPg64yuyJbW.prototype.entryCtor = Ent_a0sjF8dIWzveOtPg64yuyJbW;
Tbl_a0sjF8dIWzveOtPg64yuyJbW.prototype.selfCtor = Tbl_a0sjF8dIWzveOtPg64yuyJbW;
Tbl_a0sjF8dIWzveOtPg64yuyJbW.prototype.collectionCtor = Col_a0sjF8dIWzveOtPg64yuyJbW;
Tbl_a0sjF8dIWzveOtPg64yuyJbW.prototype.stableName = "a0sjF8dIWzveOtPg64yuyJbW";
Tbl_a0sjF8dIWzveOtPg64yuyJbW.prototype.entryKindName = "blaser";

// jsonimport
Ent_a0sjF8dIWzveOtPg64yuyJbW.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("zN183bpQgbJZlUuVbcvAxTdI", ctx.importNumber(json, "hp"), s);
}
cs.registerGlobal("$a0sjF8dIWzveOtPg64yuyJbW");
/* ACTION: initialize blaser */
function a_AitbTHI8EboRO8JMDxd2Usjp(previous, returnAddr, $board, $hp) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_AitbTHI8EboRO8JMDxd2Usjp$0;
  s.name = "initialize blaser";
  s.$board = $board;
  s.$hp = $hp;
  s.result = undefined;
  s.$laser = undefined;
  s.$blaser2 = undefined;
  return s;
}
cs.registerAction("initialize blaser", "AitbTHI8EboRO8JMDxd2Usjp", a_AitbTHI8EboRO8JMDxd2Usjp, true);

function a_AitbTHI8EboRO8JMDxd2Usjp$0(s) {
  (s.pc = "0.142.0");
  var t_resumeCtx_0 = s.rt.getBlockingResumeCtx(a_AitbTHI8EboRO8JMDxd2Usjp$1);
  var t_call_1 = (ok2(s, s.$board, /* laser beam2 */ s.d.$mDh8k4ncKjNp5xb2Oj2sj53J) && s.$board.create_picture(/* laser beam2 */ s.d.$mDh8k4ncKjNp5xb2Oj2sj53J, t_resumeCtx_0));
  return a_AitbTHI8EboRO8JMDxd2Usjp$1;
}
cs.registerStep(a_AitbTHI8EboRO8JMDxd2Usjp$0, 'a_AitbTHI8EboRO8JMDxd2Usjp$0');

function a_AitbTHI8EboRO8JMDxd2Usjp$1(s) {
  var t_pauseRes_2 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_2);
  (s.$laser = t_pauseRes_2);
  (s.pc = "0.142.3");
  s.rt.logObjectMutation(s.$laser);
  (ok1(s, s.$laser) && s.$laser.set_width(200, s));
  (s.pc = "0.142.6");
  var t_infix_3 = (0 - 45);
  s.rt.logObjectMutation(s.$laser);
  (ok2(s, s.$laser, t_infix_3) && s.$laser.set_angle(t_infix_3, s));
  (s.pc = "0.142.9");
  var t_call_4 = (ok1(s, /* blaser */ s.d.$a0sjF8dIWzveOtPg64yuyJbW) && /* blaser */ s.d.$a0sjF8dIWzveOtPg64yuyJbW.create(s));
  s.rt.markAllocated(t_call_4);
  (s.$blaser2 = t_call_4);
  (s.pc = "0.142.c");
  if (s.$blaser2) {
  s.$blaser2.perform_set("x3uhjTN9iKxI2B0RA4Uv7q43", s.$laser, s);
  }
  (s.pc = "0.142.f");
  if (s.$blaser2) {
  s.$blaser2.perform_set("zN183bpQgbJZlUuVbcvAxTdI", s.$hp, s);
  }
  (s.pc = "0.142.i");
  (s.result = s.$blaser2);
  return s.rt.leave();
}
cs.registerStep(a_AitbTHI8EboRO8JMDxd2Usjp$1, 'a_AitbTHI8EboRO8JMDxd2Usjp$1');

/* ACTION: fire blazer */
function a_vhVL66QIBewgprYlAaPpQXfG(previous, returnAddr, $board, $coll, $ship) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_vhVL66QIBewgprYlAaPpQXfG$0;
  s.name = "fire blazer";
  s.$board = $board;
  s.$coll = $coll;
  s.$ship = $ship;
  s.$perform = undefined;
  s.$blaser = undefined;
  s.$blaser2 = undefined;
  return s;
}
cs.registerAction("fire blazer", "vhVL66QIBewgprYlAaPpQXfG", a_vhVL66QIBewgprYlAaPpQXfG, true);

function a_vhVL66QIBewgprYlAaPpQXfG$0(s) {
  (s.pc = "0.148.40");
  var t_lmbv_0 = s.$board;
  var t_lmbv_1 = s.$ship;
  var t_lmbv_2 = s.$coll;
  var t_lmbProxy_3 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_vhVL66QIBewgprYlAaPpQXfG$1(t_lmbProxy_3(la0), la1, t_lmbv_0, t_lmbv_1, t_lmbv_2) });
  (s.pc = "0.148.0");
  s.rt.logObjectMutation(null);
  var t_call_4 = (ok1(s, s.$perform) && lib.Time.run_every(1, s.$perform, s));
  t_call_4;
  return s.rt.leave();
}
cs.registerStep(a_vhVL66QIBewgprYlAaPpQXfG$0, 'a_vhVL66QIBewgprYlAaPpQXfG$0');

/* ACTION: a_vhVL66QIBewgprYlAaPpQXfG::lambda::1 */
function a_a_vhVL66QIBewgprYlAaPpQXfG$1(previous, returnAddr, $board, $ship, $coll) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_vhVL66QIBewgprYlAaPpQXfG$1$0;
  s.name = "fire blazer";
  s.$board = $board;
  s.$blaser = undefined;
  s.$ship = $ship;
  s.$blaser2 = undefined;
  s.$coll = $coll;
  return s;
}
cs.registerLambda("a_vhVL66QIBewgprYlAaPpQXfG\u003a\u003alambda\u003a\u003a1", "a_vhVL66QIBewgprYlAaPpQXfG$1", a_a_vhVL66QIBewgprYlAaPpQXfG$1, true);

function a_a_vhVL66QIBewgprYlAaPpQXfG$1$0(s) {
  (s.pc = "0.148.420");
  return s.rt.enter(a_AitbTHI8EboRO8JMDxd2Usjp(s, a_a_vhVL66QIBewgprYlAaPpQXfG$1$1, s.$board, 10));
}
cs.registerStep(a_a_vhVL66QIBewgprYlAaPpQXfG$1$0, 'a_a_vhVL66QIBewgprYlAaPpQXfG$1$0');

function a_a_vhVL66QIBewgprYlAaPpQXfG$1$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  (s.$blaser = t_actRes_0);
  (s.pc = "0.148.423");
  return s.rt.enter(a_AitbTHI8EboRO8JMDxd2Usjp(s, a_a_vhVL66QIBewgprYlAaPpQXfG$1$2, s.$board, 10));
}
cs.registerStep(a_a_vhVL66QIBewgprYlAaPpQXfG$1$1, 'a_a_vhVL66QIBewgprYlAaPpQXfG$1$1');

function a_a_vhVL66QIBewgprYlAaPpQXfG$1$2(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (s.$blaser2 = t_actRes_1);
  (s.pc = "0.148.426");
  if (s.$blaser) {
  var t_recOp_2 = s.$blaser[("x3uhjTN9iKxI2B0RA4Uv7q43")];
  }
  var t_call_3 = (ok1(s, s.$ship) && s.$ship.x(s));
  var t_call_4 = (ok1(s, s.$ship) && s.$ship.width(s));
  var t_infix_5 = (ok1(s, t_call_4) && (t_call_4 / 2));
  var t_infix_6 = (ok2(s, t_call_3, t_infix_5) && (t_call_3 - t_infix_5));
  var t_call_7 = (ok1(s, s.$ship) && s.$ship.y(s));
  var t_infix_8 = (ok1(s, t_call_7) && (t_call_7 - 25));
  s.rt.logObjectMutation(t_recOp_2);
  (ok3(s, t_recOp_2, t_infix_6, t_infix_8) && t_recOp_2.set_pos(t_infix_6, t_infix_8, s));
  (s.pc = "0.148.429");
  if (s.$blaser2) {
  var t_recOp_9 = s.$blaser2[("x3uhjTN9iKxI2B0RA4Uv7q43")];
  }
  var t_call_10 = (ok1(s, s.$ship) && s.$ship.x(s));
  var t_call_11 = (ok1(s, s.$ship) && s.$ship.width(s));
  var t_infix_12 = (ok1(s, t_call_11) && (t_call_11 / 2));
  var t_infix_13 = (ok2(s, t_call_10, t_infix_12) && (t_call_10 - t_infix_12));
  var t_call_14 = (ok1(s, s.$ship) && s.$ship.y(s));
  var t_infix_15 = (ok1(s, t_call_14) && (t_call_14 + 25));
  s.rt.logObjectMutation(t_recOp_9);
  (ok3(s, t_recOp_9, t_infix_13, t_infix_15) && t_recOp_9.set_pos(t_infix_13, t_infix_15, s));
  (s.pc = "0.148.42c");
  if (s.$blaser) {
  var t_recOp_16 = s.$blaser[("x3uhjTN9iKxI2B0RA4Uv7q43")];
  }
  var t_infix_17 = (0 - 800);
  s.rt.logObjectMutation(t_recOp_16);
  (ok2(s, t_recOp_16, t_infix_17) && t_recOp_16.set_speed_x(t_infix_17, s));
  (s.pc = "0.148.42f");
  if (s.$blaser2) {
  var t_recOp_18 = s.$blaser2[("x3uhjTN9iKxI2B0RA4Uv7q43")];
  }
  var t_infix_19 = (0 - 800);
  s.rt.logObjectMutation(t_recOp_18);
  (ok2(s, t_recOp_18, t_infix_19) && t_recOp_18.set_speed_x(t_infix_19, s));
  (s.pc = "0.148.42i");
  s.rt.logObjectMutation(s.$coll);
  (ok2(s, s.$coll, s.$blaser) && s.$coll.add(s.$blaser, s));
  (s.pc = "0.148.42l");
  s.rt.logObjectMutation(s.$coll);
  (ok2(s, s.$coll, s.$blaser2) && s.$coll.add(s.$blaser2, s));
  (s.pc = "0.148.42o");
  var t_libcall_20 = s.libs["game"]["add score"](s);
  return s.rt.enter(t_libcall_20.invoke(t_libcall_20, a_a_vhVL66QIBewgprYlAaPpQXfG$1$7, 5));
}
cs.registerStep(a_a_vhVL66QIBewgprYlAaPpQXfG$1$2, 'a_a_vhVL66QIBewgprYlAaPpQXfG$1$2');

function a_a_vhVL66QIBewgprYlAaPpQXfG$1$7(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_vhVL66QIBewgprYlAaPpQXfG$1$7, 'a_a_vhVL66QIBewgprYlAaPpQXfG$1$7');

cs.registerArtResource("Picture", "$mDh8k4ncKjNp5xb2Oj2sj53J", ".\u002fart\u002f$0$$mDh8k4ncKjNp5xb2Oj2sj53J");
/* ACTION: ship speed */
function a_a6V1A0XTXw95N9Q1wINcSkTl(previous, returnAddr, $ship, $board) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a6V1A0XTXw95N9Q1wINcSkTl$0;
  s.name = "ship speed";
  s.$ship = $ship;
  s.$board = $board;
  return s;
}
cs.registerAction("ship speed", "a6V1A0XTXw95N9Q1wINcSkTl", a_a6V1A0XTXw95N9Q1wINcSkTl, true);

function a_a6V1A0XTXw95N9Q1wINcSkTl$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.156.0");
  var t_call_1 = (ok1(s, s.$ship) && s.$ship.y(s));
  var t_call_2 = (ok1(s, s.$ship) && s.$ship.height(s));
  var t_infix_3 = (ok1(s, t_call_2) && (t_call_2 / 2));
  var t_infix_4 = (ok2(s, t_call_1, t_infix_3) && (t_call_1 - t_infix_3));
  var t_infix_5 = (ok1(s, t_infix_4) && (t_infix_4 <= 0));
  ok1(s, t_infix_5);
  if (t_infix_5) {
  (t_elseIf_0 = false);
  (s.pc = "0.156.40");
  var t_call_6 = (ok1(s, s.$ship) && s.$ship.speed_y(s));
  var t_infix_7 = (ok1(s, t_call_6) && (0 - t_call_6));
  s.rt.logObjectMutation(s.$ship);
  (ok2(s, s.$ship, t_infix_7) && s.$ship.set_speed_y(t_infix_7, s));
  }
  if (t_elseIf_0) {
  (s.pc = "0.156.5");
  var t_call_8 = (ok1(s, s.$ship) && s.$ship.y(s));
  var t_call_9 = (ok1(s, s.$ship) && s.$ship.height(s));
  var t_infix_10 = (ok1(s, t_call_9) && (t_call_9 / 2));
  var t_infix_11 = (ok2(s, t_call_8, t_infix_10) && (t_call_8 + t_infix_10));
  var t_call_12 = (ok1(s, s.$board) && s.$board.height(s));
  var t_infix_13 = (ok2(s, t_infix_11, t_call_12) && (t_infix_11 >= t_call_12));
  ok1(s, t_infix_13);
  if (t_infix_13) {
  (s.pc = "0.156.90");
  var t_call_14 = (ok1(s, s.$ship) && s.$ship.speed_y(s));
  var t_infix_15 = (ok1(s, t_call_14) && (0 - t_call_14));
  s.rt.logObjectMutation(s.$ship);
  (ok2(s, s.$ship, t_infix_15) && s.$ship.set_speed_y(t_infix_15, s));
  } else {
  (s.pc = "0.156.a0");
  null;
  }
  }
  return s.rt.leave();
}
cs.registerStep(a_a6V1A0XTXw95N9Q1wINcSkTl$0, 'a_a6V1A0XTXw95N9Q1wINcSkTl$0');

/* ACTION: ship ram */
function a_H2ta1gmIhAkq64kNRiCoHjQl(previous, returnAddr, $ship) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_H2ta1gmIhAkq64kNRiCoHjQl$0;
  s.name = "ship ram";
  s.$ship = $ship;
  s.$perform = undefined;
  return s;
}
cs.registerAction("ship ram", "H2ta1gmIhAkq64kNRiCoHjQl", a_H2ta1gmIhAkq64kNRiCoHjQl, true);

function a_H2ta1gmIhAkq64kNRiCoHjQl$0(s) {
  (s.pc = "0.161.40");
  var t_lmbv_0 = s.$ship;
  var t_lmbProxy_1 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_H2ta1gmIhAkq64kNRiCoHjQl$1(t_lmbProxy_1(la0), la1, t_lmbv_0) });
  (s.pc = "0.161.0");
  var t_call_2 = lib.Math_.random_range(2, 10, s);
  s.rt.logObjectMutation(null);
  var t_call_3 = (ok2(s, t_call_2, s.$perform) && lib.Time.run_every(t_call_2, s.$perform, s));
  t_call_3;
  return s.rt.leave();
}
cs.registerStep(a_H2ta1gmIhAkq64kNRiCoHjQl$0, 'a_H2ta1gmIhAkq64kNRiCoHjQl$0');

/* ACTION: a_H2ta1gmIhAkq64kNRiCoHjQl::lambda::1 */
function a_a_H2ta1gmIhAkq64kNRiCoHjQl$1(previous, returnAddr, $ship) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_H2ta1gmIhAkq64kNRiCoHjQl$1$0;
  s.name = "ship ram";
  s.$ship = $ship;
  return s;
}
cs.registerLambda("a_H2ta1gmIhAkq64kNRiCoHjQl\u003a\u003alambda\u003a\u003a1", "a_H2ta1gmIhAkq64kNRiCoHjQl$1", a_a_H2ta1gmIhAkq64kNRiCoHjQl$1, true);

function a_a_H2ta1gmIhAkq64kNRiCoHjQl$1$0(s) {
  (s.pc = "0.161.420");
  var t_infix_0 = (0 - 1000);
  s.rt.logObjectMutation(s.$ship);
  (ok2(s, s.$ship, t_infix_0) && s.$ship.set_speed_x(t_infix_0, s));
  return s.rt.leave();
}
cs.registerStep(a_a_H2ta1gmIhAkq64kNRiCoHjQl$1$0, 'a_a_H2ta1gmIhAkq64kNRiCoHjQl$1$0');

/* ACTION: solar flair */
function a_TNAg2VTsw36kCIdNnG2QW6x5(previous, returnAddr, $board, $sprites) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_TNAg2VTsw36kCIdNnG2QW6x5$0;
  s.name = "solar flair";
  s.$board = $board;
  s.$sprites = $sprites;
  s.$perform = undefined;
  s.$sprite = undefined;
  return s;
}
cs.registerAction("solar flair", "TNAg2VTsw36kCIdNnG2QW6x5", a_TNAg2VTsw36kCIdNnG2QW6x5, true);

function a_TNAg2VTsw36kCIdNnG2QW6x5$0(s) {
  (s.pc = "0.166.40");
  var t_lmbv_0 = s.$board;
  var t_lmbv_1 = s.$sprites;
  var t_lmbProxy_2 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_TNAg2VTsw36kCIdNnG2QW6x5$1(t_lmbProxy_2(la0), la1, t_lmbv_0, t_lmbv_1) });
  (s.pc = "0.166.0");
  s.rt.logObjectMutation(null);
  var t_call_3 = (ok1(s, s.$perform) && lib.Time.run_every(10, s.$perform, s));
  t_call_3;
  return s.rt.leave();
}
cs.registerStep(a_TNAg2VTsw36kCIdNnG2QW6x5$0, 'a_TNAg2VTsw36kCIdNnG2QW6x5$0');

/* ACTION: a_TNAg2VTsw36kCIdNnG2QW6x5::lambda::1 */
function a_a_TNAg2VTsw36kCIdNnG2QW6x5$1(previous, returnAddr, $board, $sprites) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_TNAg2VTsw36kCIdNnG2QW6x5$1$0;
  s.name = "solar flair";
  s.$board = $board;
  s.$sprite = undefined;
  s.$sprites = $sprites;
  return s;
}
cs.registerLambda("a_TNAg2VTsw36kCIdNnG2QW6x5\u003a\u003alambda\u003a\u003a1", "a_TNAg2VTsw36kCIdNnG2QW6x5$1", a_a_TNAg2VTsw36kCIdNnG2QW6x5$1, true);

function a_a_TNAg2VTsw36kCIdNnG2QW6x5$1$0(s) {
  (s.pc = "0.166.420");
  var t_resumeCtx_0 = s.rt.getBlockingResumeCtx(a_a_TNAg2VTsw36kCIdNnG2QW6x5$1$1);
  var t_call_1 = (ok2(s, s.$board, /* sun1 */ s.d.$uOU3YCI9PdMGgyZgQMKENLVi) && s.$board.create_picture(/* sun1 */ s.d.$uOU3YCI9PdMGgyZgQMKENLVi, t_resumeCtx_0));
  return a_a_TNAg2VTsw36kCIdNnG2QW6x5$1$1;
}
cs.registerStep(a_a_TNAg2VTsw36kCIdNnG2QW6x5$1$0, 'a_a_TNAg2VTsw36kCIdNnG2QW6x5$1$0');

function a_a_TNAg2VTsw36kCIdNnG2QW6x5$1$1(s) {
  var t_pauseRes_2 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_2);
  (s.$sprite = t_pauseRes_2);
  (s.pc = "0.166.423");
  s.rt.logObjectMutation(s.$sprite);
  (ok1(s, s.$sprite) && s.$sprite.set_width(30, s));
  (s.pc = "0.166.426");
  var t_call_3 = lib.Math_.random(100, s);
  var t_call_4 = lib.Math_.random(100, s);
  s.rt.logObjectMutation(s.$sprite);
  (ok3(s, s.$sprite, t_call_3, t_call_4) && s.$sprite.set_speed(t_call_3, t_call_4, s));
  (s.pc = "0.166.429");
  s.rt.logObjectMutation(s.$sprites);
  var t_call_5 = (ok2(s, s.$sprites, s.$sprite) && s.$sprites.add(s.$sprite, s));
  t_call_5;
  return s.rt.leave();
}
cs.registerStep(a_a_TNAg2VTsw36kCIdNnG2QW6x5$1$1, 'a_a_TNAg2VTsw36kCIdNnG2QW6x5$1$1');

cs.registerArtResource("Picture", "$uOU3YCI9PdMGgyZgQMKENLVi", ".\u002fart\u002f$0$$uOU3YCI9PdMGgyZgQMKENLVi");
/* ACTION: remove flair */
function a_ILWW429ZKoBrlEvVN4qe6GW5(previous, returnAddr, $sprites, $hero, $herofly) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_ILWW429ZKoBrlEvVN4qe6GW5$0;
  s.name = "remove flair";
  s.$sprites = $sprites;
  s.$hero = $hero;
  s.$herofly = $herofly;
  s.$sprite = undefined;
  return s;
}
cs.registerAction("remove flair", "ILWW429ZKoBrlEvVN4qe6GW5", a_ILWW429ZKoBrlEvVN4qe6GW5, true);

function a_ILWW429ZKoBrlEvVN4qe6GW5$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "0.173.0");
  true;
  if ((s.$sprites == undefined)) {
  (s.pc = "0.173.40");
  null;
  } else {
  (s.pc = "0.173.50");
  s.t_collArr_1 = (ok1(s, s.$sprites) && s.$sprites.get_enumerator());
  s.t_idx_2 = 0;
  return a_ILWW429ZKoBrlEvVN4qe6GW5$2;
  }
  return a_ILWW429ZKoBrlEvVN4qe6GW5$1;
}
cs.registerStep(a_ILWW429ZKoBrlEvVN4qe6GW5$0, 'a_ILWW429ZKoBrlEvVN4qe6GW5$0');

function a_ILWW429ZKoBrlEvVN4qe6GW5$2(s) {
  if ((s.t_idx_2 < (s.t_collArr_1.length))) {
  (s.$sprite = s.t_collArr_1[(s.t_idx_2)]);
  (s.t_idx_2++);
  var t_call_3 = (ok2(s, s.$hero, s.$sprite) && s.$hero.overlaps_with(s.$sprite, s));
  var t_lazy_4 = t_call_3;
  if ((ok1(s, t_lazy_4) && (!t_lazy_4))) {
  var t_call_5 = (ok2(s, s.$herofly, s.$sprite) && s.$herofly.overlaps_with(s.$sprite, s));
  (t_lazy_4 = t_call_5);
  }
  if (t_lazy_4) {
  (s.pc = "0.173.550");
  var t_infix_6 = (ok1(s, /* x4 */ s.d.$i3bpQH2YWETYuQpaNxeU27x1) && (/* x4 */ s.d.$i3bpQH2YWETYuQpaNxeU27x1 + 1));
  (/* x4 */ s.d.$i3bpQH2YWETYuQpaNxeU27x1 = t_infix_6);
  s.rt.logDataWrite();
  (s.pc = "0.173.553");
  s.rt.logObjectMutation(s.$sprites);
  var t_call_7 = (ok2(s, s.$sprites, s.$sprite) && s.$sprites.remove(s.$sprite, s));
  t_call_7;
  (s.pc = "0.173.556");
  s.rt.logObjectMutation(s.$sprite);
  (ok1(s, s.$sprite) && s.$sprite.delete_(s));
  }
  return a_ILWW429ZKoBrlEvVN4qe6GW5$2;
  }
  return a_ILWW429ZKoBrlEvVN4qe6GW5$1;
}
cs.registerStep(a_ILWW429ZKoBrlEvVN4qe6GW5$2, 'a_ILWW429ZKoBrlEvVN4qe6GW5$2');

function a_ILWW429ZKoBrlEvVN4qe6GW5$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_ILWW429ZKoBrlEvVN4qe6GW5$1, 'a_ILWW429ZKoBrlEvVN4qe6GW5$1');

(function () {
  var lib, bnd, resolve;
  var bnds = cs.libBindings = {};
  lib = libs["this"] = {};
  bnd = bnds["this"] = libs;
  bnd.mkLambdaProxy = cs.mkLambdaProxy(bnd, "this");
  bnd.scriptName = "Hero \u0028vroyc\u0029";
  bnd.scriptId = "vroyc";
  bnd.topScriptId = "vroyc";
    lib["main"] = cs.mkLibProxyFactory(bnd, "this", "main");
  lib = libs["game"] = {};
  bnd = bnds["game"] = {};
  bnd.mkLambdaProxy = cs.mkLambdaProxy(bnd, "game");
  bnd.scriptName = "game \u0028lnhr\u0029";
  bnd.scriptId = "lnhr";
  bnd.topScriptId = "vroyc";
    lib["set score"] = cs.mkLibProxyFactory(bnd, "game", "set score");
    lib["set life"] = cs.mkLibProxyFactory(bnd, "game", "set life");
    lib["start timer"] = cs.mkLibProxyFactory(bnd, "game", "start timer");
    lib["start countdown timer"] = cs.mkLibProxyFactory(bnd, "game", "start countdown timer");
    lib["life"] = cs.mkLibProxyFactory(bnd, "game", "life");
    lib["score"] = cs.mkLibProxyFactory(bnd, "game", "score");
    lib["current time"] = cs.mkLibProxyFactory(bnd, "game", "current time");
    lib["add score"] = cs.mkLibProxyFactory(bnd, "game", "add score");
    lib["add life"] = cs.mkLibProxyFactory(bnd, "game", "add life");
    lib["clear timer"] = cs.mkLibProxyFactory(bnd, "game", "clear timer");
    lib["remove life"] = cs.mkLibProxyFactory(bnd, "game", "remove life");
    lib["end"] = cs.mkLibProxyFactory(bnd, "game", "end");
    lib["start"] = cs.mkLibProxyFactory(bnd, "game", "start");
    lib["reset"] = cs.mkLibProxyFactory(bnd, "game", "reset");
    lib["start with fixed size"] = cs.mkLibProxyFactory(bnd, "game", "start with fixed size");
    lib["start with background picture"] = cs.mkLibProxyFactory(bnd, "game", "start with background picture");
    lib["board"] = cs.mkLibProxyFactory(bnd, "game", "board");
    lib["on end"] = cs.mkLibProxyFactory(bnd, "game", "on end");
  lib = libs["vk4YirHiqGbPTNTjv1IL5dsL"] = {};
  bnd = bnds["vk4YirHiqGbPTNTjv1IL5dsL"] = {};
  bnd.mkLambdaProxy = cs.mkLambdaProxy(bnd, "vk4YirHiqGbPTNTjv1IL5dsL");
  bnd.scriptName = "joystick \u0028bjzz\u0029";
  bnd.scriptId = "bjzz";
  bnd.topScriptId = "vroyc";
    lib["current"] = cs.mkLibProxyFactory(bnd, "vk4YirHiqGbPTNTjv1IL5dsL", "current");
    lib["set keys"] = cs.mkLibProxyFactory(bnd, "vk4YirHiqGbPTNTjv1IL5dsL", "set keys");
    lib["set accelerometer"] = cs.mkLibProxyFactory(bnd, "vk4YirHiqGbPTNTjv1IL5dsL", "set accelerometer");
    lib["accelerometer"] = cs.mkLibProxyFactory(bnd, "vk4YirHiqGbPTNTjv1IL5dsL", "accelerometer");
    lib["control sprite"] = cs.mkLibProxyFactory(bnd, "vk4YirHiqGbPTNTjv1IL5dsL", "control sprite");
    lib["control background scene"] = cs.mkLibProxyFactory(bnd, "vk4YirHiqGbPTNTjv1IL5dsL", "control background scene");
  lib = libs["olZOoTBBwZaQT3B4fbkU2Y2c"] = {};
  bnd = bnds["olZOoTBBwZaQT3B4fbkU2Y2c"] = {};
  bnd.mkLambdaProxy = cs.mkLambdaProxy(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c");
  bnd.scriptName = "sprite sheet \u0028ldugb\u0029";
  bnd.scriptId = "ldugb";
  bnd.topScriptId = "vroyc";
    lib["initialize"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "initialize");
    lib["create sprite"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "create sprite");
    lib["set margin"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "set margin");
    lib["set gap"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "set gap");
    lib["draw grid"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "draw grid");
    lib["set sprite picture"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "set sprite picture");
    lib["rows"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "rows");
    lib["columns"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "columns");
    lib["clear animation"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "clear animation");
    lib["set animation"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "set animation");
    lib["set sheet"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "set sheet");
    lib["create animation"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "create animation");
    lib["is animated"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "is animated");
    lib["create full animation"] = cs.mkLibProxyFactory(bnd, "olZOoTBBwZaQT3B4fbkU2Y2c", "create full animation");
  lib = libs["d2bbpYdDq6mcoCpqp1dEtgbi"] = {};
  bnd = bnds["d2bbpYdDq6mcoCpqp1dEtgbi"] = {};
  bnd.mkLambdaProxy = cs.mkLambdaProxy(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi");
  bnd.scriptName = "game menu \u0028lxuvb\u0029";
  bnd.scriptId = "lxuvb";
  bnd.topScriptId = "vroyc";
    lib["start"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "start");
    lib["initialize"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "initialize");
    lib["set credits"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set credits");
    lib["level count"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "level count");
    lib["set description"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set description");
    lib["level by id"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "level by id");
    lib["set locked"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set locked");
    lib["locked"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "locked");
    lib["set instructions"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set instructions");
    lib["set skip details"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set skip details");
    lib["button theme"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "button theme");
    lib["page theme"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "page theme");
    lib["set background"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set background");
    lib["set foreground"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set foreground");
    lib["set background picture"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set background picture");
    lib["level button theme"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "level button theme");
    lib["clear"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "clear");
    lib["next"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "next");
    lib["total score"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "total score");
    lib["score"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "score");
    lib["set max score"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set max score");
    lib["index"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "index");
    lib["set level selection"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "set level selection");
    lib["first level"] = cs.mkLibProxyFactory(bnd, "d2bbpYdDq6mcoCpqp1dEtgbi", "first level");
  bnd = bnds["game"];
  bnd = bnds["vk4YirHiqGbPTNTjv1IL5dsL"];
    resolve = bnd["vIOEa4LjBL2h78vLd1Ls3U5z"] = {};
      resolve["board"] = libs["game"]["board"];
      resolve["start"] = libs["game"]["start"];
  bnd = bnds["olZOoTBBwZaQT3B4fbkU2Y2c"];
  bnd = bnds["d2bbpYdDq6mcoCpqp1dEtgbi"];
    resolve = bnd["game"] = {};
      resolve["end"] = libs["game"]["end"];
      resolve["on end"] = libs["game"]["on end"];
      resolve["reset"] = libs["game"]["reset"];
      resolve["score"] = libs["game"]["score"];
      resolve["set score"] = libs["game"]["set score"];
      resolve["start"] = libs["game"]["start"];
}());
cs.startFn = function(rt) {
lib.App.rt_start(rt);
lib.Player.rt_start(rt);
lib.Senses.rt_start(rt);
lib.Time.rt_start(rt);
lib.Web.rt_start(rt);
};

cs.stopFn = function(rt) {
lib.App.rt_stop(rt);
lib.Player.rt_stop(rt);
lib.Senses.rt_stop(rt);
lib.Time.rt_stop(rt);
lib.Web.rt_stop(rt);
};

cs._compilerVersion = '1';cs._initGlobals = function(d) {
  if(!d.hasOwnProperty("$BdGhpbmca") || !d["$BdGhpbmca"]) d.$BdGhpbmca = new Tbl_BdGhpbmca(d.libName);
  if(!d.hasOwnProperty("$G5oQuHDyj1Cqydixu1lYbuzm") || !d["$G5oQuHDyj1Cqydixu1lYbuzm"]) d.$G5oQuHDyj1Cqydixu1lYbuzm = new Tbl_G5oQuHDyj1Cqydixu1lYbuzm(d.libName);
  if(!d.hasOwnProperty("$xqFaS9qU87n5kVZ81LVFbo7X") || !d["$xqFaS9qU87n5kVZ81LVFbo7X"]) d.$xqFaS9qU87n5kVZ81LVFbo7X = new Tbl_xqFaS9qU87n5kVZ81LVFbo7X(d.libName);
  if(!d.hasOwnProperty("$lVcc2aDS6HhHBmwTa7kdaOop") || !d["$lVcc2aDS6HhHBmwTa7kdaOop"]) d.$lVcc2aDS6HhHBmwTa7kdaOop = new Tbl_lVcc2aDS6HhHBmwTa7kdaOop(d.libName);
  if(!d.hasOwnProperty("$xqFpkxfy7q3EOvlgPho5S2K2")) d.$xqFpkxfy7q3EOvlgPho5S2K2 = false;
  if(!d.hasOwnProperty("$avoUwZDw7D0WKejA4Jr9PbAX")) d.$avoUwZDw7D0WKejA4Jr9PbAX = 0;
  if(!d.hasOwnProperty("$x5hWFGs51yTj5CZzqeGcoePI")) d.$x5hWFGs51yTj5CZzqeGcoePI = 0;
  if(!d.hasOwnProperty("$GJTCTeAJoSwxOp22t9U9Qo5X") || !d["$GJTCTeAJoSwxOp22t9U9Qo5X"]) d.$GJTCTeAJoSwxOp22t9U9Qo5X = new Tbl_GJTCTeAJoSwxOp22t9U9Qo5X(d.libName);
  if(!d.hasOwnProperty("$FmFQwlKCuFxRqrPduNtwCyid")) d.$FmFQwlKCuFxRqrPduNtwCyid = 0;
  if(!d.hasOwnProperty("$AcBPSm2QdmPbo9yS2ach4iYZ")) d.$AcBPSm2QdmPbo9yS2ach4iYZ = 0;
  if(!d.hasOwnProperty("$a0sjF8dIWzveOtPg64yuyJbW") || !d["$a0sjF8dIWzveOtPg64yuyJbW"]) d.$a0sjF8dIWzveOtPg64yuyJbW = new Tbl_a0sjF8dIWzveOtPg64yuyJbW(d.libName);
  if(!d.hasOwnProperty("$yAKmWqYQfCD6OukRMFZspq7z")) d.$yAKmWqYQfCD6OukRMFZspq7z = 0;
  if(!d.hasOwnProperty("$i3bpQH2YWETYuQpaNxeU27x1")) d.$i3bpQH2YWETYuQpaNxeU27x1 = 0;

};

cs._initGlobals2 = function(d) {
};

cs._resetGlobals = function(d) {
  d.$xM4pbTFgPmM5XqbcueYcRDIA = undefined;
  d.$SdO5gmsaVBpyFSCM2obtUH16 = undefined;
  d.$HDSUkuLyhDFibKg27i0hlj4U = undefined;
  d.$ITg9IATeH1Zu9Lj7VBroP3uB = undefined;
  d.$BdGhpbmca = undefined;
  d.$hVt6nP4deOtXlD0aJRnT1S9L = undefined;
  d.$G5oQuHDyj1Cqydixu1lYbuzm = undefined;
  d.$lwtatRhnHAD27XsH29tg7ke3 = undefined;
  d.$d6EZHojvh2Vq4REKUh1JZHq6 = undefined;
  d.$xqFaS9qU87n5kVZ81LVFbo7X = undefined;
  d.$LV47AU7Fb2IqQevd7cJajHje = undefined;
  d.$lVcc2aDS6HhHBmwTa7kdaOop = undefined;
  d.$zDWvqF2S2aQhvxjnQFmYimVF = undefined;
  d.$xqFpkxfy7q3EOvlgPho5S2K2 = false;
  d.$avoUwZDw7D0WKejA4Jr9PbAX = 0;
  d.$x5hWFGs51yTj5CZzqeGcoePI = 0;
  d.$AtFa8mf0t1cTCggoWNMyUXUe = undefined;
  d.$QMPo6VPk3A0HVm95PYYGc3t2 = undefined;
  d.$gIktcmxXlop1JFScyuuQFFRx = undefined;
  d.$G4FSGH7QbiLfIRtkzNPKmHCW = undefined;
  d.$sPTs4ukUDjhCqQYNO6fN4iRa = undefined;
  d.$i7v2elsf8ywqFMSgiS4SNI6p = undefined;
  d.$GJTCTeAJoSwxOp22t9U9Qo5X = undefined;
  d.$T1Omna07YTEGvI7iuNKLN2wo = undefined;
  d.$FmFQwlKCuFxRqrPduNtwCyid = 0;
  d.$AcBPSm2QdmPbo9yS2ach4iYZ = 0;
  d.$m81gCoMpykeqpyr61lZGFaoh = undefined;
  d.$a0sjF8dIWzveOtPg64yuyJbW = undefined;
  d.$qjwIS38wT7qDzwJ21nbh47jo = undefined;
  d.$EzO62w2G5PuE7wJDwaBLImzh = undefined;
  d.$mDh8k4ncKjNp5xb2Oj2sj53J = undefined;
  d.$yAKmWqYQfCD6OukRMFZspq7z = 0;
  d.$uOU3YCI9PdMGgyZgQMKENLVi = undefined;
  d.$i3bpQH2YWETYuQpaNxeU27x1 = 0;
};

cs.mainActionName = "main";
cs.authorId = "jjef";
cs.scriptId = "vroyc";
cs.hasLocalData = 1;
}),

// **************************************************************
"game": (function (cs) {
'use strict';
var libs = cs.libs = {};
var lib = TDev.RT;
var callstackcurdepth = 0;
cs.scriptTitle = "game";
cs.scriptColor = "\u00239955bb";
/* ACTION: initialize */
function a_Ayu95FKZqA9xPdjQXSANLGvP(previous, returnAddr, $width, $height) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Ayu95FKZqA9xPdjQXSANLGvP$0;
  s.name = "initialize";
  s.$width = $width;
  s.$height = $height;
  s.$ratio = undefined;
  return s;
}
cs.registerAction("initialize", "Ayu95FKZqA9xPdjQXSANLGvP", a_Ayu95FKZqA9xPdjQXSANLGvP, true);

function ok1(s, a0) {
  return (a0 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok2(s, a0, a1) {
  return (a0 == undefined || a1 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok3(s, a0, a1, a2) {
  return (a0 == undefined || a1 == undefined || a2 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_Ayu95FKZqA9xPdjQXSANLGvP$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "1.61");
  var t_infix_1 = (ok1(s, s.$width) && (s.$width < 0));
  var t_lazy_2 = t_infix_1;
  if ((ok1(s, t_lazy_2) && (!t_lazy_2))) {
  var t_infix_3 = (ok1(s, s.$height) && (s.$height < 0));
  (t_lazy_2 = t_infix_3);
  }
  ok1(s, t_lazy_2);
  if (t_lazy_2) {
  (s.pc = "1.650");
  var t_call_4 = lib.Wall.width(s);
  var t_call_5 = lib.Wall.height(s);
  var t_infix_6 = (ok2(s, t_call_4, t_call_5) && (t_call_4 / t_call_5));
  (s.$ratio = t_infix_6);
  var t_elseIf_7 = true;
  (s.pc = "1.653");
  var t_infix_8 = (ok1(s, s.$ratio) && (s.$ratio < 1));
  ok1(s, t_infix_8);
  if (t_infix_8) {
  (s.pc = "1.6570");
  var t_infix_9 = (ok1(s, s.$ratio) && (800 * s.$ratio));
  (s.$width = t_infix_9);
  (s.pc = "1.6573");
  (s.$height = 800);
  } else {
  (s.pc = "1.6580");
  (s.$width = 800);
  (s.pc = "1.6583");
  var t_infix_10 = (ok1(s, s.$ratio) && (800 / s.$ratio));
  (s.$height = t_infix_10);
  }
  } else {
  (s.pc = "1.660");
  null;
  }
  var t_elseIf_11 = true;
  (s.pc = "1.66");
  var t_infix_12 = (ok2(s, s.$width, s.$height) && (s.$width < s.$height));
  ok1(s, t_infix_12);
  if (t_infix_12) {
  (s.pc = "1.6a0");
  var t_call_13 = (ok2(s, s.$width, s.$height) && lib.Media.create_portrait_board(s.$width, s.$height, s));
  s.rt.markAllocated(t_call_13);
  (/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS = t_call_13);
  s.rt.logDataWrite();
  } else {
  (s.pc = "1.6b0");
  var t_call_14 = (ok2(s, s.$width, s.$height) && lib.Media.create_landscape_board(s.$width, s.$height, s));
  s.rt.markAllocated(t_call_14);
  (/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS = t_call_14);
  s.rt.logDataWrite();
  }
  (s.pc = "1.6b");
  var t_infix_15 = (0 - 1);
  (/* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m = t_infix_15);
  s.rt.logDataWrite();
  (s.pc = "1.6e");
  var t_infix_16 = (0 - 1);
  (/* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV = t_infix_16);
  s.rt.logDataWrite();
  (s.pc = "1.6h");
  var t_call_17 = lib.Invalid.datetime(s);
  (/* _start time */ s.d.$TzLNjDeJYpMRpdgNFuqgE2PY = t_call_17);
  s.rt.logDataWrite();
  (s.pc = "1.6k");
  var t_call_18 = lib.Invalid.sprite(s);
  (/* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X = t_call_18);
  s.rt.logDataWrite();
  (s.pc = "1.6n");
  var t_call_19 = lib.Invalid.sprite(s);
  (/* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6 = t_call_19);
  s.rt.logDataWrite();
  (s.pc = "1.6q");
  var t_call_20 = lib.Invalid.sprite(s);
  (/* _timer txt */ s.d.$x2fjfvNmVawvnAWKndzdfxls = t_call_20);
  s.rt.logDataWrite();
  (s.pc = "1.6t");
  var t_infix_21 = (0 - 1);
  (/* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY = t_infix_21);
  s.rt.logDataWrite();
  (s.pc = "1.6w");
  var t_call_22 = lib.String_.split("---\u003b\u2764\u003b\u2764\u2764\u003b\u2764\u2764\u2764", "\u003b", s);
  s.rt.markAllocated(t_call_22);
  (/* _hearts */ s.d.$emzufgdY6lsG2RaaCYaxwN8m = t_call_22);
  s.rt.logDataWrite();
  (s.pc = "1.6z");
  return s.rt.enter(a_oKY8zayGQ3QsufrQiKXXS9sh(s, a_Ayu95FKZqA9xPdjQXSANLGvP$5, 0));
}
cs.registerStep(a_Ayu95FKZqA9xPdjQXSANLGvP$0, 'a_Ayu95FKZqA9xPdjQXSANLGvP$0');

function a_Ayu95FKZqA9xPdjQXSANLGvP$5(s) {
  (s.pc = "1.6C");
  return s.rt.enter(a_l4svuo4DZFDcDqJbGklzHLTi(s, a_Ayu95FKZqA9xPdjQXSANLGvP$6, 3));
}
cs.registerStep(a_Ayu95FKZqA9xPdjQXSANLGvP$5, 'a_Ayu95FKZqA9xPdjQXSANLGvP$5');

function a_Ayu95FKZqA9xPdjQXSANLGvP$6(s) {
  var t_actRes_23 = s.rt.returnedFrom.result;
  t_actRes_23;
  return s.rt.leave();
}
cs.registerStep(a_Ayu95FKZqA9xPdjQXSANLGvP$6, 'a_Ayu95FKZqA9xPdjQXSANLGvP$6');

/* ACTION: set score */
function a_oKY8zayGQ3QsufrQiKXXS9sh(previous, returnAddr, $value) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_oKY8zayGQ3QsufrQiKXXS9sh$0;
  s.name = "set score";
  s.$value = $value;
  return s;
}
cs.registerAction("set score", "oKY8zayGQ3QsufrQiKXXS9sh", a_oKY8zayGQ3QsufrQiKXXS9sh, false);

function a_oKY8zayGQ3QsufrQiKXXS9sh$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_oKY8zayGQ3QsufrQiKXXS9sh$2, lib.RTValue.mkPicker(lib.Number_.picker(), 0, "value", "$value"));
  return a_oKY8zayGQ3QsufrQiKXXS9sh$2;
  }
  return a_oKY8zayGQ3QsufrQiKXXS9sh$1;
}
cs.registerStep(a_oKY8zayGQ3QsufrQiKXXS9sh$0, 'a_oKY8zayGQ3QsufrQiKXXS9sh$0');

function a_oKY8zayGQ3QsufrQiKXXS9sh$2(s) {
  return a_oKY8zayGQ3QsufrQiKXXS9sh$1;
}
cs.registerStep(a_oKY8zayGQ3QsufrQiKXXS9sh$2, 'a_oKY8zayGQ3QsufrQiKXXS9sh$2');

function a_oKY8zayGQ3QsufrQiKXXS9sh$1(s) {
  (s.pc = "1.c1");
  (/* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m = s.$value);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_oKY8zayGQ3QsufrQiKXXS9sh$1, 'a_oKY8zayGQ3QsufrQiKXXS9sh$1');

/* ACTION: set life */
function a_l4svuo4DZFDcDqJbGklzHLTi(previous, returnAddr, $value) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_l4svuo4DZFDcDqJbGklzHLTi$0;
  s.name = "set life";
  s.$value = $value;
  return s;
}
cs.registerAction("set life", "l4svuo4DZFDcDqJbGklzHLTi", a_l4svuo4DZFDcDqJbGklzHLTi, true);

function a_l4svuo4DZFDcDqJbGklzHLTi$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_l4svuo4DZFDcDqJbGklzHLTi$5, lib.RTValue.mkPicker(lib.Number_.picker(), 0, "value", "$value"));
  return a_l4svuo4DZFDcDqJbGklzHLTi$5;
  }
  return a_l4svuo4DZFDcDqJbGklzHLTi$4;
}
cs.registerStep(a_l4svuo4DZFDcDqJbGklzHLTi$0, 'a_l4svuo4DZFDcDqJbGklzHLTi$0');

function a_l4svuo4DZFDcDqJbGklzHLTi$5(s) {
  return a_l4svuo4DZFDcDqJbGklzHLTi$4;
}
cs.registerStep(a_l4svuo4DZFDcDqJbGklzHLTi$5, 'a_l4svuo4DZFDcDqJbGklzHLTi$5');

function a_l4svuo4DZFDcDqJbGklzHLTi$4(s) {
  (s.pc = "1.h1");
  var t_call_0 = (ok1(s, s.$value) && lib.Math_.max(0, s.$value, s));
  (/* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV = t_call_0);
  s.rt.logDataWrite();
  var t_elseIf_1 = true;
  (s.pc = "1.h4");
  var t_infix_2 = (ok1(s, /* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV) && (/* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV <= 0));
  ok1(s, t_infix_2);
  if (t_infix_2) {
  (s.pc = "1.h80");
  return s.rt.enter(a_gswamj84uYSwqLED2VvLdKi6(s, a_l4svuo4DZFDcDqJbGklzHLTi$2));
  } else {
  (s.pc = "1.h90");
  null;
  }
  return a_l4svuo4DZFDcDqJbGklzHLTi$1;
}
cs.registerStep(a_l4svuo4DZFDcDqJbGklzHLTi$4, 'a_l4svuo4DZFDcDqJbGklzHLTi$4');

function a_l4svuo4DZFDcDqJbGklzHLTi$2(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  t_actRes_3;
  (s.pc = "1.h83");
  return s.rt.enter(a_a14qLDjp7EtajVvdEd1rS18X(s, a_l4svuo4DZFDcDqJbGklzHLTi$3));
}
cs.registerStep(a_l4svuo4DZFDcDqJbGklzHLTi$2, 'a_l4svuo4DZFDcDqJbGklzHLTi$2');

function a_l4svuo4DZFDcDqJbGklzHLTi$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_l4svuo4DZFDcDqJbGklzHLTi$1, 'a_l4svuo4DZFDcDqJbGklzHLTi$1');

function a_l4svuo4DZFDcDqJbGklzHLTi$3(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  t_actRes_4;
  return a_l4svuo4DZFDcDqJbGklzHLTi$1;
}
cs.registerStep(a_l4svuo4DZFDcDqJbGklzHLTi$3, 'a_l4svuo4DZFDcDqJbGklzHLTi$3');

/* ACTION: start timer */
function a_xR8UEUDLaI6qbCw4GQtfFiwQ(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xR8UEUDLaI6qbCw4GQtfFiwQ$0;
  s.name = "start timer";
  return s;
}
cs.registerAction("start timer", "xR8UEUDLaI6qbCw4GQtfFiwQ", a_xR8UEUDLaI6qbCw4GQtfFiwQ, false);

function a_xR8UEUDLaI6qbCw4GQtfFiwQ$0(s) {
  (s.pc = "1.m1");
  var t_call_0 = lib.Time.now(s);
  (/* _start time */ s.d.$TzLNjDeJYpMRpdgNFuqgE2PY = t_call_0);
  s.rt.logDataWrite();
  (s.pc = "1.m4");
  var t_infix_1 = (0 - 1);
  (/* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY = t_infix_1);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_xR8UEUDLaI6qbCw4GQtfFiwQ$0, 'a_xR8UEUDLaI6qbCw4GQtfFiwQ$0');

/* ACTION: start countdown timer */
function a_uCawjS8UtYJd1W4TZkrVvAE7(previous, returnAddr, $seconds) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_uCawjS8UtYJd1W4TZkrVvAE7$0;
  s.name = "start countdown timer";
  s.$seconds = $seconds;
  return s;
}
cs.registerAction("start countdown timer", "uCawjS8UtYJd1W4TZkrVvAE7", a_uCawjS8UtYJd1W4TZkrVvAE7, false);

function a_uCawjS8UtYJd1W4TZkrVvAE7$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_uCawjS8UtYJd1W4TZkrVvAE7$2, lib.RTValue.mkPicker(lib.Number_.picker(), 0, "seconds", "$seconds"));
  return a_uCawjS8UtYJd1W4TZkrVvAE7$2;
  }
  return a_uCawjS8UtYJd1W4TZkrVvAE7$1;
}
cs.registerStep(a_uCawjS8UtYJd1W4TZkrVvAE7$0, 'a_uCawjS8UtYJd1W4TZkrVvAE7$0');

function a_uCawjS8UtYJd1W4TZkrVvAE7$2(s) {
  return a_uCawjS8UtYJd1W4TZkrVvAE7$1;
}
cs.registerStep(a_uCawjS8UtYJd1W4TZkrVvAE7$2, 'a_uCawjS8UtYJd1W4TZkrVvAE7$2');

function a_uCawjS8UtYJd1W4TZkrVvAE7$1(s) {
  (s.pc = "1.r1");
  var t_call_0 = lib.Time.now(s);
  (/* _start time */ s.d.$TzLNjDeJYpMRpdgNFuqgE2PY = t_call_0);
  s.rt.logDataWrite();
  (s.pc = "1.r4");
  (/* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY = s.$seconds);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_uCawjS8UtYJd1W4TZkrVvAE7$1, 'a_uCawjS8UtYJd1W4TZkrVvAE7$1');

/* ACTION: life */
function a_YXmGOuliQ2RYyUc3NtRv9DNE(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_YXmGOuliQ2RYyUc3NtRv9DNE$0;
  s.name = "life";
  s.result = undefined;
  return s;
}
cs.registerAction("life", "YXmGOuliQ2RYyUc3NtRv9DNE", a_YXmGOuliQ2RYyUc3NtRv9DNE, false);

function a_YXmGOuliQ2RYyUc3NtRv9DNE$0(s) {
  (s.pc = "1.w1");
  (s.result = /* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV);
  if (s.previous.needsPicker) {
  s.rt.displayResult("r", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_YXmGOuliQ2RYyUc3NtRv9DNE$0, 'a_YXmGOuliQ2RYyUc3NtRv9DNE$0');

/* ACTION: score */
function a_xleVEbMbZTbU7BJfeUMUPpMk(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xleVEbMbZTbU7BJfeUMUPpMk$0;
  s.name = "score";
  s.result = undefined;
  return s;
}
cs.registerAction("score", "xleVEbMbZTbU7BJfeUMUPpMk", a_xleVEbMbZTbU7BJfeUMUPpMk, false);

function a_xleVEbMbZTbU7BJfeUMUPpMk$0(s) {
  (s.pc = "1.D1");
  (s.result = /* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m);
  if (s.previous.needsPicker) {
  s.rt.displayResult("r", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_xleVEbMbZTbU7BJfeUMUPpMk$0, 'a_xleVEbMbZTbU7BJfeUMUPpMk$0');

/* ACTION: evolve */
function a_gswamj84uYSwqLED2VvLdKi6(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_gswamj84uYSwqLED2VvLdKi6$0;
  s.name = "evolve";
  return s;
}
cs.registerAction("evolve", "gswamj84uYSwqLED2VvLdKi6", a_gswamj84uYSwqLED2VvLdKi6, true);

function a_gswamj84uYSwqLED2VvLdKi6$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "1.J0");
  var t_call_1 = lib.Boolean_.not((/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS == undefined), s);
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.pc = "1.J40");
  s.rt.logObjectMutation(/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS);
  (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.evolve(s));
  var t_elseIf_2 = true;
  (s.pc = "1.J43");
  var t_infix_3 = (ok1(s, /* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV) && (/* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV >= 0));
  ok1(s, t_infix_3);
  if (t_infix_3) {
  (s.pc = "1.J470");
  return s.rt.enter(a_XjXM7AL67NDGlzsZgg9s44uq(s, a_gswamj84uYSwqLED2VvLdKi6$3));
  } else {
  (s.pc = "1.J480");
  null;
  }
  return a_gswamj84uYSwqLED2VvLdKi6$2;
  } else {
  (s.pc = "1.J50");
  null;
  }
  return a_gswamj84uYSwqLED2VvLdKi6$1;
}
cs.registerStep(a_gswamj84uYSwqLED2VvLdKi6$0, 'a_gswamj84uYSwqLED2VvLdKi6$0');

function a_gswamj84uYSwqLED2VvLdKi6$3(s) {
  return a_gswamj84uYSwqLED2VvLdKi6$2;
}
cs.registerStep(a_gswamj84uYSwqLED2VvLdKi6$3, 'a_gswamj84uYSwqLED2VvLdKi6$3');

function a_gswamj84uYSwqLED2VvLdKi6$2(s) {
  var t_elseIf_4 = true;
  (s.pc = "1.J48");
  var t_infix_5 = (ok1(s, /* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m) && (/* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m >= 0));
  ok1(s, t_infix_5);
  if (t_infix_5) {
  (s.pc = "1.J4c0");
  return s.rt.enter(a_ify9GgXEJgKuJ9u1VD6EdWZv(s, a_gswamj84uYSwqLED2VvLdKi6$5));
  } else {
  (s.pc = "1.J4d0");
  null;
  }
  return a_gswamj84uYSwqLED2VvLdKi6$4;
}
cs.registerStep(a_gswamj84uYSwqLED2VvLdKi6$2, 'a_gswamj84uYSwqLED2VvLdKi6$2');

function a_gswamj84uYSwqLED2VvLdKi6$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_gswamj84uYSwqLED2VvLdKi6$1, 'a_gswamj84uYSwqLED2VvLdKi6$1');

function a_gswamj84uYSwqLED2VvLdKi6$5(s) {
  return a_gswamj84uYSwqLED2VvLdKi6$4;
}
cs.registerStep(a_gswamj84uYSwqLED2VvLdKi6$5, 'a_gswamj84uYSwqLED2VvLdKi6$5');

function a_gswamj84uYSwqLED2VvLdKi6$4(s) {
  var t_elseIf_6 = true;
  (s.pc = "1.J4d");
  var t_call_7 = lib.Boolean_.not((/* _start time */ s.d.$TzLNjDeJYpMRpdgNFuqgE2PY == undefined), s);
  ok1(s, t_call_7);
  if (t_call_7) {
  (s.pc = "1.J4h0");
  return s.rt.enter(a_PojbQsm32lz5k054APQR8Jb1(s, a_gswamj84uYSwqLED2VvLdKi6$7));
  } else {
  (s.pc = "1.J4i0");
  null;
  }
  return a_gswamj84uYSwqLED2VvLdKi6$6;
}
cs.registerStep(a_gswamj84uYSwqLED2VvLdKi6$4, 'a_gswamj84uYSwqLED2VvLdKi6$4');

function a_gswamj84uYSwqLED2VvLdKi6$7(s) {
  var t_actRes_8 = s.rt.returnedFrom.result;
  t_actRes_8;
  return a_gswamj84uYSwqLED2VvLdKi6$6;
}
cs.registerStep(a_gswamj84uYSwqLED2VvLdKi6$7, 'a_gswamj84uYSwqLED2VvLdKi6$7');

function a_gswamj84uYSwqLED2VvLdKi6$6(s) {
  return a_gswamj84uYSwqLED2VvLdKi6$1;
}
cs.registerStep(a_gswamj84uYSwqLED2VvLdKi6$6, 'a_gswamj84uYSwqLED2VvLdKi6$6');

/* ACTION: create text */
function a_UMupj4ChNfQ8E2uvW694p1tX(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_UMupj4ChNfQ8E2uvW694p1tX$0;
  s.name = "create text";
  s.result = undefined;
  return s;
}
cs.registerAction("create text", "UMupj4ChNfQ8E2uvW694p1tX", a_UMupj4ChNfQ8E2uvW694p1tX, false);

function ok4(s, a0, a1, a2, a3) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok5(s, a0, a1, a2, a3, a4) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok6(s, a0, a1, a2, a3, a4, a5) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined || a5 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_UMupj4ChNfQ8E2uvW694p1tX$0(s) {
  (s.pc = "1.P0");
  var t_call_0 = (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.create_text(100, 20, 28, "", s));
  s.rt.markAllocated(t_call_0);
  (s.result = t_call_0);
  (s.pc = "1.P3");
  s.rt.logObjectMutation(s.result);
  (ok1(s, s.result) && s.result.set_z_index(1000, s));
  (s.pc = "1.P6");
  s.rt.logObjectMutation(s.result);
  (ok1(s, s.result) && s.result.set_friction(1, s));
  (s.pc = "1.P9");
  var t_call_1 = lib.Colors.foreground(s);
  s.rt.logObjectMutation(s.result);
  (ok2(s, s.result, t_call_1) && s.result.set_color(t_call_1, s));
  return s.rt.leave();
}
cs.registerStep(a_UMupj4ChNfQ8E2uvW694p1tX$0, 'a_UMupj4ChNfQ8E2uvW694p1tX$0');

/* ACTION: evolve life */
function a_XjXM7AL67NDGlzsZgg9s44uq(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_XjXM7AL67NDGlzsZgg9s44uq$0;
  s.name = "evolve life";
  s.$l = undefined;
  s.$s = undefined;
  return s;
}
cs.registerAction("evolve life", "XjXM7AL67NDGlzsZgg9s44uq", a_XjXM7AL67NDGlzsZgg9s44uq, false);

function a_XjXM7AL67NDGlzsZgg9s44uq$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "1.U0");
  true;
  if ((/* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X == undefined)) {
  (s.pc = "1.U40");
  return s.rt.enter(a_UMupj4ChNfQ8E2uvW694p1tX(s, a_XjXM7AL67NDGlzsZgg9s44uq$2));
  } else {
  (s.pc = "1.U50");
  null;
  }
  return a_XjXM7AL67NDGlzsZgg9s44uq$1;
}
cs.registerStep(a_XjXM7AL67NDGlzsZgg9s44uq$0, 'a_XjXM7AL67NDGlzsZgg9s44uq$0');

function a_XjXM7AL67NDGlzsZgg9s44uq$2(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (/* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X = t_actRes_1);
  s.rt.logDataWrite();
  (s.pc = "1.U43");
  var t_call_2 = lib.Colors.red(s);
  s.rt.logObjectMutation(/* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X);
  (ok2(s, /* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X, t_call_2) && /* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X.set_color(t_call_2, s));
  (s.pc = "1.U46");
  s.rt.logObjectMutation(/* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X);
  (ok1(s, /* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X) && /* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X.set_pos(72, 20, s));
  var t_elseIf_3 = true;
  (s.pc = "1.U49");
  var t_call_4 = (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.width(s));
  var t_call_5 = (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.height(s));
  var t_infix_6 = (ok2(s, t_call_4, t_call_5) && (t_call_4 < t_call_5));
  ok1(s, t_infix_6);
  if (t_infix_6) {
  (s.pc = "1.U4d0");
  s.rt.logObjectMutation(/* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X);
  (ok1(s, /* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X) && /* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X.set_x(96, s));
  } else {
  (s.pc = "1.U4e0");
  null;
  }
  return a_XjXM7AL67NDGlzsZgg9s44uq$1;
}
cs.registerStep(a_XjXM7AL67NDGlzsZgg9s44uq$2, 'a_XjXM7AL67NDGlzsZgg9s44uq$2');

function a_XjXM7AL67NDGlzsZgg9s44uq$1(s) {
  (s.pc = "1.U5");
  var t_call_7 = (ok1(s, /* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV) && lib.Math_.ceiling(/* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV, s));
  (s.$l = t_call_7);
  (s.pc = "1.U8");
  var t_call_8 = (ok1(s, s.$l) && lib.Number_.to_string(s.$l, s));
  var t_concat_9 = lib.String_.concatAny("\u2764 ", t_call_8);
  (s.$s = t_concat_9);
  var t_elseIf_10 = true;
  (s.pc = "1.Ub");
  var t_call_11 = (ok1(s, /* _hearts */ s.d.$emzufgdY6lsG2RaaCYaxwN8m) && /* _hearts */ s.d.$emzufgdY6lsG2RaaCYaxwN8m.count(s));
  var t_infix_12 = (ok2(s, s.$l, t_call_11) && (s.$l < t_call_11));
  ok1(s, t_infix_12);
  if (t_infix_12) {
  (s.pc = "1.Uf0");
  var t_call_13 = (ok2(s, /* _hearts */ s.d.$emzufgdY6lsG2RaaCYaxwN8m, s.$l) && /* _hearts */ s.d.$emzufgdY6lsG2RaaCYaxwN8m.at(s.$l, s));
  (s.$s = t_call_13);
  } else {
  (s.pc = "1.Ug0");
  null;
  }
  (s.pc = "1.Ug");
  s.rt.logObjectMutation(/* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X);
  (ok2(s, /* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X, s.$s) && /* _life txt */ s.d.$pHEIAaLyqWXgpyUd6dIeYp2X.set_text(s.$s, s));
  return s.rt.leave();
}
cs.registerStep(a_XjXM7AL67NDGlzsZgg9s44uq$1, 'a_XjXM7AL67NDGlzsZgg9s44uq$1');

/* ACTION: evolve score */
function a_ify9GgXEJgKuJ9u1VD6EdWZv(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_ify9GgXEJgKuJ9u1VD6EdWZv$0;
  s.name = "evolve score";
  s.$x = undefined;
  return s;
}
cs.registerAction("evolve score", "ify9GgXEJgKuJ9u1VD6EdWZv", a_ify9GgXEJgKuJ9u1VD6EdWZv, false);

function a_ify9GgXEJgKuJ9u1VD6EdWZv$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "1.Z0");
  true;
  if ((/* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6 == undefined)) {
  (s.pc = "1.Z40");
  return s.rt.enter(a_UMupj4ChNfQ8E2uvW694p1tX(s, a_ify9GgXEJgKuJ9u1VD6EdWZv$2));
  } else {
  (s.pc = "1.Z50");
  null;
  }
  return a_ify9GgXEJgKuJ9u1VD6EdWZv$1;
}
cs.registerStep(a_ify9GgXEJgKuJ9u1VD6EdWZv$0, 'a_ify9GgXEJgKuJ9u1VD6EdWZv$0');

function a_ify9GgXEJgKuJ9u1VD6EdWZv$2(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (/* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6 = t_actRes_1);
  s.rt.logDataWrite();
  (s.pc = "1.Z43");
  (s.$x = 132);
  (s.pc = "1.Z46");
  var t_call_2 = (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.width(s));
  var t_infix_3 = (ok2(s, t_call_2, s.$x) && (t_call_2 - s.$x));
  s.rt.logObjectMutation(/* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6);
  (ok2(s, /* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6, t_infix_3) && /* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6.set_pos(t_infix_3, 20, s));
  (s.pc = "1.Z49");
  var t_call_4 = lib.Colors.orange(s);
  s.rt.logObjectMutation(/* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6);
  (ok2(s, /* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6, t_call_4) && /* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6.set_color(t_call_4, s));
  return a_ify9GgXEJgKuJ9u1VD6EdWZv$1;
}
cs.registerStep(a_ify9GgXEJgKuJ9u1VD6EdWZv$2, 'a_ify9GgXEJgKuJ9u1VD6EdWZv$2');

function a_ify9GgXEJgKuJ9u1VD6EdWZv$1(s) {
  (s.pc = "1.Z5");
  var t_call_5 = (ok1(s, /* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m) && lib.Math_.ceiling(/* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m, s));
  var t_call_6 = (ok1(s, t_call_5) && lib.Number_.to_string(t_call_5, s));
  var t_concat_7 = lib.String_.concatAny("score\u003a ", t_call_6);
  s.rt.logObjectMutation(/* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6);
  (ok2(s, /* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6, t_concat_7) && /* _score txt */ s.d.$AejJAmPMk38UG2URZk5hXYh6.set_text(t_concat_7, s));
  return s.rt.leave();
}
cs.registerStep(a_ify9GgXEJgKuJ9u1VD6EdWZv$1, 'a_ify9GgXEJgKuJ9u1VD6EdWZv$1');

/* ACTION: evolve timer */
function a_PojbQsm32lz5k054APQR8Jb1(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_PojbQsm32lz5k054APQR8Jb1$0;
  s.name = "evolve timer";
  s.$elapsed = undefined;
  return s;
}
cs.registerAction("evolve timer", "PojbQsm32lz5k054APQR8Jb1", a_PojbQsm32lz5k054APQR8Jb1, true);

function a_PojbQsm32lz5k054APQR8Jb1$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "1.66.0");
  true;
  if ((/* _timer txt */ s.d.$x2fjfvNmVawvnAWKndzdfxls == undefined)) {
  (s.pc = "1.66.40");
  return s.rt.enter(a_UMupj4ChNfQ8E2uvW694p1tX(s, a_PojbQsm32lz5k054APQR8Jb1$2));
  } else {
  (s.pc = "1.66.50");
  null;
  }
  return a_PojbQsm32lz5k054APQR8Jb1$1;
}
cs.registerStep(a_PojbQsm32lz5k054APQR8Jb1$0, 'a_PojbQsm32lz5k054APQR8Jb1$0');

function a_PojbQsm32lz5k054APQR8Jb1$2(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (/* _timer txt */ s.d.$x2fjfvNmVawvnAWKndzdfxls = t_actRes_1);
  s.rt.logDataWrite();
  (s.pc = "1.66.43");
  var t_call_2 = (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.width(s));
  var t_infix_3 = (ok1(s, t_call_2) && (t_call_2 / 2));
  s.rt.logObjectMutation(/* _timer txt */ s.d.$x2fjfvNmVawvnAWKndzdfxls);
  (ok2(s, /* _timer txt */ s.d.$x2fjfvNmVawvnAWKndzdfxls, t_infix_3) && /* _timer txt */ s.d.$x2fjfvNmVawvnAWKndzdfxls.set_pos(t_infix_3, 20, s));
  return a_PojbQsm32lz5k054APQR8Jb1$1;
}
cs.registerStep(a_PojbQsm32lz5k054APQR8Jb1$2, 'a_PojbQsm32lz5k054APQR8Jb1$2');

function a_PojbQsm32lz5k054APQR8Jb1$1(s) {
  (s.pc = "1.66.5");
  return s.rt.enter(a_q4EB482ElguyYpuPEwTgQQ4e(s, a_PojbQsm32lz5k054APQR8Jb1$3));
}
cs.registerStep(a_PojbQsm32lz5k054APQR8Jb1$1, 'a_PojbQsm32lz5k054APQR8Jb1$1');

function a_PojbQsm32lz5k054APQR8Jb1$3(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  (s.$elapsed = t_actRes_4);
  (s.pc = "1.66.8");
  var t_call_5 = (ok1(s, s.$elapsed) && lib.Math_.round_with_precision(s.$elapsed, 1, s));
  var t_call_6 = (ok1(s, t_call_5) && lib.Number_.to_string(t_call_5, s));
  s.rt.logObjectMutation(/* _timer txt */ s.d.$x2fjfvNmVawvnAWKndzdfxls);
  (ok2(s, /* _timer txt */ s.d.$x2fjfvNmVawvnAWKndzdfxls, t_call_6) && /* _timer txt */ s.d.$x2fjfvNmVawvnAWKndzdfxls.set_text(t_call_6, s));
  var t_elseIf_7 = true;
  (s.pc = "1.66.b");
  var t_infix_8 = (ok1(s, /* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY) && (/* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY > 0));
  var t_lazy_9 = t_infix_8;
  if ((ok1(s, t_lazy_9) && t_lazy_9)) {
  var t_infix_10 = (ok1(s, s.$elapsed) && (s.$elapsed === 0));
  (t_lazy_9 = t_infix_10);
  }
  ok1(s, t_lazy_9);
  if (t_lazy_9) {
  (s.pc = "1.66.f0");
  return s.rt.enter(a_a14qLDjp7EtajVvdEd1rS18X(s, a_PojbQsm32lz5k054APQR8Jb1$6));
  } else {
  (s.pc = "1.66.g0");
  null;
  }
  return a_PojbQsm32lz5k054APQR8Jb1$5;
}
cs.registerStep(a_PojbQsm32lz5k054APQR8Jb1$3, 'a_PojbQsm32lz5k054APQR8Jb1$3');

function a_PojbQsm32lz5k054APQR8Jb1$6(s) {
  var t_actRes_11 = s.rt.returnedFrom.result;
  t_actRes_11;
  return a_PojbQsm32lz5k054APQR8Jb1$5;
}
cs.registerStep(a_PojbQsm32lz5k054APQR8Jb1$6, 'a_PojbQsm32lz5k054APQR8Jb1$6');

function a_PojbQsm32lz5k054APQR8Jb1$5(s) {
  return s.rt.leave();
}
cs.registerStep(a_PojbQsm32lz5k054APQR8Jb1$5, 'a_PojbQsm32lz5k054APQR8Jb1$5');

/* ACTION: example */
function a_xK9ECxOm926KPUxdhlTtnYMl(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xK9ECxOm926KPUxdhlTtnYMl$0;
  s.name = "example";
  s.$board = undefined;
  return s;
}
cs.registerAction("example", "xK9ECxOm926KPUxdhlTtnYMl", a_xK9ECxOm926KPUxdhlTtnYMl, true);

function a_xK9ECxOm926KPUxdhlTtnYMl$0(s) {
  (s.pc = "1.74.2");
  return s.rt.enter(a_rUM4WD97vl3DCMmQPvBzb6jc(s, a_xK9ECxOm926KPUxdhlTtnYMl$1));
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$0, 'a_xK9ECxOm926KPUxdhlTtnYMl$0');

function a_xK9ECxOm926KPUxdhlTtnYMl$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_0);
  (s.pc = "1.74.8");
  return s.rt.enter(a_oKY8zayGQ3QsufrQiKXXS9sh(s, a_xK9ECxOm926KPUxdhlTtnYMl$2, 3600));
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$1, 'a_xK9ECxOm926KPUxdhlTtnYMl$1');

function a_xK9ECxOm926KPUxdhlTtnYMl$2(s) {
  (s.pc = "1.74.c");
  return s.rt.enter(a_xINhkUFpWzhMPF0ROZX4TSm4(s, a_xK9ECxOm926KPUxdhlTtnYMl$3, 100));
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$2, 'a_xK9ECxOm926KPUxdhlTtnYMl$2');

function a_xK9ECxOm926KPUxdhlTtnYMl$3(s) {
  (s.pc = "1.74.h");
  return s.rt.enter(a_l4svuo4DZFDcDqJbGklzHLTi(s, a_xK9ECxOm926KPUxdhlTtnYMl$4, 1));
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$3, 'a_xK9ECxOm926KPUxdhlTtnYMl$3');

function a_xK9ECxOm926KPUxdhlTtnYMl$4(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  t_actRes_1;
  (s.pc = "1.74.l");
  return s.rt.enter(a_l0buJlsN2iCiTbJPwUwTGWmO(s, a_xK9ECxOm926KPUxdhlTtnYMl$5, 1));
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$4, 'a_xK9ECxOm926KPUxdhlTtnYMl$4');

function a_xK9ECxOm926KPUxdhlTtnYMl$5(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  t_actRes_2;
  (s.pc = "1.74.o");
  return s.rt.enter(a_qoY1RsaFEb0jJJuZq8SkbAp3(s, a_xK9ECxOm926KPUxdhlTtnYMl$6, 1));
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$5, 'a_xK9ECxOm926KPUxdhlTtnYMl$5');

function a_xK9ECxOm926KPUxdhlTtnYMl$6(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  t_actRes_3;
  (s.pc = "1.74.t");
  return s.rt.enter(a_xR8UEUDLaI6qbCw4GQtfFiwQ(s, a_xK9ECxOm926KPUxdhlTtnYMl$7));
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$6, 'a_xK9ECxOm926KPUxdhlTtnYMl$6');

function a_xK9ECxOm926KPUxdhlTtnYMl$7(s) {
  (s.pc = "1.74.w");
  return s.rt.enter(a_uCawjS8UtYJd1W4TZkrVvAE7(s, a_xK9ECxOm926KPUxdhlTtnYMl$8, 10));
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$7, 'a_xK9ECxOm926KPUxdhlTtnYMl$7');

function a_xK9ECxOm926KPUxdhlTtnYMl$8(s) {
  (s.pc = "1.74.B");
  return s.rt.enter(a_a14qLDjp7EtajVvdEd1rS18X(s, a_xK9ECxOm926KPUxdhlTtnYMl$9));
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$8, 'a_xK9ECxOm926KPUxdhlTtnYMl$8');

function a_xK9ECxOm926KPUxdhlTtnYMl$9(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  t_actRes_4;
  return s.rt.leave();
}
cs.registerStep(a_xK9ECxOm926KPUxdhlTtnYMl$9, 'a_xK9ECxOm926KPUxdhlTtnYMl$9');

/* ACTION: current time */
function a_q4EB482ElguyYpuPEwTgQQ4e(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_q4EB482ElguyYpuPEwTgQQ4e$0;
  s.name = "current time";
  s.result = undefined;
  return s;
}
cs.registerAction("current time", "q4EB482ElguyYpuPEwTgQQ4e", a_q4EB482ElguyYpuPEwTgQQ4e, false);

function a_q4EB482ElguyYpuPEwTgQQ4e$0(s) {
  (s.pc = "1.79.1");
  var t_call_0 = lib.Time.now(s);
  var t_call_1 = (ok2(s, t_call_0, /* _start time */ s.d.$TzLNjDeJYpMRpdgNFuqgE2PY) && t_call_0.subtract(/* _start time */ s.d.$TzLNjDeJYpMRpdgNFuqgE2PY, s));
  (s.result = t_call_1);
  var t_elseIf_2 = true;
  (s.pc = "1.79.4");
  var t_infix_3 = (ok1(s, /* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY) && (/* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY > 0));
  ok1(s, t_infix_3);
  if (t_infix_3) {
  (s.pc = "1.79.80");
  var t_infix_4 = (ok2(s, /* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY, s.result) && (/* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY - s.result));
  var t_call_5 = (ok1(s, t_infix_4) && lib.Math_.max(0, t_infix_4, s));
  (s.result = t_call_5);
  } else {
  (s.pc = "1.79.90");
  null;
  }
  if (s.previous.needsPicker) {
  s.rt.displayResult("seconds", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_q4EB482ElguyYpuPEwTgQQ4e$0, 'a_q4EB482ElguyYpuPEwTgQQ4e$0');

/* ACTION: add score */
function a_xINhkUFpWzhMPF0ROZX4TSm4(previous, returnAddr, $value) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xINhkUFpWzhMPF0ROZX4TSm4$0;
  s.name = "add score";
  s.$value = $value;
  return s;
}
cs.registerAction("add score", "xINhkUFpWzhMPF0ROZX4TSm4", a_xINhkUFpWzhMPF0ROZX4TSm4, false);

function a_xINhkUFpWzhMPF0ROZX4TSm4$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_xINhkUFpWzhMPF0ROZX4TSm4$3, lib.RTValue.mkPicker(lib.Number_.picker(), 0, "value", "$value"));
  return a_xINhkUFpWzhMPF0ROZX4TSm4$3;
  }
  return a_xINhkUFpWzhMPF0ROZX4TSm4$2;
}
cs.registerStep(a_xINhkUFpWzhMPF0ROZX4TSm4$0, 'a_xINhkUFpWzhMPF0ROZX4TSm4$0');

function a_xINhkUFpWzhMPF0ROZX4TSm4$3(s) {
  return a_xINhkUFpWzhMPF0ROZX4TSm4$2;
}
cs.registerStep(a_xINhkUFpWzhMPF0ROZX4TSm4$3, 'a_xINhkUFpWzhMPF0ROZX4TSm4$3');

function a_xINhkUFpWzhMPF0ROZX4TSm4$2(s) {
  (s.pc = "1.85.1");
  var t_infix_0 = (ok2(s, /* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m, s.$value) && (/* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m + s.$value));
  return s.rt.enter(a_oKY8zayGQ3QsufrQiKXXS9sh(s, a_xINhkUFpWzhMPF0ROZX4TSm4$1, t_infix_0));
}
cs.registerStep(a_xINhkUFpWzhMPF0ROZX4TSm4$2, 'a_xINhkUFpWzhMPF0ROZX4TSm4$2');

function a_xINhkUFpWzhMPF0ROZX4TSm4$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_xINhkUFpWzhMPF0ROZX4TSm4$1, 'a_xINhkUFpWzhMPF0ROZX4TSm4$1');

/* ACTION: add life */
function a_l0buJlsN2iCiTbJPwUwTGWmO(previous, returnAddr, $value) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_l0buJlsN2iCiTbJPwUwTGWmO$0;
  s.name = "add life";
  s.$value = $value;
  return s;
}
cs.registerAction("add life", "l0buJlsN2iCiTbJPwUwTGWmO", a_l0buJlsN2iCiTbJPwUwTGWmO, true);

function a_l0buJlsN2iCiTbJPwUwTGWmO$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_l0buJlsN2iCiTbJPwUwTGWmO$3, lib.RTValue.mkPicker(lib.Number_.picker(), 0, "value", "$value"));
  return a_l0buJlsN2iCiTbJPwUwTGWmO$3;
  }
  return a_l0buJlsN2iCiTbJPwUwTGWmO$2;
}
cs.registerStep(a_l0buJlsN2iCiTbJPwUwTGWmO$0, 'a_l0buJlsN2iCiTbJPwUwTGWmO$0');

function a_l0buJlsN2iCiTbJPwUwTGWmO$3(s) {
  return a_l0buJlsN2iCiTbJPwUwTGWmO$2;
}
cs.registerStep(a_l0buJlsN2iCiTbJPwUwTGWmO$3, 'a_l0buJlsN2iCiTbJPwUwTGWmO$3');

function a_l0buJlsN2iCiTbJPwUwTGWmO$2(s) {
  (s.pc = "1.90.1");
  var t_infix_0 = (ok2(s, /* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV, s.$value) && (/* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV + s.$value));
  return s.rt.enter(a_l4svuo4DZFDcDqJbGklzHLTi(s, a_l0buJlsN2iCiTbJPwUwTGWmO$1, t_infix_0));
}
cs.registerStep(a_l0buJlsN2iCiTbJPwUwTGWmO$2, 'a_l0buJlsN2iCiTbJPwUwTGWmO$2');

function a_l0buJlsN2iCiTbJPwUwTGWmO$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  t_actRes_1;
  return s.rt.leave();
}
cs.registerStep(a_l0buJlsN2iCiTbJPwUwTGWmO$1, 'a_l0buJlsN2iCiTbJPwUwTGWmO$1');

/* ACTION: clear timer */
function a_ods2ZuwV9xHaiO5pElQlNyaE(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_ods2ZuwV9xHaiO5pElQlNyaE$0;
  s.name = "clear timer";
  return s;
}
cs.registerAction("clear timer", "ods2ZuwV9xHaiO5pElQlNyaE", a_ods2ZuwV9xHaiO5pElQlNyaE, false);

function a_ods2ZuwV9xHaiO5pElQlNyaE$0(s) {
  (s.pc = "1.95.1");
  var t_call_0 = lib.Invalid.datetime(s);
  (/* _start time */ s.d.$TzLNjDeJYpMRpdgNFuqgE2PY = t_call_0);
  s.rt.logDataWrite();
  (s.pc = "1.95.4");
  var t_infix_1 = (0 - 1);
  (/* _countdown duration */ s.d.$x4cIV8c7P0QJsADCfcHm2ApY = t_infix_1);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_ods2ZuwV9xHaiO5pElQlNyaE$0, 'a_ods2ZuwV9xHaiO5pElQlNyaE$0');

/* ACTION: remove life */
function a_qoY1RsaFEb0jJJuZq8SkbAp3(previous, returnAddr, $value) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_qoY1RsaFEb0jJJuZq8SkbAp3$0;
  s.name = "remove life";
  s.$value = $value;
  return s;
}
cs.registerAction("remove life", "qoY1RsaFEb0jJJuZq8SkbAp3", a_qoY1RsaFEb0jJJuZq8SkbAp3, true);

function a_qoY1RsaFEb0jJJuZq8SkbAp3$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_qoY1RsaFEb0jJJuZq8SkbAp3$3, lib.RTValue.mkPicker(lib.Number_.picker(), 0, "value", "$value"));
  return a_qoY1RsaFEb0jJJuZq8SkbAp3$3;
  }
  return a_qoY1RsaFEb0jJJuZq8SkbAp3$2;
}
cs.registerStep(a_qoY1RsaFEb0jJJuZq8SkbAp3$0, 'a_qoY1RsaFEb0jJJuZq8SkbAp3$0');

function a_qoY1RsaFEb0jJJuZq8SkbAp3$3(s) {
  return a_qoY1RsaFEb0jJJuZq8SkbAp3$2;
}
cs.registerStep(a_qoY1RsaFEb0jJJuZq8SkbAp3$3, 'a_qoY1RsaFEb0jJJuZq8SkbAp3$3');

function a_qoY1RsaFEb0jJJuZq8SkbAp3$2(s) {
  (s.pc = "1.100.1");
  var t_infix_0 = (ok2(s, /* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV, s.$value) && (/* _life */ s.d.$xubkD4SENn7AllzejMhYSTOV - s.$value));
  return s.rt.enter(a_l4svuo4DZFDcDqJbGklzHLTi(s, a_qoY1RsaFEb0jJJuZq8SkbAp3$1, t_infix_0));
}
cs.registerStep(a_qoY1RsaFEb0jJJuZq8SkbAp3$2, 'a_qoY1RsaFEb0jJJuZq8SkbAp3$2');

function a_qoY1RsaFEb0jJJuZq8SkbAp3$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  t_actRes_1;
  return s.rt.leave();
}
cs.registerStep(a_qoY1RsaFEb0jJJuZq8SkbAp3$1, 'a_qoY1RsaFEb0jJJuZq8SkbAp3$1');

/* ACTION: end */
function a_a14qLDjp7EtajVvdEd1rS18X(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a14qLDjp7EtajVvdEd1rS18X$0;
  s.name = "end";
  return s;
}
cs.registerAction("end", "a14qLDjp7EtajVvdEd1rS18X", a_a14qLDjp7EtajVvdEd1rS18X, true);

function a_a14qLDjp7EtajVvdEd1rS18X$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "1.105.1");
  var t_call_1 = lib.Boolean_.not((/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS == undefined), s);
  ok1(s, t_call_1);
  if (t_call_1) {
  var t_elseIf_2 = true;
  (s.pc = "1.105.50");
  var t_call_3 = lib.Boolean_.not((/* _end event */ s.d.$Eu2dngMaA73jYqD6d0u8iCju == undefined), s);
  ok1(s, t_call_3);
  if (t_call_3) {
  (s.pc = "1.105.540");
  return s.rt.enter((ok1(s, /* _end event */ s.d.$Eu2dngMaA73jYqD6d0u8iCju) && /* _end event */ s.d.$Eu2dngMaA73jYqD6d0u8iCju(s, a_a14qLDjp7EtajVvdEd1rS18X$3)));
  } else {
  var t_elseIf_4 = true;
  (s.pc = "1.105.550");
  var t_infix_5 = (ok1(s, /* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m) && (/* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m > 0));
  ok1(s, t_infix_5);
  if (t_infix_5) {
  (s.pc = "1.105.5540");
  s.rt.logObjectMutation(null);
  var t_resumeCtx_6 = s.rt.getAwaitResumeCtx(a_a14qLDjp7EtajVvdEd1rS18X$6);
  (ok1(s, /* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m) && lib.Bazaar.post_leaderboard_score(/* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m, t_resumeCtx_6));
  return a_a14qLDjp7EtajVvdEd1rS18X$6;
  } else {
  (s.pc = "1.105.5550");
  null;
  }
  return a_a14qLDjp7EtajVvdEd1rS18X$5;
  }
  return a_a14qLDjp7EtajVvdEd1rS18X$2;
  } else {
  (s.pc = "1.105.60");
  null;
  }
  return a_a14qLDjp7EtajVvdEd1rS18X$1;
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$0, 'a_a14qLDjp7EtajVvdEd1rS18X$0');

function a_a14qLDjp7EtajVvdEd1rS18X$3(s) {
  (s.pc = "1.105.543");
  return s.rt.enter(a_Kv3t1TJgZdpYJpx9reGXtTW2(s, a_a14qLDjp7EtajVvdEd1rS18X$4));
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$3, 'a_a14qLDjp7EtajVvdEd1rS18X$3');

function a_a14qLDjp7EtajVvdEd1rS18X$6(s) {
  return a_a14qLDjp7EtajVvdEd1rS18X$5;
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$6, 'a_a14qLDjp7EtajVvdEd1rS18X$6');

function a_a14qLDjp7EtajVvdEd1rS18X$5(s) {
  (s.pc = "1.105.555");
  return s.rt.enter(a_joFUGC04wxnpsBuC02e32Cvy(s, a_a14qLDjp7EtajVvdEd1rS18X$7));
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$5, 'a_a14qLDjp7EtajVvdEd1rS18X$5');

function a_a14qLDjp7EtajVvdEd1rS18X$2(s) {
  return a_a14qLDjp7EtajVvdEd1rS18X$1;
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$2, 'a_a14qLDjp7EtajVvdEd1rS18X$2');

function a_a14qLDjp7EtajVvdEd1rS18X$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$1, 'a_a14qLDjp7EtajVvdEd1rS18X$1');

function a_a14qLDjp7EtajVvdEd1rS18X$4(s) {
  return a_a14qLDjp7EtajVvdEd1rS18X$2;
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$4, 'a_a14qLDjp7EtajVvdEd1rS18X$4');

function a_a14qLDjp7EtajVvdEd1rS18X$7(s) {
  var t_actRes_7 = s.rt.returnedFrom.result;
  t_actRes_7;
  var t_elseIf_8 = true;
  (s.pc = "1.105.558");
  var t_infix_9 = (ok1(s, /* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m) && (/* _score */ s.d.$lp3pSLpGr7O3RGbDzuSQiJ5m > 0));
  ok1(s, t_infix_9);
  if (t_infix_9) {
  (s.pc = "1.105.55c0");
  lib.Wall.clear(s);
  (s.pc = "1.105.55c3");
  var t_resumeCtx_10 = s.rt.getBlockingResumeCtx(a_a14qLDjp7EtajVvdEd1rS18X$9);
  lib.Bazaar.post_leaderboard_to_wall(t_resumeCtx_10);
  return a_a14qLDjp7EtajVvdEd1rS18X$9;
  } else {
  (s.pc = "1.105.55d0");
  null;
  }
  return a_a14qLDjp7EtajVvdEd1rS18X$8;
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$7, 'a_a14qLDjp7EtajVvdEd1rS18X$7');

function a_a14qLDjp7EtajVvdEd1rS18X$9(s) {
  return a_a14qLDjp7EtajVvdEd1rS18X$8;
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$9, 'a_a14qLDjp7EtajVvdEd1rS18X$9');

function a_a14qLDjp7EtajVvdEd1rS18X$8(s) {
  (s.pc = "1.105.55d");
  return s.rt.enter(a_Kv3t1TJgZdpYJpx9reGXtTW2(s, a_a14qLDjp7EtajVvdEd1rS18X$10));
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$8, 'a_a14qLDjp7EtajVvdEd1rS18X$8');

function a_a14qLDjp7EtajVvdEd1rS18X$10(s) {
  (s.pc = "1.105.55g");
  lib.Time.stop(s);
  return a_a14qLDjp7EtajVvdEd1rS18X$2;
}
cs.registerStep(a_a14qLDjp7EtajVvdEd1rS18X$10, 'a_a14qLDjp7EtajVvdEd1rS18X$10');

/* ACTION: start */
function a_rUM4WD97vl3DCMmQPvBzb6jc(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_rUM4WD97vl3DCMmQPvBzb6jc$0;
  s.name = "start";
  s.result = undefined;
  return s;
}
cs.registerAction("start", "rUM4WD97vl3DCMmQPvBzb6jc", a_rUM4WD97vl3DCMmQPvBzb6jc, true);

function a_rUM4WD97vl3DCMmQPvBzb6jc$0(s) {
  (s.pc = "1.110.1");
  var t_infix_0 = (0 - 1);
  var t_infix_1 = (0 - 1);
  return s.rt.enter(a_XQPjg13t37zIEtpt44U6ff92(s, a_rUM4WD97vl3DCMmQPvBzb6jc$1, t_infix_0, t_infix_1));
}
cs.registerStep(a_rUM4WD97vl3DCMmQPvBzb6jc$0, 'a_rUM4WD97vl3DCMmQPvBzb6jc$0');

function a_rUM4WD97vl3DCMmQPvBzb6jc$1(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  (s.result = t_actRes_2);
  if (s.previous.needsPicker) {
  s.rt.displayResult("board", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_rUM4WD97vl3DCMmQPvBzb6jc$1, 'a_rUM4WD97vl3DCMmQPvBzb6jc$1');

/* ACTION: game over */
function a_joFUGC04wxnpsBuC02e32Cvy(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_joFUGC04wxnpsBuC02e32Cvy$0;
  s.name = "game over";
  s.$message = undefined;
  s.$text = undefined;
  s.$i = undefined;
  return s;
}
cs.registerAction("game over", "joFUGC04wxnpsBuC02e32Cvy", a_joFUGC04wxnpsBuC02e32Cvy, true);

function a_joFUGC04wxnpsBuC02e32Cvy$0(s) {
  (s.pc = "1.115.0");
  (s.$message = "Game Over");
  (s.pc = "1.115.3");
  var t_call_0 = (ok2(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS, s.$message) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.create_text(200, 40, 40, s.$message, s));
  s.rt.markAllocated(t_call_0);
  (s.$text = t_call_0);
  (s.pc = "1.115.6");
  s.rt.logObjectMutation(s.$text);
  (ok1(s, s.$text) && s.$text.set_opacity(0, s));
  (s.pc = "1.115.9");
  var t_infix_1 = (720 / 5);
  s.t_bnd_2 = t_infix_1;
  (s.$i = 0);
  return a_joFUGC04wxnpsBuC02e32Cvy$1;
}
cs.registerStep(a_joFUGC04wxnpsBuC02e32Cvy$0, 'a_joFUGC04wxnpsBuC02e32Cvy$0');

function a_joFUGC04wxnpsBuC02e32Cvy$1(s) {
  if ((s.$i < s.t_bnd_2)) {
  (s.pc = "1.115.d0");
  var t_call_3 = (ok1(s, s.$text) && s.$text.opacity(s));
  var t_infix_4 = (ok1(s, t_call_3) && (t_call_3 + 0.05));
  s.rt.logObjectMutation(s.$text);
  (ok2(s, s.$text, t_infix_4) && s.$text.set_opacity(t_infix_4, s));
  (s.pc = "1.115.d3");
  var t_call_5 = lib.Colors.random(s);
  s.rt.logObjectMutation(s.$text);
  (ok2(s, s.$text, t_call_5) && s.$text.set_color(t_call_5, s));
  (s.pc = "1.115.d6");
  var t_call_6 = (ok1(s, s.$text) && s.$text.angle(s));
  var t_infix_7 = (ok1(s, t_call_6) && (t_call_6 + 5));
  s.rt.logObjectMutation(s.$text);
  (ok2(s, s.$text, t_infix_7) && s.$text.set_angle(t_infix_7, s));
  (s.pc = "1.115.d9");
  s.rt.logObjectMutation(/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS);
  (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.update_on_wall(s));
  (s.pc = "1.115.dc");
  var t_resumeCtx_8 = s.rt.getAwaitResumeCtx(a_joFUGC04wxnpsBuC02e32Cvy$3);
  lib.Time.sleep(0.02, t_resumeCtx_8);
  return a_joFUGC04wxnpsBuC02e32Cvy$3;
  }
  (s.pc = "1.115.d");
  var t_resumeCtx_9 = s.rt.getAwaitResumeCtx(a_joFUGC04wxnpsBuC02e32Cvy$4);
  lib.Time.sleep(2, t_resumeCtx_9);
  return a_joFUGC04wxnpsBuC02e32Cvy$4;
}
cs.registerStep(a_joFUGC04wxnpsBuC02e32Cvy$1, 'a_joFUGC04wxnpsBuC02e32Cvy$1');

function a_joFUGC04wxnpsBuC02e32Cvy$3(s) {
  (s.$i++);
  return a_joFUGC04wxnpsBuC02e32Cvy$1;
}
cs.registerStep(a_joFUGC04wxnpsBuC02e32Cvy$3, 'a_joFUGC04wxnpsBuC02e32Cvy$3');

function a_joFUGC04wxnpsBuC02e32Cvy$4(s) {
  (s.pc = "1.115.g");
  s.rt.logObjectMutation(s.$text);
  (ok1(s, s.$text) && s.$text.delete_(s));
  (s.pc = "1.115.j");
  s.rt.logObjectMutation(/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS);
  (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.update_on_wall(s));
  return s.rt.leave();
}
cs.registerStep(a_joFUGC04wxnpsBuC02e32Cvy$4, 'a_joFUGC04wxnpsBuC02e32Cvy$4');

/* ACTION: reset */
function a_Kv3t1TJgZdpYJpx9reGXtTW2(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Kv3t1TJgZdpYJpx9reGXtTW2$0;
  s.name = "reset";
  return s;
}
cs.registerAction("reset", "Kv3t1TJgZdpYJpx9reGXtTW2", a_Kv3t1TJgZdpYJpx9reGXtTW2, false);

function a_Kv3t1TJgZdpYJpx9reGXtTW2$0(s) {
  (s.pc = "1.120.1");
  return s.rt.enter(a_xpQAnETcU9aowS6g7p1qZZbf(s, a_Kv3t1TJgZdpYJpx9reGXtTW2$1));
}
cs.registerStep(a_Kv3t1TJgZdpYJpx9reGXtTW2$0, 'a_Kv3t1TJgZdpYJpx9reGXtTW2$0');

function a_Kv3t1TJgZdpYJpx9reGXtTW2$1(s) {
  (s.pc = "1.120.4");
  var t_call_0 = lib.Invalid.action(s);
  (/* _end event */ s.d.$Eu2dngMaA73jYqD6d0u8iCju = t_call_0);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_Kv3t1TJgZdpYJpx9reGXtTW2$1, 'a_Kv3t1TJgZdpYJpx9reGXtTW2$1');

/* ACTION: start with fixed size */
function a_XQPjg13t37zIEtpt44U6ff92(previous, returnAddr, $width, $height) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_XQPjg13t37zIEtpt44U6ff92$0;
  s.name = "start with fixed size";
  s.$width = $width;
  s.$height = $height;
  s.result = undefined;
  s.$perform = undefined;
  return s;
}
cs.registerAction("start with fixed size", "XQPjg13t37zIEtpt44U6ff92", a_XQPjg13t37zIEtpt44U6ff92, true);

function a_XQPjg13t37zIEtpt44U6ff92$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_XQPjg13t37zIEtpt44U6ff92$5, lib.RTValue.mkPicker(lib.Number_.picker(), 0, "width", "$width"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "height", "$height"));
  return a_XQPjg13t37zIEtpt44U6ff92$5;
  }
  return a_XQPjg13t37zIEtpt44U6ff92$4;
}
cs.registerStep(a_XQPjg13t37zIEtpt44U6ff92$0, 'a_XQPjg13t37zIEtpt44U6ff92$0');

function a_XQPjg13t37zIEtpt44U6ff92$5(s) {
  return a_XQPjg13t37zIEtpt44U6ff92$4;
}
cs.registerStep(a_XQPjg13t37zIEtpt44U6ff92$5, 'a_XQPjg13t37zIEtpt44U6ff92$5');

function a_XQPjg13t37zIEtpt44U6ff92$4(s) {
  (s.pc = "1.125.1");
  return s.rt.enter(a_xpQAnETcU9aowS6g7p1qZZbf(s, a_XQPjg13t37zIEtpt44U6ff92$1));
}
cs.registerStep(a_XQPjg13t37zIEtpt44U6ff92$4, 'a_XQPjg13t37zIEtpt44U6ff92$4');

function a_XQPjg13t37zIEtpt44U6ff92$1(s) {
  (s.pc = "1.125.4");
  return s.rt.enter(a_Ayu95FKZqA9xPdjQXSANLGvP(s, a_XQPjg13t37zIEtpt44U6ff92$2, s.$width, s.$height));
}
cs.registerStep(a_XQPjg13t37zIEtpt44U6ff92$1, 'a_XQPjg13t37zIEtpt44U6ff92$1');

function a_XQPjg13t37zIEtpt44U6ff92$2(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  t_actRes_0;
  (s.pc = "1.125.b0");
  var t_lmbProxy_1 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_XQPjg13t37zIEtpt44U6ff92$3(t_lmbProxy_1(la0), la1) });
  (s.pc = "1.125.7");
  var t_call_2 = (ok2(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS, s.$perform) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.add_on_every_frame(s.$perform, s));
  t_call_2;
  (s.pc = "1.125.b");
  (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.post_to_wall(s));
  (s.pc = "1.125.e");
  (s.result = /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS);
  (s.pc = "1.125.h");
  lib.App.log("game\u003a end initialize", s);
  if (s.previous.needsPicker) {
  s.rt.displayResult("board", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_XQPjg13t37zIEtpt44U6ff92$2, 'a_XQPjg13t37zIEtpt44U6ff92$2');

/* ACTION: a_XQPjg13t37zIEtpt44U6ff92::lambda::3 */
function a_a_XQPjg13t37zIEtpt44U6ff92$3(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_XQPjg13t37zIEtpt44U6ff92$3$0;
  s.name = "start with fixed size";
  return s;
}
cs.registerLambda("a_XQPjg13t37zIEtpt44U6ff92\u003a\u003alambda\u003a\u003a3", "a_XQPjg13t37zIEtpt44U6ff92$3", a_a_XQPjg13t37zIEtpt44U6ff92$3, true);

function a_a_XQPjg13t37zIEtpt44U6ff92$3$0(s) {
  (s.pc = "1.125.b20");
  return s.rt.enter(a_gswamj84uYSwqLED2VvLdKi6(s, a_a_XQPjg13t37zIEtpt44U6ff92$3$1));
}
cs.registerStep(a_a_XQPjg13t37zIEtpt44U6ff92$3$0, 'a_a_XQPjg13t37zIEtpt44U6ff92$3$0');

function a_a_XQPjg13t37zIEtpt44U6ff92$3$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  t_actRes_0;
  var t_elseIf_1 = true;
  (s.pc = "1.125.b23");
  var t_call_2 = lib.Boolean_.not((/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS == undefined), s);
  ok1(s, t_call_2);
  if (t_call_2) {
  (s.pc = "1.125.b270");
  s.rt.logObjectMutation(/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS);
  (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.update_on_wall(s));
  } else {
  (s.pc = "1.125.b280");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_a_XQPjg13t37zIEtpt44U6ff92$3$1, 'a_a_XQPjg13t37zIEtpt44U6ff92$3$1');

/* ACTION: start with background picture */
function a_A69js6TDtOSLAIAQQr6S33zC(previous, returnAddr, $pic) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_A69js6TDtOSLAIAQQr6S33zC$0;
  s.name = "start with background picture";
  s.$pic = $pic;
  s.result = undefined;
  return s;
}
cs.registerAction("start with background picture", "A69js6TDtOSLAIAQQr6S33zC", a_A69js6TDtOSLAIAQQr6S33zC, true);

function a_A69js6TDtOSLAIAQQr6S33zC$0(s) {
  (s.pc = "1.130.1");
  var t_resumeCtx_0 = s.rt.getBlockingResumeCtx(a_A69js6TDtOSLAIAQQr6S33zC$1);
  var t_call_1 = (ok1(s, s.$pic) && s.$pic.width(t_resumeCtx_0));
  return a_A69js6TDtOSLAIAQQr6S33zC$1;
}
cs.registerStep(a_A69js6TDtOSLAIAQQr6S33zC$0, 'a_A69js6TDtOSLAIAQQr6S33zC$0');

function a_A69js6TDtOSLAIAQQr6S33zC$1(s) {
  s.t_pauseRes_2 = s.pauseValue;
  var t_resumeCtx_3 = s.rt.getBlockingResumeCtx(a_A69js6TDtOSLAIAQQr6S33zC$2);
  var t_call_4 = (ok1(s, s.$pic) && s.$pic.height(t_resumeCtx_3));
  return a_A69js6TDtOSLAIAQQr6S33zC$2;
}
cs.registerStep(a_A69js6TDtOSLAIAQQr6S33zC$1, 'a_A69js6TDtOSLAIAQQr6S33zC$1');

function a_A69js6TDtOSLAIAQQr6S33zC$2(s) {
  var t_pauseRes_5 = s.pauseValue;
  return s.rt.enter(a_XQPjg13t37zIEtpt44U6ff92(s, a_A69js6TDtOSLAIAQQr6S33zC$3, s.t_pauseRes_2, t_pauseRes_5));
}
cs.registerStep(a_A69js6TDtOSLAIAQQr6S33zC$2, 'a_A69js6TDtOSLAIAQQr6S33zC$2');

function a_A69js6TDtOSLAIAQQr6S33zC$3(s) {
  var t_actRes_6 = s.rt.returnedFrom.result;
  (s.result = t_actRes_6);
  (s.pc = "1.130.4");
  s.rt.logObjectMutation(s.result);
  var t_resumeCtx_7 = s.rt.getBlockingResumeCtx(a_A69js6TDtOSLAIAQQr6S33zC$4);
  (ok2(s, s.result, s.$pic) && s.result.set_background_picture(s.$pic, t_resumeCtx_7));
  return a_A69js6TDtOSLAIAQQr6S33zC$4;
}
cs.registerStep(a_A69js6TDtOSLAIAQQr6S33zC$3, 'a_A69js6TDtOSLAIAQQr6S33zC$3');

function a_A69js6TDtOSLAIAQQr6S33zC$4(s) {
  return s.rt.leave();
}
cs.registerStep(a_A69js6TDtOSLAIAQQr6S33zC$4, 'a_A69js6TDtOSLAIAQQr6S33zC$4');

/* ACTION: board */
function a_y5RrO2ILX7gVIvFQMpo6XjGo(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_y5RrO2ILX7gVIvFQMpo6XjGo$0;
  s.name = "board";
  s.result = undefined;
  return s;
}
cs.registerAction("board", "y5RrO2ILX7gVIvFQMpo6XjGo", a_y5RrO2ILX7gVIvFQMpo6XjGo, false);

function a_y5RrO2ILX7gVIvFQMpo6XjGo$0(s) {
  (s.pc = "1.135.1");
  (s.result = /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS);
  if (s.previous.needsPicker) {
  s.rt.displayResult("board", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_y5RrO2ILX7gVIvFQMpo6XjGo$0, 'a_y5RrO2ILX7gVIvFQMpo6XjGo$0');

/* ACTION: on end */
function a_xTv6Ulq3EWIRTV6f6oXlbDh9(previous, returnAddr, $action) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xTv6Ulq3EWIRTV6f6oXlbDh9$0;
  s.name = "on end";
  s.$action = $action;
  return s;
}
cs.registerAction("on end", "xTv6Ulq3EWIRTV6f6oXlbDh9", a_xTv6Ulq3EWIRTV6f6oXlbDh9, false);

function a_xTv6Ulq3EWIRTV6f6oXlbDh9$0(s) {
  (s.pc = "1.141.1");
  (/* _end event */ s.d.$Eu2dngMaA73jYqD6d0u8iCju = s.$action);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_xTv6Ulq3EWIRTV6f6oXlbDh9$0, 'a_xTv6Ulq3EWIRTV6f6oXlbDh9$0');

/* ACTION: test on end */
function a_Xd5cD2v2HyMBTyiuwycN9lHa(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Xd5cD2v2HyMBTyiuwycN9lHa$0;
  s.name = "test on end";
  s.$action = undefined;
  return s;
}
cs.registerAction("test on end", "Xd5cD2v2HyMBTyiuwycN9lHa", a_Xd5cD2v2HyMBTyiuwycN9lHa, true);

function a_Xd5cD2v2HyMBTyiuwycN9lHa$0(s) {
  (s.pc = "1.146.40");
  var t_lmbProxy_0 = s.libs.mkLambdaProxy;
  (s.$action = function(la0, la1) { return a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1(t_lmbProxy_0(la0), la1) });
  (s.pc = "1.146.0");
  return s.rt.enter(a_xTv6Ulq3EWIRTV6f6oXlbDh9(s, a_Xd5cD2v2HyMBTyiuwycN9lHa$2, s.$action));
}
cs.registerStep(a_Xd5cD2v2HyMBTyiuwycN9lHa$0, 'a_Xd5cD2v2HyMBTyiuwycN9lHa$0');

function a_Xd5cD2v2HyMBTyiuwycN9lHa$2(s) {
  (s.pc = "1.146.4");
  return s.rt.enter(a_rUM4WD97vl3DCMmQPvBzb6jc(s, a_Xd5cD2v2HyMBTyiuwycN9lHa$3));
}
cs.registerStep(a_Xd5cD2v2HyMBTyiuwycN9lHa$2, 'a_Xd5cD2v2HyMBTyiuwycN9lHa$2');

function a_Xd5cD2v2HyMBTyiuwycN9lHa$3(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  t_actRes_1;
  (s.pc = "1.146.7");
  return s.rt.enter(a_a14qLDjp7EtajVvdEd1rS18X(s, a_Xd5cD2v2HyMBTyiuwycN9lHa$4));
}
cs.registerStep(a_Xd5cD2v2HyMBTyiuwycN9lHa$3, 'a_Xd5cD2v2HyMBTyiuwycN9lHa$3');

function a_Xd5cD2v2HyMBTyiuwycN9lHa$4(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  t_actRes_2;
  return s.rt.leave();
}
cs.registerStep(a_Xd5cD2v2HyMBTyiuwycN9lHa$4, 'a_Xd5cD2v2HyMBTyiuwycN9lHa$4');

/* ACTION: a_Xd5cD2v2HyMBTyiuwycN9lHa::lambda::1 */
function a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1$0;
  s.name = "test on end";
  return s;
}
cs.registerLambda("a_Xd5cD2v2HyMBTyiuwycN9lHa\u003a\u003alambda\u003a\u003a1", "a_Xd5cD2v2HyMBTyiuwycN9lHa$1", a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1, true);

function a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1$0(s) {
  (s.pc = "1.146.420");
  var t_resumeCtx_0 = s.rt.getBlockingResumeCtx(a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1$1);
  lib.Wall.prompt("on end called", t_resumeCtx_0);
  return a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1$1;
}
cs.registerStep(a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1$0, 'a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1$0');

function a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1$1, 'a_a_Xd5cD2v2HyMBTyiuwycN9lHa$1$1');

/* ACTION: test */
function a_xOu0vfXrzi94ugA9AcysN2bf(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xOu0vfXrzi94ugA9AcysN2bf$0;
  s.name = "test";
  s.$board = undefined;
  s.$sprite = undefined;
  return s;
}
cs.registerAction("test", "xOu0vfXrzi94ugA9AcysN2bf", a_xOu0vfXrzi94ugA9AcysN2bf, true);

function a_xOu0vfXrzi94ugA9AcysN2bf$0(s) {
  (s.pc = "1.151.0");
  return s.rt.enter(a_rUM4WD97vl3DCMmQPvBzb6jc(s, a_xOu0vfXrzi94ugA9AcysN2bf$1));
}
cs.registerStep(a_xOu0vfXrzi94ugA9AcysN2bf$0, 'a_xOu0vfXrzi94ugA9AcysN2bf$0');

function a_xOu0vfXrzi94ugA9AcysN2bf$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_0);
  (s.pc = "1.151.3");
  s.rt.logObjectMutation(s.$board);
  (ok1(s, s.$board) && s.$board.set_gravity(0, 200, s));
  (s.pc = "1.151.6");
  s.rt.logObjectMutation(s.$board);
  (ok1(s, s.$board) && s.$board.create_boundary(0, s));
  (s.pc = "1.151.9");
  var t_call_1 = (ok1(s, s.$board) && s.$board.create_rectangle(20, 20, s));
  s.rt.markAllocated(t_call_1);
  (s.$sprite = t_call_1);
  (s.pc = "1.151.c");
  var t_call_2 = lib.Colors.random(s);
  s.rt.logObjectMutation(s.$sprite);
  (ok2(s, s.$sprite, t_call_2) && s.$sprite.set_color(t_call_2, s));
  return s.rt.leave();
}
cs.registerStep(a_xOu0vfXrzi94ugA9AcysN2bf$1, 'a_xOu0vfXrzi94ugA9AcysN2bf$1');

/* ACTION: clear board */
function a_xpQAnETcU9aowS6g7p1qZZbf(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xpQAnETcU9aowS6g7p1qZZbf$0;
  s.name = "clear board";
  return s;
}
cs.registerAction("clear board", "xpQAnETcU9aowS6g7p1qZZbf", a_xpQAnETcU9aowS6g7p1qZZbf, false);

function a_xpQAnETcU9aowS6g7p1qZZbf$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "1.156.0");
  var t_call_1 = lib.Boolean_.not((/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS == undefined), s);
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.pc = "1.156.40");
  (ok1(s, /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS) && /* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS.clear_every_frame_timers(s));
  } else {
  (s.pc = "1.156.50");
  null;
  }
  (s.pc = "1.156.5");
  var t_call_2 = lib.Invalid.board(s);
  (/* _board */ s.d.$xW5SJ4MKJ44wSSDVuZgZG3iS = t_call_2);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_xpQAnETcU9aowS6g7p1qZZbf$0, 'a_xpQAnETcU9aowS6g7p1qZZbf$0');

cs.startFn = function(rt) {
lib.App.rt_start(rt);
lib.Player.rt_start(rt);
lib.Senses.rt_start(rt);
lib.Time.rt_start(rt);
lib.Web.rt_start(rt);
};

cs.stopFn = function(rt) {
lib.App.rt_stop(rt);
lib.Player.rt_stop(rt);
lib.Senses.rt_stop(rt);
lib.Time.rt_stop(rt);
lib.Web.rt_stop(rt);
};

cs._compilerVersion = '1';cs._initGlobals = function(d) {
  if(!d.hasOwnProperty("$xubkD4SENn7AllzejMhYSTOV")) d.$xubkD4SENn7AllzejMhYSTOV = 0;
  if(!d.hasOwnProperty("$lp3pSLpGr7O3RGbDzuSQiJ5m")) d.$lp3pSLpGr7O3RGbDzuSQiJ5m = 0;
  if(!d.hasOwnProperty("$TzLNjDeJYpMRpdgNFuqgE2PY")) d.$TzLNjDeJYpMRpdgNFuqgE2PY = lib.DateTime.defaultValue;
  if(!d.hasOwnProperty("$x4cIV8c7P0QJsADCfcHm2ApY")) d.$x4cIV8c7P0QJsADCfcHm2ApY = 0;

};

cs._initGlobals2 = function(d) {
};

cs._resetGlobals = function(d) {
  d.$xW5SJ4MKJ44wSSDVuZgZG3iS = undefined;
  d.$xubkD4SENn7AllzejMhYSTOV = 0;
  d.$lp3pSLpGr7O3RGbDzuSQiJ5m = 0;
  d.$TzLNjDeJYpMRpdgNFuqgE2PY = lib.DateTime.defaultValue;
  d.$pHEIAaLyqWXgpyUd6dIeYp2X = undefined;
  d.$AejJAmPMk38UG2URZk5hXYh6 = undefined;
  d.$x2fjfvNmVawvnAWKndzdfxls = undefined;
  d.$x4cIV8c7P0QJsADCfcHm2ApY = 0;
  d.$emzufgdY6lsG2RaaCYaxwN8m = undefined;
  d.$Eu2dngMaA73jYqD6d0u8iCju = undefined;
};

cs.mainActionName = "set score";
cs.authorId = "jjef";
cs.scriptId = "vroyc";
}),

// **************************************************************
"vk4YirHiqGbPTNTjv1IL5dsL": (function (cs) {
'use strict';
var libs = cs.libs = {};
var lib = TDev.RT;
var callstackcurdepth = 0;
cs.scriptTitle = "joystick";
cs.scriptColor = "\u00239955bb";
/* ACTION: example */
function a_main(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_main$0;
  s.name = "example";
  s.$board = undefined;
  s.$sprite = undefined;
  s.$p = undefined;
  return s;
}
cs.registerAction("example", "main", a_main, true);

function ok1(s, a0) {
  return (a0 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok2(s, a0, a1) {
  return (a0 == undefined || a1 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok3(s, a0, a1, a2) {
  return (a0 == undefined || a1 == undefined || a2 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok4(s, a0, a1, a2, a3) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_main$0(s) {
  (s.pc = "2.62");
  var t_libcall_0 = s.libs["vIOEa4LjBL2h78vLd1Ls3U5z"]["start"](s);
  return s.rt.enter(t_libcall_0.invoke(t_libcall_0, a_main$1));
}
cs.registerStep(a_main$0, 'a_main$0');

function a_main$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_1);
  (s.pc = "2.65");
  var t_call_2 = (ok1(s, s.$board) && s.$board.create_ellipse(20, 20, s));
  s.rt.markAllocated(t_call_2);
  (s.$sprite = t_call_2);
  (s.pc = "2.6b");
  return s.rt.enter(a_qDcj96avRPrOW0HP9ddHIGDX(s, a_main$2));
}
cs.registerStep(a_main$1, 'a_main$1');

function a_main$2(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  (s.$p = t_actRes_3);
  (s.pc = "2.6f");
  var t_call_4 = (ok1(s, s.$p) && s.$p.x(s));
  var t_infix_5 = (ok1(s, t_call_4) && (t_call_4 * 50));
  var t_call_6 = (ok1(s, s.$p) && s.$p.y(s));
  var t_infix_7 = (ok1(s, t_call_6) && (t_call_6 * 50));
  s.rt.logObjectMutation(s.$sprite);
  (ok3(s, s.$sprite, t_infix_5, t_infix_7) && s.$sprite.set_speed(t_infix_5, t_infix_7, s));
  (s.pc = "2.6l");
  return s.rt.enter(a_Jr5PkqN8lT3CcCaI8FkcwY9i(s, a_main$3, s.$sprite, 50, 0));
}
cs.registerStep(a_main$2, 'a_main$2');

function a_main$3(s) {
  (s.pc = "2.6s");
  var t_call_8 = (ok1(s, s.$p) && s.$p.z(s));
  var t_infix_9 = (ok1(s, t_call_8) && (t_call_8 * 10));
  s.rt.logObjectMutation(s.$sprite);
  (ok2(s, s.$sprite, t_infix_9) && s.$sprite.set_acceleration_y(t_infix_9, s));
  (s.pc = "2.6x");
  return s.rt.enter(a_hUUrbnz6QsXzbuBs4lLmaY67(s, a_main$4, true));
}
cs.registerStep(a_main$3, 'a_main$3');

function a_main$4(s) {
  (s.pc = "2.6D");
  return s.rt.enter(a_xLL5SIqze7BJH9jArgnxFL1w(s, a_main$5, "a", "w", "d", "s", "space"));
}
cs.registerStep(a_main$4, 'a_main$4');

function a_main$5(s) {
  (s.pc = "2.6I");
  return s.rt.enter(a_xOCxKZH5B5Fbbm2N2BgFeCjp(s, a_main$6, 0, 10));
}
cs.registerStep(a_main$5, 'a_main$5');

function a_main$6(s) {
  return s.rt.leave();
}
cs.registerStep(a_main$6, 'a_main$6');

/* ACTION: current */
function a_qDcj96avRPrOW0HP9ddHIGDX(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_qDcj96avRPrOW0HP9ddHIGDX$0;
  s.name = "current";
  s.result = undefined;
  s.$now = undefined;
  s.$dt = undefined;
  s.$vector = undefined;
  return s;
}
cs.registerAction("current", "qDcj96avRPrOW0HP9ddHIGDX", a_qDcj96avRPrOW0HP9ddHIGDX, false);

function a_qDcj96avRPrOW0HP9ddHIGDX$0(s) {
  (s.pc = "2.d1");
  var t_call_0 = lib.Time.now(s);
  (s.$now = t_call_0);
  (s.pc = "2.d4");
  return s.rt.enter(a_AKyPSHgYSnMUTq5QWdoGYf4b(s, a_qDcj96avRPrOW0HP9ddHIGDX$1, s.$now));
}
cs.registerStep(a_qDcj96avRPrOW0HP9ddHIGDX$0, 'a_qDcj96avRPrOW0HP9ddHIGDX$0');

function a_qDcj96avRPrOW0HP9ddHIGDX$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (s.$dt = t_actRes_1);
  (s.pc = "2.d7");
  var t_call_2 = (ok1(s, /* vector */ s.d.$BdGhpbmca) && /* vector */ s.d.$BdGhpbmca.create(s));
  s.rt.markAllocated(t_call_2);
  (s.$vector = t_call_2);
  (s.pc = "2.da");
  return s.rt.enter(a_l4qZbEXuo0rCJ9p2l2546YMX(s, a_qDcj96avRPrOW0HP9ddHIGDX$2, s.$dt, s.$vector));
}
cs.registerStep(a_qDcj96avRPrOW0HP9ddHIGDX$1, 'a_qDcj96avRPrOW0HP9ddHIGDX$1');

function a_qDcj96avRPrOW0HP9ddHIGDX$2(s) {
  s.t_elseIf_3 = true;
  (s.pc = "2.dd");
  ok1(s, /* _accelerometer */ s.d.$zKu4ADE6HhE7UI5GvT3xWZ2G);
  if (/* _accelerometer */ s.d.$zKu4ADE6HhE7UI5GvT3xWZ2G) {
  (s.t_elseIf_3 = false);
  (s.pc = "2.dh0");
  return s.rt.enter(a_NARYT4r1qcmrRmDNdAjtkOcD(s, a_qDcj96avRPrOW0HP9ddHIGDX$4, s.$dt, s.$vector));
  }
  return a_qDcj96avRPrOW0HP9ddHIGDX$3;
}
cs.registerStep(a_qDcj96avRPrOW0HP9ddHIGDX$2, 'a_qDcj96avRPrOW0HP9ddHIGDX$2');

function a_qDcj96avRPrOW0HP9ddHIGDX$4(s) {
  return a_qDcj96avRPrOW0HP9ddHIGDX$3;
}
cs.registerStep(a_qDcj96avRPrOW0HP9ddHIGDX$4, 'a_qDcj96avRPrOW0HP9ddHIGDX$4');

function a_qDcj96avRPrOW0HP9ddHIGDX$3(s) {
  if (s.t_elseIf_3) {
  (s.pc = "2.di");
  var t_libcall_4 = s.libs["vIOEa4LjBL2h78vLd1Ls3U5z"]["board"](s);
  return s.rt.enter(t_libcall_4.invoke(t_libcall_4, a_qDcj96avRPrOW0HP9ddHIGDX$5));
  }
  return a_qDcj96avRPrOW0HP9ddHIGDX$8;
}
cs.registerStep(a_qDcj96avRPrOW0HP9ddHIGDX$3, 'a_qDcj96avRPrOW0HP9ddHIGDX$3');

function a_qDcj96avRPrOW0HP9ddHIGDX$5(s) {
  var t_actRes_5 = s.rt.returnedFrom.result;
  var t_call_6 = (ok1(s, t_actRes_5) && t_actRes_5.touched(s));
  ok1(s, t_call_6);
  if (t_call_6) {
  (s.pc = "2.dm0");
  return s.rt.enter(a_uYKZvu9VJlQJWlN4YZ8bPdOY(s, a_qDcj96avRPrOW0HP9ddHIGDX$7, s.$dt, s.$vector));
  } else {
  (s.pc = "2.dn0");
  null;
  }
  return a_qDcj96avRPrOW0HP9ddHIGDX$6;
}
cs.registerStep(a_qDcj96avRPrOW0HP9ddHIGDX$5, 'a_qDcj96avRPrOW0HP9ddHIGDX$5');

function a_qDcj96avRPrOW0HP9ddHIGDX$8(s) {
  (s.pc = "2.dn");
  if (s.$vector) {
  var t_recOp_7 = s.$vector[("PIhmB5a45eV2GwDOel4fNJzD")];
  }
  if (s.$vector) {
  var t_recOp_8 = s.$vector[("s4RJLddQmZAAL2fVNJZlofpI")];
  }
  if (s.$vector) {
  var t_recOp_9 = s.$vector[("z4sZT4jEURZzF4qvBK80374u")];
  }
  var t_call_10 = (ok3(s, t_recOp_7, t_recOp_8, t_recOp_9) && lib.Math_.create_vector3(t_recOp_7, t_recOp_8, t_recOp_9, s));
  (/* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1 = t_call_10);
  s.rt.logDataWrite();
  (s.pc = "2.dq");
  (/* _current time */ s.d.$k7HatejkjqfIA242SSMpitAK = s.$now);
  s.rt.logDataWrite();
  (s.pc = "2.dt");
  (s.result = /* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1);
  if (s.previous.needsPicker) {
  s.rt.displayResult("p", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_qDcj96avRPrOW0HP9ddHIGDX$8, 'a_qDcj96avRPrOW0HP9ddHIGDX$8');

function a_qDcj96avRPrOW0HP9ddHIGDX$7(s) {
  return a_qDcj96avRPrOW0HP9ddHIGDX$6;
}
cs.registerStep(a_qDcj96avRPrOW0HP9ddHIGDX$7, 'a_qDcj96avRPrOW0HP9ddHIGDX$7');

function a_qDcj96avRPrOW0HP9ddHIGDX$6(s) {
  return a_qDcj96avRPrOW0HP9ddHIGDX$8;
}
cs.registerStep(a_qDcj96avRPrOW0HP9ddHIGDX$6, 'a_qDcj96avRPrOW0HP9ddHIGDX$6');

/* ACTION: compute touch */
function a_uYKZvu9VJlQJWlN4YZ8bPdOY(previous, returnAddr, $dt, $vector) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_uYKZvu9VJlQJWlN4YZ8bPdOY$0;
  s.name = "compute touch";
  s.$dt = $dt;
  s.$vector = $vector;
  s.$board = undefined;
  s.$dist = undefined;
  s.$r = undefined;
  s.$m = undefined;
  s.$p = undefined;
  return s;
}
cs.registerAction("compute touch", "uYKZvu9VJlQJWlN4YZ8bPdOY", a_uYKZvu9VJlQJWlN4YZ8bPdOY, false);

function a_uYKZvu9VJlQJWlN4YZ8bPdOY$0(s) {
  (s.pc = "2.k0");
  var t_call_0 = (ok1(s, /* _accelerometer */ s.d.$zKu4ADE6HhE7UI5GvT3xWZ2G) && lib.Boolean_.not(/* _accelerometer */ s.d.$zKu4ADE6HhE7UI5GvT3xWZ2G, s));
  (ok1(s, t_call_0) && lib.Contract.assert(t_call_0, "", s));
  (s.pc = "2.k3");
  var t_libcall_1 = s.libs["vIOEa4LjBL2h78vLd1Ls3U5z"]["board"](s);
  return s.rt.enter(t_libcall_1.invoke(t_libcall_1, a_uYKZvu9VJlQJWlN4YZ8bPdOY$1));
}
cs.registerStep(a_uYKZvu9VJlQJWlN4YZ8bPdOY$0, 'a_uYKZvu9VJlQJWlN4YZ8bPdOY$0');

function a_uYKZvu9VJlQJWlN4YZ8bPdOY$1(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_2);
  (s.pc = "2.k6");
  var t_call_3 = (ok1(s, s.$board) && s.$board.touch_current(s));
  var t_call_4 = (ok1(s, s.$board) && s.$board.touch_start(s));
  var t_call_5 = (ok2(s, t_call_3, t_call_4) && t_call_3.subtract(t_call_4, s));
  (s.$dist = t_call_5);
  (s.pc = "2.k9");
  var t_call_6 = (ok1(s, s.$board) && s.$board.width(s));
  var t_call_7 = (ok1(s, s.$board) && s.$board.height(s));
  var t_call_8 = (ok2(s, t_call_6, t_call_7) && lib.Math_.min(t_call_6, t_call_7, s));
  var t_infix_9 = (ok1(s, t_call_8) && (t_call_8 * 0.3));
  (s.$r = t_infix_9);
  (s.pc = "2.kc");
  var t_call_10 = (ok1(s, s.$dist) && s.$dist.x(s));
  var t_call_11 = (ok1(s, t_call_10) && lib.Math_.abs(t_call_10, s));
  var t_call_12 = (ok1(s, s.$dist) && s.$dist.y(s));
  var t_call_13 = (ok1(s, t_call_12) && lib.Math_.abs(t_call_12, s));
  var t_call_14 = (ok2(s, t_call_11, t_call_13) && lib.Math_.max(t_call_11, t_call_13, s));
  var t_call_15 = (ok2(s, s.$r, t_call_14) && lib.Math_.max(s.$r, t_call_14, s));
  (s.$m = t_call_15);
  (s.pc = "2.kf");
  var t_infix_16 = (ok1(s, s.$m) && (1 / s.$m));
  var t_call_17 = (ok2(s, s.$dist, t_infix_16) && s.$dist.scale(t_infix_16, s));
  (s.$p = t_call_17);
  (s.pc = "2.ki");
  var t_infix_18 = (0 - 1);
  var t_call_19 = (ok1(s, s.$p) && s.$p.x(s));
  var t_call_20 = (ok2(s, t_infix_18, t_call_19) && lib.Math_.clamp(t_infix_18, 1, t_call_19, s));
  if (s.$vector) {
  s.$vector.perform_set("PIhmB5a45eV2GwDOel4fNJzD", t_call_20, s);
  }
  (s.pc = "2.kl");
  var t_infix_21 = (0 - 1);
  var t_call_22 = (ok1(s, s.$p) && s.$p.y(s));
  var t_call_23 = (ok2(s, t_infix_21, t_call_22) && lib.Math_.clamp(t_infix_21, 1, t_call_22, s));
  if (s.$vector) {
  s.$vector.perform_set("s4RJLddQmZAAL2fVNJZlofpI", t_call_23, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_uYKZvu9VJlQJWlN4YZ8bPdOY$1, 'a_uYKZvu9VJlQJWlN4YZ8bPdOY$1');

/* ACTION: compute keyboard */
function a_l4qZbEXuo0rCJ9p2l2546YMX(previous, returnAddr, $seconds, $vector) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_l4qZbEXuo0rCJ9p2l2546YMX$0;
  s.name = "compute keyboard";
  s.$seconds = $seconds;
  s.$vector = $vector;
  s.$ramp = undefined;
  s.$deramp = undefined;
  s.$click = undefined;
  return s;
}
cs.registerAction("compute keyboard", "l4qZbEXuo0rCJ9p2l2546YMX", a_l4qZbEXuo0rCJ9p2l2546YMX, false);

function a_l4qZbEXuo0rCJ9p2l2546YMX$0(s) {
  (s.pc = "2.p0");
  (s.$ramp = 0.4);
  (s.pc = "2.p3");
  (s.$deramp = 0.9);
  var t_elseIf_0 = true;
  (s.pc = "2.p6");
  var t_call_1 = (ok1(s, /* left key */ s.d.$VnuZVlq4It4ey9uDsKs4YbdR) && lib.String_.is_empty(/* left key */ s.d.$VnuZVlq4It4ey9uDsKs4YbdR, s));
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.pc = "2.pa0");
  (/* left key */ s.d.$VnuZVlq4It4ey9uDsKs4YbdR = "left");
  s.rt.logDataWrite();
  (s.pc = "2.pa3");
  (/* right key */ s.d.$aTuZ6YFViE62QFkIlkkwKW12 = "right");
  s.rt.logDataWrite();
  (s.pc = "2.pa6");
  (/* up key */ s.d.$YkBWyq8FAIP9GNsp2XZd9aam = "up");
  s.rt.logDataWrite();
  (s.pc = "2.pa9");
  (/* down key */ s.d.$TOlXyopWIthfSNmQ7K8HEulk = "down");
  s.rt.logDataWrite();
  (s.pc = "2.pac");
  (/* button key */ s.d.$Lpz9hXJq4RUQjd5quEu4cq12 = "space");
  s.rt.logDataWrite();
  } else {
  (s.pc = "2.pb0");
  null;
  }
  var t_elseIf_2 = true;
  (s.pc = "2.pb");
  var t_call_3 = lib.Boolean_.not((/* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1 == undefined), s);
  var t_lazy_4 = t_call_3;
  if ((ok1(s, t_lazy_4) && t_lazy_4)) {
  var t_infix_5 = (ok1(s, s.$seconds) && (s.$seconds > 0));
  (t_lazy_4 = t_infix_5);
  }
  ok1(s, t_lazy_4);
  if (t_lazy_4) {
  (s.pc = "2.pf0");
  var t_call_6 = (ok1(s, /* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1) && /* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1.x(s));
  if (s.$vector) {
  s.$vector.perform_set("PIhmB5a45eV2GwDOel4fNJzD", t_call_6, s);
  }
  (s.pc = "2.pf3");
  var t_call_7 = (ok1(s, /* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1) && /* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1.y(s));
  if (s.$vector) {
  s.$vector.perform_set("s4RJLddQmZAAL2fVNJZlofpI", t_call_7, s);
  }
  (s.pc = "2.pf6");
  var t_call_8 = (ok1(s, /* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1) && /* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1.z(s));
  if (s.$vector) {
  s.$vector.perform_set("z4sZT4jEURZzF4qvBK80374u", t_call_8, s);
  }
  } else {
  (s.pc = "2.pg0");
  null;
  }
  var t_elseIf_9 = true;
  (s.pc = "2.pg");
  var t_call_10 = (ok1(s, /* left key */ s.d.$VnuZVlq4It4ey9uDsKs4YbdR) && lib.Senses.is_key_pressed(/* left key */ s.d.$VnuZVlq4It4ey9uDsKs4YbdR, s));
  ok1(s, t_call_10);
  if (t_call_10) {
  (t_elseIf_9 = false);
  (s.pc = "2.pk0");
  var t_infix_11 = (0 - 1);
  if (s.$vector) {
  var t_recOp_12 = s.$vector[("PIhmB5a45eV2GwDOel4fNJzD")];
  }
  var t_infix_13 = (ok2(s, s.$seconds, s.$ramp) && (s.$seconds / s.$ramp));
  var t_infix_14 = (ok2(s, t_recOp_12, t_infix_13) && (t_recOp_12 - t_infix_13));
  var t_call_15 = (ok2(s, t_infix_11, t_infix_14) && lib.Math_.clamp(t_infix_11, 0, t_infix_14, s));
  if (s.$vector) {
  s.$vector.perform_set("PIhmB5a45eV2GwDOel4fNJzD", t_call_15, s);
  }
  }
  if (t_elseIf_9) {
  (s.pc = "2.pl");
  var t_call_16 = (ok1(s, /* right key */ s.d.$aTuZ6YFViE62QFkIlkkwKW12) && lib.Senses.is_key_pressed(/* right key */ s.d.$aTuZ6YFViE62QFkIlkkwKW12, s));
  ok1(s, t_call_16);
  if (t_call_16) {
  (s.pc = "2.pp0");
  if (s.$vector) {
  var t_recOp_17 = s.$vector[("PIhmB5a45eV2GwDOel4fNJzD")];
  }
  var t_infix_18 = (ok2(s, s.$seconds, s.$ramp) && (s.$seconds / s.$ramp));
  var t_infix_19 = (ok2(s, t_recOp_17, t_infix_18) && (t_recOp_17 + t_infix_18));
  var t_call_20 = (ok1(s, t_infix_19) && lib.Math_.clamp(0, 1, t_infix_19, s));
  if (s.$vector) {
  s.$vector.perform_set("PIhmB5a45eV2GwDOel4fNJzD", t_call_20, s);
  }
  } else {
  (s.pc = "2.pq0");
  if (s.$vector) {
  var t_recOp_21 = s.$vector[("PIhmB5a45eV2GwDOel4fNJzD")];
  }
  var t_infix_22 = (ok2(s, t_recOp_21, s.$deramp) && (t_recOp_21 * s.$deramp));
  if (s.$vector) {
  s.$vector.perform_set("PIhmB5a45eV2GwDOel4fNJzD", t_infix_22, s);
  }
  var t_elseIf_23 = true;
  (s.pc = "2.pq3");
  if (s.$vector) {
  var t_recOp_24 = s.$vector[("PIhmB5a45eV2GwDOel4fNJzD")];
  }
  var t_call_25 = (ok1(s, t_recOp_24) && lib.Math_.abs(t_recOp_24, s));
  var t_infix_26 = (ok1(s, t_call_25) && (t_call_25 < 0.05));
  ok1(s, t_infix_26);
  if (t_infix_26) {
  (s.pc = "2.pq70");
  if (s.$vector) {
  s.$vector.perform_set("PIhmB5a45eV2GwDOel4fNJzD", 0, s);
  }
  } else {
  (s.pc = "2.pq80");
  null;
  }
  }
  }
  var t_elseIf_27 = true;
  (s.pc = "2.pq");
  var t_call_28 = (ok1(s, /* down key */ s.d.$TOlXyopWIthfSNmQ7K8HEulk) && lib.Senses.is_key_pressed(/* down key */ s.d.$TOlXyopWIthfSNmQ7K8HEulk, s));
  ok1(s, t_call_28);
  if (t_call_28) {
  (t_elseIf_27 = false);
  (s.pc = "2.pu0");
  if (s.$vector) {
  var t_recOp_29 = s.$vector[("s4RJLddQmZAAL2fVNJZlofpI")];
  }
  var t_infix_30 = (ok2(s, s.$seconds, s.$ramp) && (s.$seconds / s.$ramp));
  var t_infix_31 = (ok2(s, t_recOp_29, t_infix_30) && (t_recOp_29 + t_infix_30));
  var t_call_32 = (ok1(s, t_infix_31) && lib.Math_.clamp(0, 1, t_infix_31, s));
  if (s.$vector) {
  s.$vector.perform_set("s4RJLddQmZAAL2fVNJZlofpI", t_call_32, s);
  }
  }
  if (t_elseIf_27) {
  (s.pc = "2.pv");
  var t_call_33 = (ok1(s, /* up key */ s.d.$YkBWyq8FAIP9GNsp2XZd9aam) && lib.Senses.is_key_pressed(/* up key */ s.d.$YkBWyq8FAIP9GNsp2XZd9aam, s));
  ok1(s, t_call_33);
  if (t_call_33) {
  (s.pc = "2.pz0");
  var t_infix_34 = (0 - 1);
  if (s.$vector) {
  var t_recOp_35 = s.$vector[("s4RJLddQmZAAL2fVNJZlofpI")];
  }
  var t_infix_36 = (ok2(s, s.$seconds, s.$ramp) && (s.$seconds / s.$ramp));
  var t_infix_37 = (ok2(s, t_recOp_35, t_infix_36) && (t_recOp_35 - t_infix_36));
  var t_call_38 = (ok2(s, t_infix_34, t_infix_37) && lib.Math_.clamp(t_infix_34, 0, t_infix_37, s));
  if (s.$vector) {
  s.$vector.perform_set("s4RJLddQmZAAL2fVNJZlofpI", t_call_38, s);
  }
  } else {
  (s.pc = "2.pA0");
  if (s.$vector) {
  var t_recOp_39 = s.$vector[("s4RJLddQmZAAL2fVNJZlofpI")];
  }
  var t_infix_40 = (ok2(s, t_recOp_39, s.$deramp) && (t_recOp_39 * s.$deramp));
  if (s.$vector) {
  s.$vector.perform_set("s4RJLddQmZAAL2fVNJZlofpI", t_infix_40, s);
  }
  var t_elseIf_41 = true;
  (s.pc = "2.pA3");
  if (s.$vector) {
  var t_recOp_42 = s.$vector[("s4RJLddQmZAAL2fVNJZlofpI")];
  }
  var t_call_43 = (ok1(s, t_recOp_42) && lib.Math_.abs(t_recOp_42, s));
  var t_infix_44 = (ok1(s, t_call_43) && (t_call_43 < 0.05));
  ok1(s, t_infix_44);
  if (t_infix_44) {
  (s.pc = "2.pA70");
  if (s.$vector) {
  s.$vector.perform_set("s4RJLddQmZAAL2fVNJZlofpI", 0, s);
  }
  } else {
  (s.pc = "2.pA80");
  null;
  }
  }
  }
  (s.pc = "2.pA");
  s.t_lazy_45 = /* _accelerometer */ s.d.$zKu4ADE6HhE7UI5GvT3xWZ2G;
  if ((ok1(s, s.t_lazy_45) && s.t_lazy_45)) {
  var t_libcall_46 = s.libs["vIOEa4LjBL2h78vLd1Ls3U5z"]["board"](s);
  return s.rt.enter(t_libcall_46.invoke(t_libcall_46, a_l4qZbEXuo0rCJ9p2l2546YMX$32));
  }
  return a_l4qZbEXuo0rCJ9p2l2546YMX$31;
}
cs.registerStep(a_l4qZbEXuo0rCJ9p2l2546YMX$0, 'a_l4qZbEXuo0rCJ9p2l2546YMX$0');

function a_l4qZbEXuo0rCJ9p2l2546YMX$32(s) {
  var t_actRes_47 = s.rt.returnedFrom.result;
  var t_call_48 = (ok1(s, t_actRes_47) && t_actRes_47.touched(s));
  (s.t_lazy_45 = t_call_48);
  return a_l4qZbEXuo0rCJ9p2l2546YMX$31;
}
cs.registerStep(a_l4qZbEXuo0rCJ9p2l2546YMX$32, 'a_l4qZbEXuo0rCJ9p2l2546YMX$32');

function a_l4qZbEXuo0rCJ9p2l2546YMX$31(s) {
  (s.$click = s.t_lazy_45);
  var t_elseIf_49 = true;
  (s.pc = "2.pD");
  var t_call_50 = (ok1(s, /* button key */ s.d.$Lpz9hXJq4RUQjd5quEu4cq12) && lib.Senses.is_key_pressed(/* button key */ s.d.$Lpz9hXJq4RUQjd5quEu4cq12, s));
  var t_lazy_51 = t_call_50;
  if ((ok1(s, t_lazy_51) && (!t_lazy_51))) {
  (t_lazy_51 = s.$click);
  }
  ok1(s, t_lazy_51);
  if (t_lazy_51) {
  (s.pc = "2.pH0");
  if (s.$vector) {
  var t_recOp_52 = s.$vector[("z4sZT4jEURZzF4qvBK80374u")];
  }
  var t_infix_53 = (ok2(s, s.$seconds, s.$ramp) && (s.$seconds / s.$ramp));
  var t_infix_54 = (ok2(s, t_recOp_52, t_infix_53) && (t_recOp_52 + t_infix_53));
  var t_call_55 = (ok1(s, t_infix_54) && lib.Math_.clamp(0, 1, t_infix_54, s));
  if (s.$vector) {
  s.$vector.perform_set("z4sZT4jEURZzF4qvBK80374u", t_call_55, s);
  }
  } else {
  (s.pc = "2.pI0");
  if (s.$vector) {
  var t_recOp_56 = s.$vector[("z4sZT4jEURZzF4qvBK80374u")];
  }
  var t_infix_57 = (ok2(s, t_recOp_56, s.$deramp) && (t_recOp_56 * s.$deramp));
  if (s.$vector) {
  s.$vector.perform_set("z4sZT4jEURZzF4qvBK80374u", t_infix_57, s);
  }
  var t_elseIf_58 = true;
  (s.pc = "2.pI3");
  if (s.$vector) {
  var t_recOp_59 = s.$vector[("z4sZT4jEURZzF4qvBK80374u")];
  }
  var t_infix_60 = (ok1(s, t_recOp_59) && (t_recOp_59 < 0.05));
  ok1(s, t_infix_60);
  if (t_infix_60) {
  (s.pc = "2.pI70");
  if (s.$vector) {
  s.$vector.perform_set("z4sZT4jEURZzF4qvBK80374u", 0, s);
  }
  } else {
  (s.pc = "2.pI80");
  null;
  }
  }
  return s.rt.leave();
}
cs.registerStep(a_l4qZbEXuo0rCJ9p2l2546YMX$31, 'a_l4qZbEXuo0rCJ9p2l2546YMX$31');

/* ACTION: check last current */
function a_AKyPSHgYSnMUTq5QWdoGYf4b(previous, returnAddr, $now) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_AKyPSHgYSnMUTq5QWdoGYf4b$0;
  s.name = "check last current";
  s.$now = $now;
  s.result = undefined;
  return s;
}
cs.registerAction("check last current", "AKyPSHgYSnMUTq5QWdoGYf4b", a_AKyPSHgYSnMUTq5QWdoGYf4b, false);

function a_AKyPSHgYSnMUTq5QWdoGYf4b$0(s) {
  (s.pc = "2.u0");
  (s.result = 0);
  var t_elseIf_0 = true;
  (s.pc = "2.u3");
  var t_call_1 = lib.Boolean_.not((/* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1 == undefined), s);
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.pc = "2.u70");
  var t_call_2 = (ok2(s, s.$now, /* _current time */ s.d.$k7HatejkjqfIA242SSMpitAK) && s.$now.subtract(/* _current time */ s.d.$k7HatejkjqfIA242SSMpitAK, s));
  (s.result = t_call_2);
  var t_elseIf_3 = true;
  (s.pc = "2.u73");
  var t_infix_4 = (ok1(s, s.result) && (s.result > 1));
  ok1(s, t_infix_4);
  if (t_infix_4) {
  (s.pc = "2.u770");
  var t_call_5 = lib.Invalid.vector3(s);
  (/* _current */ s.d.$LJp5GBFLELwUrK3r6yVHOfL1 = t_call_5);
  s.rt.logDataWrite();
  (s.pc = "2.u773");
  (s.result = 0);
  } else {
  (s.pc = "2.u780");
  null;
  }
  } else {
  (s.pc = "2.u80");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_AKyPSHgYSnMUTq5QWdoGYf4b$0, 'a_AKyPSHgYSnMUTq5QWdoGYf4b$0');

/* ACTION: test */
function a_UJBkmukg7xj2SmmTAcdYmdmZ(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_UJBkmukg7xj2SmmTAcdYmdmZ$0;
  s.name = "test";
  s.$board = undefined;
  s.$sprite = undefined;
  s.$perform = undefined;
  s.$p = undefined;
  return s;
}
cs.registerAction("test", "UJBkmukg7xj2SmmTAcdYmdmZ", a_UJBkmukg7xj2SmmTAcdYmdmZ, true);

function a_UJBkmukg7xj2SmmTAcdYmdmZ$0(s) {
  (s.pc = "2.z0");
  var t_libcall_0 = s.libs["vIOEa4LjBL2h78vLd1Ls3U5z"]["start"](s);
  return s.rt.enter(t_libcall_0.invoke(t_libcall_0, a_UJBkmukg7xj2SmmTAcdYmdmZ$1));
}
cs.registerStep(a_UJBkmukg7xj2SmmTAcdYmdmZ$0, 'a_UJBkmukg7xj2SmmTAcdYmdmZ$0');

function a_UJBkmukg7xj2SmmTAcdYmdmZ$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_1);
  (s.pc = "2.z3");
  (ok1(s, s.$board) && s.$board.set_debug_mode(true, s));
  (s.pc = "2.z6");
  var t_call_2 = (ok1(s, s.$board) && s.$board.create_ellipse(100, 100, s));
  s.rt.markAllocated(t_call_2);
  (s.$sprite = t_call_2);
  (s.pc = "2.zd0");
  var t_lmbv_3 = s.$sprite;
  var t_lmbProxy_4 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2(t_lmbProxy_4(la0), la1, t_lmbv_3) });
  (s.pc = "2.z9");
  var t_call_5 = (ok2(s, s.$board, s.$perform) && s.$board.add_on_every_frame(s.$perform, s));
  t_call_5;
  return s.rt.leave();
}
cs.registerStep(a_UJBkmukg7xj2SmmTAcdYmdmZ$1, 'a_UJBkmukg7xj2SmmTAcdYmdmZ$1');

/* ACTION: a_UJBkmukg7xj2SmmTAcdYmdmZ::lambda::2 */
function a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2(previous, returnAddr, $sprite) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2$0;
  s.name = "test";
  s.$sprite = $sprite;
  s.$p = undefined;
  return s;
}
cs.registerLambda("a_UJBkmukg7xj2SmmTAcdYmdmZ\u003a\u003alambda\u003a\u003a2", "a_UJBkmukg7xj2SmmTAcdYmdmZ$2", a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2, true);

function a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2$0(s) {
  (s.pc = "2.zd20");
  return s.rt.enter(a_qDcj96avRPrOW0HP9ddHIGDX(s, a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2$1));
}
cs.registerStep(a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2$0, 'a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2$0');

function a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  (s.$p = t_actRes_0);
  (s.pc = "2.zd23");
  var t_call_1 = (ok1(s, s.$p) && s.$p.x(s));
  var t_infix_2 = (ok1(s, t_call_1) && (t_call_1 * 50));
  var t_call_3 = (ok1(s, s.$p) && s.$p.y(s));
  var t_infix_4 = (ok1(s, t_call_3) && (t_call_3 * 50));
  s.rt.logObjectMutation(s.$sprite);
  (ok3(s, s.$sprite, t_infix_2, t_infix_4) && s.$sprite.set_speed(t_infix_2, t_infix_4, s));
  (s.pc = "2.zd26");
  var t_call_5 = (ok1(s, s.$p) && s.$p.z(s));
  var t_infix_6 = (ok1(s, t_call_5) && (t_call_5 * 10));
  s.rt.logObjectMutation(s.$sprite);
  (ok2(s, s.$sprite, t_infix_6) && s.$sprite.set_acceleration_y(t_infix_6, s));
  return s.rt.leave();
}
cs.registerStep(a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2$1, 'a_a_UJBkmukg7xj2SmmTAcdYmdmZ$2$1');

/* ACTION: set keys */
function a_xLL5SIqze7BJH9jArgnxFL1w(previous, returnAddr, $left, $up, $right, $down, $button) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xLL5SIqze7BJH9jArgnxFL1w$0;
  s.name = "set keys";
  s.$left = $left;
  s.$up = $up;
  s.$right = $right;
  s.$down = $down;
  s.$button = $button;
  return s;
}
cs.registerAction("set keys", "xLL5SIqze7BJH9jArgnxFL1w", a_xLL5SIqze7BJH9jArgnxFL1w, false);

function a_xLL5SIqze7BJH9jArgnxFL1w$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_xLL5SIqze7BJH9jArgnxFL1w$2, lib.RTValue.mkPicker(lib.String_.picker(), "", "left", "$left"), lib.RTValue.mkPicker(lib.String_.picker(), "", "up", "$up"), lib.RTValue.mkPicker(lib.String_.picker(), "", "right", "$right"), lib.RTValue.mkPicker(lib.String_.picker(), "", "down", "$down"), lib.RTValue.mkPicker(lib.String_.picker(), "", "button", "$button"));
  return a_xLL5SIqze7BJH9jArgnxFL1w$2;
  }
  return a_xLL5SIqze7BJH9jArgnxFL1w$1;
}
cs.registerStep(a_xLL5SIqze7BJH9jArgnxFL1w$0, 'a_xLL5SIqze7BJH9jArgnxFL1w$0');

function a_xLL5SIqze7BJH9jArgnxFL1w$2(s) {
  return a_xLL5SIqze7BJH9jArgnxFL1w$1;
}
cs.registerStep(a_xLL5SIqze7BJH9jArgnxFL1w$2, 'a_xLL5SIqze7BJH9jArgnxFL1w$2');

function a_xLL5SIqze7BJH9jArgnxFL1w$1(s) {
  (s.pc = "2.J6");
  (/* left key */ s.d.$VnuZVlq4It4ey9uDsKs4YbdR = s.$left);
  s.rt.logDataWrite();
  (s.pc = "2.J9");
  (/* right key */ s.d.$aTuZ6YFViE62QFkIlkkwKW12 = s.$right);
  s.rt.logDataWrite();
  (s.pc = "2.Jc");
  (/* up key */ s.d.$YkBWyq8FAIP9GNsp2XZd9aam = s.$up);
  s.rt.logDataWrite();
  (s.pc = "2.Jf");
  (/* down key */ s.d.$TOlXyopWIthfSNmQ7K8HEulk = s.$down);
  s.rt.logDataWrite();
  (s.pc = "2.Ji");
  (/* button key */ s.d.$Lpz9hXJq4RUQjd5quEu4cq12 = s.$button);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_xLL5SIqze7BJH9jArgnxFL1w$1, 'a_xLL5SIqze7BJH9jArgnxFL1w$1');

/* ACTION: set accelerometer */
function a_hUUrbnz6QsXzbuBs4lLmaY67(previous, returnAddr, $enabled) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_hUUrbnz6QsXzbuBs4lLmaY67$0;
  s.name = "set accelerometer";
  s.$enabled = $enabled;
  return s;
}
cs.registerAction("set accelerometer", "hUUrbnz6QsXzbuBs4lLmaY67", a_hUUrbnz6QsXzbuBs4lLmaY67, false);

function a_hUUrbnz6QsXzbuBs4lLmaY67$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_hUUrbnz6QsXzbuBs4lLmaY67$3, lib.RTValue.mkPicker(lib.Boolean_.picker(), false, "enabled", "$enabled"));
  return a_hUUrbnz6QsXzbuBs4lLmaY67$3;
  }
  return a_hUUrbnz6QsXzbuBs4lLmaY67$2;
}
cs.registerStep(a_hUUrbnz6QsXzbuBs4lLmaY67$0, 'a_hUUrbnz6QsXzbuBs4lLmaY67$0');

function a_hUUrbnz6QsXzbuBs4lLmaY67$3(s) {
  return a_hUUrbnz6QsXzbuBs4lLmaY67$2;
}
cs.registerStep(a_hUUrbnz6QsXzbuBs4lLmaY67$3, 'a_hUUrbnz6QsXzbuBs4lLmaY67$3');

function a_hUUrbnz6QsXzbuBs4lLmaY67$2(s) {
  (s.pc = "2.P1");
  var t_lazy_0 = s.$enabled;
  if ((ok1(s, t_lazy_0) && t_lazy_0)) {
  var t_call_1 = lib.Senses.has_accelerometer(s);
  (t_lazy_0 = t_call_1);
  }
  (/* _accelerometer */ s.d.$zKu4ADE6HhE7UI5GvT3xWZ2G = t_lazy_0);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_hUUrbnz6QsXzbuBs4lLmaY67$2, 'a_hUUrbnz6QsXzbuBs4lLmaY67$2');

/* ACTION: compute accelerometer */
function a_NARYT4r1qcmrRmDNdAjtkOcD(previous, returnAddr, $dt, $vector) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_NARYT4r1qcmrRmDNdAjtkOcD$0;
  s.name = "compute accelerometer";
  s.$dt = $dt;
  s.$vector = $vector;
  s.$p = undefined;
  return s;
}
cs.registerAction("compute accelerometer", "NARYT4r1qcmrRmDNdAjtkOcD", a_NARYT4r1qcmrRmDNdAjtkOcD, false);

function a_NARYT4r1qcmrRmDNdAjtkOcD$0(s) {
  (s.pc = "2.U0");
  var t_resumeCtx_0 = s.rt.getBlockingResumeCtx(a_NARYT4r1qcmrRmDNdAjtkOcD$1);
  var t_call_1 = lib.Senses.acceleration_quick(t_resumeCtx_0);
  return a_NARYT4r1qcmrRmDNdAjtkOcD$1;
}
cs.registerStep(a_NARYT4r1qcmrRmDNdAjtkOcD$0, 'a_NARYT4r1qcmrRmDNdAjtkOcD$0');

function a_NARYT4r1qcmrRmDNdAjtkOcD$1(s) {
  var t_pauseRes_2 = s.pauseValue;
  (s.$p = t_pauseRes_2);
  (s.pc = "2.U3");
  var t_infix_3 = (0 - 1);
  var t_call_4 = (ok1(s, s.$p) && s.$p.x(s));
  var t_infix_5 = (ok1(s, t_call_4) && (t_call_4 * 2));
  var t_call_6 = (ok2(s, t_infix_3, t_infix_5) && lib.Math_.clamp(t_infix_3, 1, t_infix_5, s));
  if (s.$vector) {
  s.$vector.perform_set("PIhmB5a45eV2GwDOel4fNJzD", t_call_6, s);
  }
  (s.pc = "2.U6");
  var t_infix_7 = (0 - 1);
  var t_call_8 = (ok1(s, s.$p) && s.$p.y(s));
  var t_infix_9 = (ok1(s, t_call_8) && (t_call_8 * 2));
  var t_call_10 = (ok2(s, t_infix_7, t_infix_9) && lib.Math_.clamp(t_infix_7, 1, t_infix_9, s));
  if (s.$vector) {
  s.$vector.perform_set("s4RJLddQmZAAL2fVNJZlofpI", t_call_10, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_NARYT4r1qcmrRmDNdAjtkOcD$1, 'a_NARYT4r1qcmrRmDNdAjtkOcD$1');


//Ent_BdGhpbmca
function Ent_BdGhpbmca(p) {
  this.parent = p;
}
Ent_BdGhpbmca.prototype = new lib.ObjectEntry();
Ent_BdGhpbmca.prototype.keys = [];
Ent_BdGhpbmca.prototype.values = ["PIhmB5a45eV2GwDOel4fNJzD", "s4RJLddQmZAAL2fVNJZlofpI", "z4sZT4jEURZzF4qvBK80374u"];
Ent_BdGhpbmca.prototype.fields = ["PIhmB5a45eV2GwDOel4fNJzD", "s4RJLddQmZAAL2fVNJZlofpI", "z4sZT4jEURZzF4qvBK80374u"];
Ent_BdGhpbmca.prototype.PIhmB5a45eV2GwDOel4fNJzD_realname = "x";
Ent_BdGhpbmca.prototype.s4RJLddQmZAAL2fVNJZlofpI_realname = "y";
Ent_BdGhpbmca.prototype.z4sZT4jEURZzF4qvBK80374u_realname = "z";
Ent_BdGhpbmca.prototype.PIhmB5a45eV2GwDOel4fNJzD = 0;
Ent_BdGhpbmca.prototype.s4RJLddQmZAAL2fVNJZlofpI = 0;
Ent_BdGhpbmca.prototype.z4sZT4jEURZzF4qvBK80374u = 0;
//Col_BdGhpbmca
function Col_BdGhpbmca(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_BdGhpbmca.prototype = lib.RecordCollection.prototype;
//Tbl_BdGhpbmca
function Tbl_BdGhpbmca(l) {
  this.libName = l;
  this.initParent();
}
Tbl_BdGhpbmca.prototype = new lib.ObjectSingleton();
Tbl_BdGhpbmca.prototype.entryCtor = Ent_BdGhpbmca;
Tbl_BdGhpbmca.prototype.selfCtor = Tbl_BdGhpbmca;
Tbl_BdGhpbmca.prototype.collectionCtor = Col_BdGhpbmca;
Tbl_BdGhpbmca.prototype.stableName = "BdGhpbmca";
Tbl_BdGhpbmca.prototype.entryKindName = "vector";

// jsonimport
Ent_BdGhpbmca.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("PIhmB5a45eV2GwDOel4fNJzD", ctx.importNumber(json, "x"), s);
  this.perform_set("s4RJLddQmZAAL2fVNJZlofpI", ctx.importNumber(json, "y"), s);
  this.perform_set("z4sZT4jEURZzF4qvBK80374u", ctx.importNumber(json, "z"), s);
}
cs.registerGlobal("$BdGhpbmca");
/* ACTION: accelerometer */
function a_Pp43nHG2nxgTrXqtYtq2qQ3n(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Pp43nHG2nxgTrXqtYtq2qQ3n$0;
  s.name = "accelerometer";
  s.result = undefined;
  return s;
}
cs.registerAction("accelerometer", "Pp43nHG2nxgTrXqtYtq2qQ3n", a_Pp43nHG2nxgTrXqtYtq2qQ3n, false);

function a_Pp43nHG2nxgTrXqtYtq2qQ3n$0(s) {
  (s.pc = "2.62.1");
  (s.result = /* _accelerometer */ s.d.$zKu4ADE6HhE7UI5GvT3xWZ2G);
  if (s.previous.needsPicker) {
  s.rt.displayResult("b", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_Pp43nHG2nxgTrXqtYtq2qQ3n$0, 'a_Pp43nHG2nxgTrXqtYtq2qQ3n$0');

/* ACTION: control sprite */
function a_Jr5PkqN8lT3CcCaI8FkcwY9i(previous, returnAddr, $sprite, $max_speed_x, $max_speed_y) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Jr5PkqN8lT3CcCaI8FkcwY9i$0;
  s.name = "control sprite";
  s.$sprite = $sprite;
  s.$max_speed_x = $max_speed_x;
  s.$max_speed_y = $max_speed_y;
  s.$perform = undefined;
  s.$p = undefined;
  return s;
}
cs.registerAction("control sprite", "Jr5PkqN8lT3CcCaI8FkcwY9i", a_Jr5PkqN8lT3CcCaI8FkcwY9i, false);

function a_Jr5PkqN8lT3CcCaI8FkcwY9i$0(s) {
  (s.pc = "2.67.1");
  var t_infix_0 = (ok1(s, s.$max_speed_x) && (s.$max_speed_x !== 0));
  var t_lazy_1 = t_infix_0;
  if ((ok1(s, t_lazy_1) && (!t_lazy_1))) {
  var t_infix_2 = (ok1(s, s.$max_speed_y) && (s.$max_speed_y !== 0));
  (t_lazy_1 = t_infix_2);
  }
  (ok1(s, t_lazy_1) && lib.Contract.requires(t_lazy_1, "max speed x or max speed y must be positive", s));
  (s.pc = "2.67.80");
  var t_lmbv_3 = s.$max_speed_x;
  var t_lmbv_4 = s.$sprite;
  var t_lmbv_5 = s.$max_speed_y;
  var t_lmbProxy_6 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2(t_lmbProxy_6(la0), la1, t_lmbv_3, t_lmbv_4, t_lmbv_5) });
  (s.pc = "2.67.4");
  var t_libcall_7 = s.libs["vIOEa4LjBL2h78vLd1Ls3U5z"]["board"](s);
  return s.rt.enter(t_libcall_7.invoke(t_libcall_7, a_Jr5PkqN8lT3CcCaI8FkcwY9i$3));
}
cs.registerStep(a_Jr5PkqN8lT3CcCaI8FkcwY9i$0, 'a_Jr5PkqN8lT3CcCaI8FkcwY9i$0');

function a_Jr5PkqN8lT3CcCaI8FkcwY9i$3(s) {
  var t_actRes_8 = s.rt.returnedFrom.result;
  var t_call_9 = (ok2(s, t_actRes_8, s.$perform) && t_actRes_8.add_on_every_frame(s.$perform, s));
  t_call_9;
  return s.rt.leave();
}
cs.registerStep(a_Jr5PkqN8lT3CcCaI8FkcwY9i$3, 'a_Jr5PkqN8lT3CcCaI8FkcwY9i$3');

/* ACTION: a_Jr5PkqN8lT3CcCaI8FkcwY9i::lambda::2 */
function a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2(previous, returnAddr, $max_speed_x, $sprite, $max_speed_y) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2$0;
  s.name = "control sprite";
  s.$max_speed_x = $max_speed_x;
  s.$sprite = $sprite;
  s.$p = undefined;
  s.$max_speed_y = $max_speed_y;
  return s;
}
cs.registerLambda("a_Jr5PkqN8lT3CcCaI8FkcwY9i\u003a\u003alambda\u003a\u003a2", "a_Jr5PkqN8lT3CcCaI8FkcwY9i$2", a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2, true);

function a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2$0(s) {
  (s.pc = "2.67.820");
  return s.rt.enter(a_qDcj96avRPrOW0HP9ddHIGDX(s, a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2$1));
}
cs.registerStep(a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2$0, 'a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2$0');

function a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  (s.$p = t_actRes_0);
  var t_elseIf_1 = true;
  (s.pc = "2.67.823");
  var t_infix_2 = (ok1(s, s.$max_speed_x) && (s.$max_speed_x !== 0));
  ok1(s, t_infix_2);
  if (t_infix_2) {
  (s.pc = "2.67.8270");
  var t_call_3 = (ok1(s, s.$p) && s.$p.x(s));
  var t_infix_4 = (ok2(s, t_call_3, s.$max_speed_x) && (t_call_3 * s.$max_speed_x));
  s.rt.logObjectMutation(s.$sprite);
  (ok2(s, s.$sprite, t_infix_4) && s.$sprite.set_speed_x(t_infix_4, s));
  } else {
  (s.pc = "2.67.8280");
  null;
  }
  var t_elseIf_5 = true;
  (s.pc = "2.67.828");
  var t_infix_6 = (ok1(s, s.$max_speed_y) && (s.$max_speed_y !== 0));
  ok1(s, t_infix_6);
  if (t_infix_6) {
  (s.pc = "2.67.82c0");
  var t_call_7 = (ok1(s, s.$p) && s.$p.y(s));
  var t_infix_8 = (ok2(s, t_call_7, s.$max_speed_y) && (t_call_7 * s.$max_speed_y));
  s.rt.logObjectMutation(s.$sprite);
  (ok2(s, s.$sprite, t_infix_8) && s.$sprite.set_speed_y(t_infix_8, s));
  } else {
  (s.pc = "2.67.82d0");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2$1, 'a_a_Jr5PkqN8lT3CcCaI8FkcwY9i$2$1');

/* ACTION: control background scene */
function a_xOCxKZH5B5Fbbm2N2BgFeCjp(previous, returnAddr, $max_speed_x, $max_speed_y) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xOCxKZH5B5Fbbm2N2BgFeCjp$0;
  s.name = "control background scene";
  s.$max_speed_x = $max_speed_x;
  s.$max_speed_y = $max_speed_y;
  s.$board = undefined;
  s.$scene = undefined;
  s.$perform = undefined;
  s.$p = undefined;
  return s;
}
cs.registerAction("control background scene", "xOCxKZH5B5Fbbm2N2BgFeCjp", a_xOCxKZH5B5Fbbm2N2BgFeCjp, false);

function a_xOCxKZH5B5Fbbm2N2BgFeCjp$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_xOCxKZH5B5Fbbm2N2BgFeCjp$5, lib.RTValue.mkPicker(lib.Number_.picker(), 0, "max speed x", "$max_speed_x"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "max speed y", "$max_speed_y"));
  return a_xOCxKZH5B5Fbbm2N2BgFeCjp$5;
  }
  return a_xOCxKZH5B5Fbbm2N2BgFeCjp$4;
}
cs.registerStep(a_xOCxKZH5B5Fbbm2N2BgFeCjp$0, 'a_xOCxKZH5B5Fbbm2N2BgFeCjp$0');

function a_xOCxKZH5B5Fbbm2N2BgFeCjp$5(s) {
  return a_xOCxKZH5B5Fbbm2N2BgFeCjp$4;
}
cs.registerStep(a_xOCxKZH5B5Fbbm2N2BgFeCjp$5, 'a_xOCxKZH5B5Fbbm2N2BgFeCjp$5');

function a_xOCxKZH5B5Fbbm2N2BgFeCjp$4(s) {
  (s.pc = "2.72.1");
  var t_infix_0 = (ok1(s, s.$max_speed_x) && (s.$max_speed_x !== 0));
  var t_lazy_1 = t_infix_0;
  if ((ok1(s, t_lazy_1) && (!t_lazy_1))) {
  var t_infix_2 = (ok1(s, s.$max_speed_y) && (s.$max_speed_y !== 0));
  (t_lazy_1 = t_infix_2);
  }
  (ok1(s, t_lazy_1) && lib.Contract.requires(t_lazy_1, "max speed x or max speed y must be positive", s));
  (s.pc = "2.72.4");
  var t_libcall_3 = s.libs["vIOEa4LjBL2h78vLd1Ls3U5z"]["board"](s);
  return s.rt.enter(t_libcall_3.invoke(t_libcall_3, a_xOCxKZH5B5Fbbm2N2BgFeCjp$2));
}
cs.registerStep(a_xOCxKZH5B5Fbbm2N2BgFeCjp$4, 'a_xOCxKZH5B5Fbbm2N2BgFeCjp$4');

function a_xOCxKZH5B5Fbbm2N2BgFeCjp$2(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_4);
  (s.pc = "2.72.7");
  var t_call_5 = (ok1(s, s.$board) && s.$board.background_scene(s));
  (s.$scene = t_call_5);
  (s.pc = "2.72.e0");
  var t_lmbv_6 = s.$max_speed_x;
  var t_lmbv_7 = s.$scene;
  var t_lmbv_8 = s.$max_speed_y;
  var t_lmbProxy_9 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3(t_lmbProxy_9(la0), la1, t_lmbv_6, t_lmbv_7, t_lmbv_8) });
  (s.pc = "2.72.a");
  var t_call_10 = (ok2(s, s.$board, s.$perform) && s.$board.add_on_every_frame(s.$perform, s));
  t_call_10;
  return s.rt.leave();
}
cs.registerStep(a_xOCxKZH5B5Fbbm2N2BgFeCjp$2, 'a_xOCxKZH5B5Fbbm2N2BgFeCjp$2');

/* ACTION: a_xOCxKZH5B5Fbbm2N2BgFeCjp::lambda::3 */
function a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3(previous, returnAddr, $max_speed_x, $scene, $max_speed_y) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3$0;
  s.name = "control background scene";
  s.$max_speed_x = $max_speed_x;
  s.$p = undefined;
  s.$scene = $scene;
  s.$max_speed_y = $max_speed_y;
  return s;
}
cs.registerLambda("a_xOCxKZH5B5Fbbm2N2BgFeCjp\u003a\u003alambda\u003a\u003a3", "a_xOCxKZH5B5Fbbm2N2BgFeCjp$3", a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3, true);

function a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3$0(s) {
  (s.pc = "2.72.e20");
  return s.rt.enter(a_qDcj96avRPrOW0HP9ddHIGDX(s, a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3$1));
}
cs.registerStep(a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3$0, 'a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3$0');

function a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  (s.$p = t_actRes_0);
  var t_elseIf_1 = true;
  (s.pc = "2.72.e23");
  var t_call_2 = (ok1(s, s.$p) && s.$p.x(s));
  var t_infix_3 = (ok2(s, s.$max_speed_x, t_call_2) && (s.$max_speed_x * t_call_2));
  var t_infix_4 = (ok1(s, t_infix_3) && (t_infix_3 !== 0));
  ok1(s, t_infix_4);
  if (t_infix_4) {
  (s.pc = "2.72.e270");
  var t_call_5 = (ok1(s, s.$scene) && s.$scene.view_x(s));
  var t_call_6 = (ok1(s, s.$p) && s.$p.x(s));
  var t_infix_7 = (ok2(s, t_call_6, s.$max_speed_x) && (t_call_6 * s.$max_speed_x));
  var t_infix_8 = (ok2(s, t_call_5, t_infix_7) && (t_call_5 + t_infix_7));
  s.rt.logObjectMutation(s.$scene);
  (ok2(s, s.$scene, t_infix_8) && s.$scene.set_view_x(t_infix_8, s));
  } else {
  (s.pc = "2.72.e280");
  null;
  }
  var t_elseIf_9 = true;
  (s.pc = "2.72.e28");
  var t_call_10 = (ok1(s, s.$p) && s.$p.y(s));
  var t_infix_11 = (ok2(s, s.$max_speed_y, t_call_10) && (s.$max_speed_y * t_call_10));
  var t_infix_12 = (ok1(s, t_infix_11) && (t_infix_11 !== 0));
  ok1(s, t_infix_12);
  if (t_infix_12) {
  (s.pc = "2.72.e2c0");
  var t_call_13 = (ok1(s, s.$scene) && s.$scene.view_y(s));
  var t_call_14 = (ok1(s, s.$p) && s.$p.y(s));
  var t_infix_15 = (ok2(s, t_call_14, s.$max_speed_y) && (t_call_14 * s.$max_speed_y));
  var t_infix_16 = (ok2(s, t_call_13, t_infix_15) && (t_call_13 + t_infix_15));
  s.rt.logObjectMutation(s.$scene);
  (ok2(s, s.$scene, t_infix_16) && s.$scene.set_view_y(t_infix_16, s));
  } else {
  (s.pc = "2.72.e2d0");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3$1, 'a_a_xOCxKZH5B5Fbbm2N2BgFeCjp$3$1');

cs.startFn = function(rt) {
lib.App.rt_start(rt);
lib.Player.rt_start(rt);
lib.Senses.rt_start(rt);
lib.Time.rt_start(rt);
lib.Web.rt_start(rt);
};

cs.stopFn = function(rt) {
lib.App.rt_stop(rt);
lib.Player.rt_stop(rt);
lib.Senses.rt_stop(rt);
lib.Time.rt_stop(rt);
lib.Web.rt_stop(rt);
};

cs._compilerVersion = '1';cs._initGlobals = function(d) {
  if(!d.hasOwnProperty("$k7HatejkjqfIA242SSMpitAK")) d.$k7HatejkjqfIA242SSMpitAK = lib.DateTime.defaultValue;
  if(!d.hasOwnProperty("$VnuZVlq4It4ey9uDsKs4YbdR")) d.$VnuZVlq4It4ey9uDsKs4YbdR = "";
  if(!d.hasOwnProperty("$aTuZ6YFViE62QFkIlkkwKW12")) d.$aTuZ6YFViE62QFkIlkkwKW12 = "";
  if(!d.hasOwnProperty("$YkBWyq8FAIP9GNsp2XZd9aam")) d.$YkBWyq8FAIP9GNsp2XZd9aam = "";
  if(!d.hasOwnProperty("$TOlXyopWIthfSNmQ7K8HEulk")) d.$TOlXyopWIthfSNmQ7K8HEulk = "";
  if(!d.hasOwnProperty("$Lpz9hXJq4RUQjd5quEu4cq12")) d.$Lpz9hXJq4RUQjd5quEu4cq12 = "";
  if(!d.hasOwnProperty("$zKu4ADE6HhE7UI5GvT3xWZ2G")) d.$zKu4ADE6HhE7UI5GvT3xWZ2G = false;
  if(!d.hasOwnProperty("$BdGhpbmca") || !d["$BdGhpbmca"]) d.$BdGhpbmca = new Tbl_BdGhpbmca(d.libName);

};

cs._initGlobals2 = function(d) {
};

cs._resetGlobals = function(d) {
  d.$LJp5GBFLELwUrK3r6yVHOfL1 = undefined;
  d.$k7HatejkjqfIA242SSMpitAK = lib.DateTime.defaultValue;
  d.$VnuZVlq4It4ey9uDsKs4YbdR = "";
  d.$aTuZ6YFViE62QFkIlkkwKW12 = "";
  d.$YkBWyq8FAIP9GNsp2XZd9aam = "";
  d.$TOlXyopWIthfSNmQ7K8HEulk = "";
  d.$Lpz9hXJq4RUQjd5quEu4cq12 = "";
  d.$zKu4ADE6HhE7UI5GvT3xWZ2G = false;
  d.$BdGhpbmca = undefined;
};

cs.mainActionName = "current";
cs.authorId = "jjef";
cs.scriptId = "vroyc";
}),

// **************************************************************
"olZOoTBBwZaQT3B4fbkU2Y2c": (function (cs) {
'use strict';
var libs = cs.libs = {};
var lib = TDev.RT;
var callstackcurdepth = 0;
cs.scriptTitle = "sprite sheet";
cs.scriptColor = "\u00239955bb";
/* ACTION: initialize */
function a_AWkgzp4gwjt4o4w79a9LatRn(previous, returnAddr, $board) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_AWkgzp4gwjt4o4w79a9LatRn$0;
  s.name = "initialize";
  s.$board = $board;
  s.$perform = undefined;
  return s;
}
cs.registerAction("initialize", "AWkgzp4gwjt4o4w79a9LatRn", a_AWkgzp4gwjt4o4w79a9LatRn, true);

function ok1(s, a0) {
  return (a0 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok2(s, a0, a1) {
  return (a0 == undefined || a1 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok3(s, a0, a1, a2) {
  return (a0 == undefined || a1 == undefined || a2 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_AWkgzp4gwjt4o4w79a9LatRn$0(s) {
  (s.pc = "3.61");
  (/* board */ s.d.$ttDB4Z14tS2D49H96olVfxPC = s.$board);
  s.rt.logDataWrite();
  (s.pc = "3.64");
  var t_call_0 = (ok1(s, s.$board) && s.$board.create_sprite_set(s));
  (/* _animated sprites */ s.d.$HmpFOp0jnpX9U3gAc1t52p1l = t_call_0);
  s.rt.logDataWrite();
  (s.pc = "3.67");
  s.rt.logObjectMutation(/* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa);
  (ok1(s, /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa) && /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa.clear(s));
  (s.pc = "3.6a");
  s.rt.logObjectMutation(/* sheet index */ s.d.$Bc2hlZXQgaW5kZXga);
  (ok1(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.clear(s));
  (s.pc = "3.6h0");
  var t_lmbProxy_1 = s.libs.mkLambdaProxy;
  (s.$perform = function(la0, la1) { return a_a_AWkgzp4gwjt4o4w79a9LatRn$1(t_lmbProxy_1(la0), la1) });
  (s.pc = "3.6d");
  var t_call_2 = (ok2(s, s.$board, s.$perform) && s.$board.add_on_every_frame(s.$perform, s));
  t_call_2;
  return s.rt.leave();
}
cs.registerStep(a_AWkgzp4gwjt4o4w79a9LatRn$0, 'a_AWkgzp4gwjt4o4w79a9LatRn$0');

/* ACTION: a_AWkgzp4gwjt4o4w79a9LatRn::lambda::1 */
function a_a_AWkgzp4gwjt4o4w79a9LatRn$1(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_AWkgzp4gwjt4o4w79a9LatRn$1$0;
  s.name = "initialize";
  return s;
}
cs.registerLambda("a_AWkgzp4gwjt4o4w79a9LatRn\u003a\u003alambda\u003a\u003a1", "a_AWkgzp4gwjt4o4w79a9LatRn$1", a_a_AWkgzp4gwjt4o4w79a9LatRn$1, true);

function a_a_AWkgzp4gwjt4o4w79a9LatRn$1$0(s) {
  (s.pc = "3.6h20");
  return s.rt.enter(a_xXepqqhXptC4XpoSlcIj6822(s, a_a_AWkgzp4gwjt4o4w79a9LatRn$1$1));
}
cs.registerStep(a_a_AWkgzp4gwjt4o4w79a9LatRn$1$0, 'a_a_AWkgzp4gwjt4o4w79a9LatRn$1$0');

function a_a_AWkgzp4gwjt4o4w79a9LatRn$1$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  t_actRes_0;
  return s.rt.leave();
}
cs.registerStep(a_a_AWkgzp4gwjt4o4w79a9LatRn$1$1, 'a_a_AWkgzp4gwjt4o4w79a9LatRn$1$1');

/* ACTION: create sprite */
function a_iBz2fjvUTvuuMxl174JV39Iq(previous, returnAddr, $sheet_id, $row_index, $column_index) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_iBz2fjvUTvuuMxl174JV39Iq$0;
  s.name = "create sprite";
  s.$sheet_id = $sheet_id;
  s.$row_index = $row_index;
  s.$column_index = $column_index;
  s.result = undefined;
  s.$sheet = undefined;
  return s;
}
cs.registerAction("create sprite", "iBz2fjvUTvuuMxl174JV39Iq", a_iBz2fjvUTvuuMxl174JV39Iq, true);

function a_iBz2fjvUTvuuMxl174JV39Iq$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_iBz2fjvUTvuuMxl174JV39Iq$5, lib.RTValue.mkPicker(lib.String_.picker(), "", "sheet id", "$sheet_id"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "row index", "$row_index"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "column index", "$column_index"));
  return a_iBz2fjvUTvuuMxl174JV39Iq$5;
  }
  return a_iBz2fjvUTvuuMxl174JV39Iq$4;
}
cs.registerStep(a_iBz2fjvUTvuuMxl174JV39Iq$0, 'a_iBz2fjvUTvuuMxl174JV39Iq$0');

function a_iBz2fjvUTvuuMxl174JV39Iq$5(s) {
  return a_iBz2fjvUTvuuMxl174JV39Iq$4;
}
cs.registerStep(a_iBz2fjvUTvuuMxl174JV39Iq$5, 'a_iBz2fjvUTvuuMxl174JV39Iq$5');

function a_iBz2fjvUTvuuMxl174JV39Iq$4(s) {
  (s.pc = "3.c1");
  var t_infix_0 = (ok1(s, s.$row_index) && (s.$row_index >= 1));
  (ok1(s, t_infix_0) && lib.Contract.requires(t_infix_0, "row index must be greater or equal to 1", s));
  (s.pc = "3.c4");
  var t_infix_1 = (ok1(s, s.$column_index) && (s.$column_index >= 1));
  (ok1(s, t_infix_1) && lib.Contract.requires(t_infix_1, "column index must be greater or equal to 1", s));
  (s.pc = "3.c7");
  var t_call_2 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  (s.$sheet = t_call_2);
  (s.pc = "3.ca");
  if (s.$sheet) {
  var t_recOp_3 = s.$sheet.perform_get("qIAd2BInjEq6edaHJblgGXLR", s);
  }
  var t_resumeCtx_4 = s.rt.getBlockingResumeCtx(a_iBz2fjvUTvuuMxl174JV39Iq$2);
  var t_call_5 = (ok2(s, /* board */ s.d.$ttDB4Z14tS2D49H96olVfxPC, t_recOp_3) && /* board */ s.d.$ttDB4Z14tS2D49H96olVfxPC.create_picture(t_recOp_3, t_resumeCtx_4));
  return a_iBz2fjvUTvuuMxl174JV39Iq$2;
}
cs.registerStep(a_iBz2fjvUTvuuMxl174JV39Iq$4, 'a_iBz2fjvUTvuuMxl174JV39Iq$4');

function a_iBz2fjvUTvuuMxl174JV39Iq$2(s) {
  var t_pauseRes_6 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_6);
  (s.result = t_pauseRes_6);
  (s.pc = "3.cd");
  var t_infix_7 = (ok1(s, s.$column_index) && (s.$column_index - 1));
  var t_infix_8 = (ok1(s, s.$row_index) && (s.$row_index - 1));
  return s.rt.enter(a_x8elMgRejELmY0t80h770i2v(s, a_iBz2fjvUTvuuMxl174JV39Iq$3, s.$sheet, s.result, t_infix_7, t_infix_8));
}
cs.registerStep(a_iBz2fjvUTvuuMxl174JV39Iq$2, 'a_iBz2fjvUTvuuMxl174JV39Iq$2');

function a_iBz2fjvUTvuuMxl174JV39Iq$3(s) {
  var t_actRes_9 = s.rt.returnedFrom.result;
  t_actRes_9;
  if (s.previous.needsPicker) {
  s.rt.displayResult("sprite", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_iBz2fjvUTvuuMxl174JV39Iq$3, 'a_iBz2fjvUTvuuMxl174JV39Iq$3');

/* ACTION: set margin */
function a_giSKNZgi9Bsbf3wnIeavbjLM(previous, returnAddr, $sheet_id, $left, $top) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_giSKNZgi9Bsbf3wnIeavbjLM$0;
  s.name = "set margin";
  s.$sheet_id = $sheet_id;
  s.$left = $left;
  s.$top = $top;
  s.$sheet = undefined;
  return s;
}
cs.registerAction("set margin", "giSKNZgi9Bsbf3wnIeavbjLM", a_giSKNZgi9Bsbf3wnIeavbjLM, true);

function a_giSKNZgi9Bsbf3wnIeavbjLM$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_giSKNZgi9Bsbf3wnIeavbjLM$5, lib.RTValue.mkPicker(lib.String_.picker(), "", "sheet id", "$sheet_id"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "left", "$left"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "top", "$top"));
  return a_giSKNZgi9Bsbf3wnIeavbjLM$5;
  }
  return a_giSKNZgi9Bsbf3wnIeavbjLM$4;
}
cs.registerStep(a_giSKNZgi9Bsbf3wnIeavbjLM$0, 'a_giSKNZgi9Bsbf3wnIeavbjLM$0');

function a_giSKNZgi9Bsbf3wnIeavbjLM$5(s) {
  return a_giSKNZgi9Bsbf3wnIeavbjLM$4;
}
cs.registerStep(a_giSKNZgi9Bsbf3wnIeavbjLM$5, 'a_giSKNZgi9Bsbf3wnIeavbjLM$5');

function a_giSKNZgi9Bsbf3wnIeavbjLM$4(s) {
  (s.pc = "3.h1");
  var t_call_0 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  (s.$sheet = t_call_0);
  (s.pc = "3.h4");
  if (s.$sheet) {
  s.$sheet.perform_set("BZY9s61lmNNxBW31EfVNb4vl", s.$left, s);
  }
  (s.pc = "3.h7");
  if (s.$sheet) {
  s.$sheet.perform_set("rlBRdLfNyC8etUZ7YFUMLIvQ", s.$top, s);
  }
  (s.pc = "3.ha");
  return s.rt.enter(a_rv4uTbsBkglHdyoc2ekrt3Wb(s, a_giSKNZgi9Bsbf3wnIeavbjLM$3, s.$sheet));
}
cs.registerStep(a_giSKNZgi9Bsbf3wnIeavbjLM$4, 'a_giSKNZgi9Bsbf3wnIeavbjLM$4');

function a_giSKNZgi9Bsbf3wnIeavbjLM$3(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  t_actRes_1;
  return s.rt.leave();
}
cs.registerStep(a_giSKNZgi9Bsbf3wnIeavbjLM$3, 'a_giSKNZgi9Bsbf3wnIeavbjLM$3');

/* ACTION: set gap */
function a_xEqTqdjmt0whKMLqkyydiQJq(previous, returnAddr, $sheet_id, $row, $column) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xEqTqdjmt0whKMLqkyydiQJq$0;
  s.name = "set gap";
  s.$sheet_id = $sheet_id;
  s.$row = $row;
  s.$column = $column;
  s.$sheet = undefined;
  return s;
}
cs.registerAction("set gap", "xEqTqdjmt0whKMLqkyydiQJq", a_xEqTqdjmt0whKMLqkyydiQJq, true);

function a_xEqTqdjmt0whKMLqkyydiQJq$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_xEqTqdjmt0whKMLqkyydiQJq$5, lib.RTValue.mkPicker(lib.String_.picker(), "", "sheet id", "$sheet_id"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "row", "$row"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "column", "$column"));
  return a_xEqTqdjmt0whKMLqkyydiQJq$5;
  }
  return a_xEqTqdjmt0whKMLqkyydiQJq$4;
}
cs.registerStep(a_xEqTqdjmt0whKMLqkyydiQJq$0, 'a_xEqTqdjmt0whKMLqkyydiQJq$0');

function a_xEqTqdjmt0whKMLqkyydiQJq$5(s) {
  return a_xEqTqdjmt0whKMLqkyydiQJq$4;
}
cs.registerStep(a_xEqTqdjmt0whKMLqkyydiQJq$5, 'a_xEqTqdjmt0whKMLqkyydiQJq$5');

function a_xEqTqdjmt0whKMLqkyydiQJq$4(s) {
  (s.pc = "3.m1");
  var t_call_0 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  (s.$sheet = t_call_0);
  (s.pc = "3.m4");
  if (s.$sheet) {
  s.$sheet.perform_set("xk1X2K46Gohe2a2nULBivsfe", s.$row, s);
  }
  (s.pc = "3.m7");
  if (s.$sheet) {
  s.$sheet.perform_set("xPbwdlEz1e26Rg2gTnjl4r4L", s.$column, s);
  }
  (s.pc = "3.ma");
  return s.rt.enter(a_rv4uTbsBkglHdyoc2ekrt3Wb(s, a_xEqTqdjmt0whKMLqkyydiQJq$3, s.$sheet));
}
cs.registerStep(a_xEqTqdjmt0whKMLqkyydiQJq$4, 'a_xEqTqdjmt0whKMLqkyydiQJq$4');

function a_xEqTqdjmt0whKMLqkyydiQJq$3(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  t_actRes_1;
  return s.rt.leave();
}
cs.registerStep(a_xEqTqdjmt0whKMLqkyydiQJq$3, 'a_xEqTqdjmt0whKMLqkyydiQJq$3');

/* ACTION: draw grid */
function a_Zkf6y2qUXGElCZQFx2Acp2cN(previous, returnAddr, $sheet_id) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Zkf6y2qUXGElCZQFx2Acp2cN$0;
  s.name = "draw grid";
  s.$sheet_id = $sheet_id;
  s.result = undefined;
  s.$sheet = undefined;
  s.$pic = undefined;
  s.$rows = undefined;
  s.$columns = undefined;
  s.$row_height = undefined;
  s.$column_width = undefined;
  s.$ri = undefined;
  s.$ci = undefined;
  return s;
}
cs.registerAction("draw grid", "Zkf6y2qUXGElCZQFx2Acp2cN", a_Zkf6y2qUXGElCZQFx2Acp2cN, true);

function ok4(s, a0, a1, a2, a3) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok5(s, a0, a1, a2, a3, a4) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok6(s, a0, a1, a2, a3, a4, a5) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined || a5 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok7(s, a0, a1, a2, a3, a4, a5, a6) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined || a5 == undefined || a6 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok8(s, a0, a1, a2, a3, a4, a5, a6, a7) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined || a5 == undefined || a6 == undefined || a7 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok9(s, a0, a1, a2, a3, a4, a5, a6, a7, a8) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined || a5 == undefined || a6 == undefined || a7 == undefined || a8 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_Zkf6y2qUXGElCZQFx2Acp2cN$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_Zkf6y2qUXGElCZQFx2Acp2cN$15, lib.RTValue.mkPicker(lib.String_.picker(), "", "sheet id", "$sheet_id"));
  return a_Zkf6y2qUXGElCZQFx2Acp2cN$15;
  }
  return a_Zkf6y2qUXGElCZQFx2Acp2cN$14;
}
cs.registerStep(a_Zkf6y2qUXGElCZQFx2Acp2cN$0, 'a_Zkf6y2qUXGElCZQFx2Acp2cN$0');

function a_Zkf6y2qUXGElCZQFx2Acp2cN$15(s) {
  return a_Zkf6y2qUXGElCZQFx2Acp2cN$14;
}
cs.registerStep(a_Zkf6y2qUXGElCZQFx2Acp2cN$15, 'a_Zkf6y2qUXGElCZQFx2Acp2cN$15');

function a_Zkf6y2qUXGElCZQFx2Acp2cN$14(s) {
  (s.pc = "3.r1");
  var t_call_0 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  (s.$sheet = t_call_0);
  (s.pc = "3.r4");
  if (s.$sheet) {
  var t_recOp_1 = s.$sheet.perform_get("qIAd2BInjEq6edaHJblgGXLR", s);
  }
  (s.$pic = t_recOp_1);
  (s.pc = "3.r7");
  if (s.$sheet) {
  var t_recOp_2 = s.$sheet.perform_get("WTX3n2nWqIYVXj0hFUbVnYwx", s);
  }
  (s.$rows = t_recOp_2);
  (s.pc = "3.ra");
  if (s.$sheet) {
  var t_recOp_3 = s.$sheet.perform_get("V0wVfXUEE41TErckLkYDPlPP", s);
  }
  (s.$columns = t_recOp_3);
  (s.pc = "3.rd");
  if (s.$sheet) {
  var t_recOp_4 = s.$sheet.perform_get("lmz3Kh04x9Vn35VFJEHm1Mir", s);
  }
  (s.$row_height = t_recOp_4);
  (s.pc = "3.rg");
  if (s.$sheet) {
  var t_recOp_5 = s.$sheet.perform_get("cZgN30Klau1iSnUzQQXVt0nw", s);
  }
  (s.$column_width = t_recOp_5);
  (s.pc = "3.rj");
  var t_resumeCtx_6 = s.rt.getBlockingResumeCtx(a_Zkf6y2qUXGElCZQFx2Acp2cN$6);
  var t_call_7 = (ok1(s, s.$pic) && s.$pic.clone(t_resumeCtx_6));
  return a_Zkf6y2qUXGElCZQFx2Acp2cN$6;
}
cs.registerStep(a_Zkf6y2qUXGElCZQFx2Acp2cN$14, 'a_Zkf6y2qUXGElCZQFx2Acp2cN$14');

function a_Zkf6y2qUXGElCZQFx2Acp2cN$6(s) {
  var t_pauseRes_8 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_8);
  (s.result = t_pauseRes_8);
  (s.pc = "3.rm");
  s.t_bnd_9 = s.$rows;
  (s.$ri = 0);
  return a_Zkf6y2qUXGElCZQFx2Acp2cN$7;
}
cs.registerStep(a_Zkf6y2qUXGElCZQFx2Acp2cN$6, 'a_Zkf6y2qUXGElCZQFx2Acp2cN$6');

function a_Zkf6y2qUXGElCZQFx2Acp2cN$7(s) {
  if ((s.$ri < s.t_bnd_9)) {
  (s.pc = "3.rq0");
  s.t_bnd_10 = s.$columns;
  (s.$ci = 0);
  return a_Zkf6y2qUXGElCZQFx2Acp2cN$9;
  }
  if (s.previous.needsPicker) {
  s.rt.displayResult("r", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_Zkf6y2qUXGElCZQFx2Acp2cN$7, 'a_Zkf6y2qUXGElCZQFx2Acp2cN$7');

function a_Zkf6y2qUXGElCZQFx2Acp2cN$9(s) {
  if ((s.$ci < s.t_bnd_10)) {
  (s.pc = "3.rq40");
  return s.rt.enter(a_U8KRwHyZDdEZoJfsT4VEXNsS(s, a_Zkf6y2qUXGElCZQFx2Acp2cN$11, s.$sheet, s.$ci));
  }
  (s.$ri++);
  return a_Zkf6y2qUXGElCZQFx2Acp2cN$7;
}
cs.registerStep(a_Zkf6y2qUXGElCZQFx2Acp2cN$9, 'a_Zkf6y2qUXGElCZQFx2Acp2cN$9');

function a_Zkf6y2qUXGElCZQFx2Acp2cN$11(s) {
  s.t_actRes_11 = s.rt.returnedFrom.result;
  return s.rt.enter(a_KPGb82K0RKe3jhJRDhMtq17X(s, a_Zkf6y2qUXGElCZQFx2Acp2cN$12, s.$sheet, s.$ri));
}
cs.registerStep(a_Zkf6y2qUXGElCZQFx2Acp2cN$11, 'a_Zkf6y2qUXGElCZQFx2Acp2cN$11');

function a_Zkf6y2qUXGElCZQFx2Acp2cN$12(s) {
  var t_actRes_12 = s.rt.returnedFrom.result;
  var t_call_13 = lib.Colors.blue(s);
  s.rt.logObjectMutation(s.result);
  var t_resumeCtx_14 = s.rt.getBlockingResumeCtx(a_Zkf6y2qUXGElCZQFx2Acp2cN$13);
  (ok6(s, s.result, s.t_actRes_11, t_actRes_12, s.$column_width, s.$row_height, t_call_13) && s.result.draw_rect(s.t_actRes_11, t_actRes_12, s.$column_width, s.$row_height, 0, t_call_13, 1, t_resumeCtx_14));
  return a_Zkf6y2qUXGElCZQFx2Acp2cN$13;
}
cs.registerStep(a_Zkf6y2qUXGElCZQFx2Acp2cN$12, 'a_Zkf6y2qUXGElCZQFx2Acp2cN$12');

function a_Zkf6y2qUXGElCZQFx2Acp2cN$13(s) {
  (s.$ci++);
  return a_Zkf6y2qUXGElCZQFx2Acp2cN$9;
}
cs.registerStep(a_Zkf6y2qUXGElCZQFx2Acp2cN$13, 'a_Zkf6y2qUXGElCZQFx2Acp2cN$13');

/* ACTION: left */
function a_U8KRwHyZDdEZoJfsT4VEXNsS(previous, returnAddr, $sheet, $column) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_U8KRwHyZDdEZoJfsT4VEXNsS$0;
  s.name = "left";
  s.$sheet = $sheet;
  s.$column = $column;
  s.result = undefined;
  return s;
}
cs.registerAction("left", "U8KRwHyZDdEZoJfsT4VEXNsS", a_U8KRwHyZDdEZoJfsT4VEXNsS, true);

function a_U8KRwHyZDdEZoJfsT4VEXNsS$0(s) {
  (s.pc = "3.w0");
  if (s.$sheet) {
  var t_recOp_0 = s.$sheet.perform_get("BZY9s61lmNNxBW31EfVNb4vl", s);
  }
  if (s.$sheet) {
  var t_recOp_1 = s.$sheet.perform_get("cZgN30Klau1iSnUzQQXVt0nw", s);
  }
  var t_infix_2 = (ok2(s, s.$column, t_recOp_1) && (s.$column * t_recOp_1));
  var t_infix_3 = (ok2(s, t_recOp_0, t_infix_2) && (t_recOp_0 + t_infix_2));
  var t_infix_4 = (ok1(s, s.$column) && (s.$column - 1));
  var t_call_5 = (ok1(s, t_infix_4) && lib.Math_.max(0, t_infix_4, s));
  if (s.$sheet) {
  var t_recOp_6 = s.$sheet.perform_get("xPbwdlEz1e26Rg2gTnjl4r4L", s);
  }
  var t_infix_7 = (ok2(s, t_call_5, t_recOp_6) && (t_call_5 * t_recOp_6));
  var t_infix_8 = (ok2(s, t_infix_3, t_infix_7) && (t_infix_3 + t_infix_7));
  (s.result = t_infix_8);
  return s.rt.leave();
}
cs.registerStep(a_U8KRwHyZDdEZoJfsT4VEXNsS$0, 'a_U8KRwHyZDdEZoJfsT4VEXNsS$0');

/* ACTION: top */
function a_KPGb82K0RKe3jhJRDhMtq17X(previous, returnAddr, $sheet, $row) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_KPGb82K0RKe3jhJRDhMtq17X$0;
  s.name = "top";
  s.$sheet = $sheet;
  s.$row = $row;
  s.result = undefined;
  return s;
}
cs.registerAction("top", "KPGb82K0RKe3jhJRDhMtq17X", a_KPGb82K0RKe3jhJRDhMtq17X, true);

function a_KPGb82K0RKe3jhJRDhMtq17X$0(s) {
  (s.pc = "3.B0");
  if (s.$sheet) {
  var t_recOp_0 = s.$sheet.perform_get("rlBRdLfNyC8etUZ7YFUMLIvQ", s);
  }
  if (s.$sheet) {
  var t_recOp_1 = s.$sheet.perform_get("lmz3Kh04x9Vn35VFJEHm1Mir", s);
  }
  var t_infix_2 = (ok2(s, s.$row, t_recOp_1) && (s.$row * t_recOp_1));
  var t_infix_3 = (ok2(s, t_recOp_0, t_infix_2) && (t_recOp_0 + t_infix_2));
  var t_infix_4 = (ok1(s, s.$row) && (s.$row - 1));
  var t_call_5 = (ok1(s, t_infix_4) && lib.Math_.max(0, t_infix_4, s));
  if (s.$sheet) {
  var t_recOp_6 = s.$sheet.perform_get("xk1X2K46Gohe2a2nULBivsfe", s);
  }
  var t_infix_7 = (ok2(s, t_call_5, t_recOp_6) && (t_call_5 * t_recOp_6));
  var t_infix_8 = (ok2(s, t_infix_3, t_infix_7) && (t_infix_3 + t_infix_7));
  (s.result = t_infix_8);
  return s.rt.leave();
}
cs.registerStep(a_KPGb82K0RKe3jhJRDhMtq17X$0, 'a_KPGb82K0RKe3jhJRDhMtq17X$0');

/* ACTION: compute sizes */
function a_rv4uTbsBkglHdyoc2ekrt3Wb(previous, returnAddr, $sheet) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_rv4uTbsBkglHdyoc2ekrt3Wb$0;
  s.name = "compute sizes";
  s.$sheet = $sheet;
  s.$pic = undefined;
  s.$columns = undefined;
  s.$column_gap = undefined;
  s.$rows = undefined;
  s.$row_gap = undefined;
  s.$left_margin = undefined;
  s.$top_margin = undefined;
  return s;
}
cs.registerAction("compute sizes", "rv4uTbsBkglHdyoc2ekrt3Wb", a_rv4uTbsBkglHdyoc2ekrt3Wb, true);

function a_rv4uTbsBkglHdyoc2ekrt3Wb$0(s) {
  (s.pc = "3.G0");
  if (s.$sheet) {
  var t_recOp_0 = s.$sheet.perform_get("qIAd2BInjEq6edaHJblgGXLR", s);
  }
  (s.$pic = t_recOp_0);
  (s.pc = "3.G3");
  if (s.$sheet) {
  var t_recOp_1 = s.$sheet.perform_get("V0wVfXUEE41TErckLkYDPlPP", s);
  }
  (s.$columns = t_recOp_1);
  (s.pc = "3.G6");
  if (s.$sheet) {
  var t_recOp_2 = s.$sheet.perform_get("xPbwdlEz1e26Rg2gTnjl4r4L", s);
  }
  (s.$column_gap = t_recOp_2);
  (s.pc = "3.G9");
  if (s.$sheet) {
  var t_recOp_3 = s.$sheet.perform_get("WTX3n2nWqIYVXj0hFUbVnYwx", s);
  }
  (s.$rows = t_recOp_3);
  (s.pc = "3.Gc");
  if (s.$sheet) {
  var t_recOp_4 = s.$sheet.perform_get("xk1X2K46Gohe2a2nULBivsfe", s);
  }
  (s.$row_gap = t_recOp_4);
  (s.pc = "3.Gf");
  if (s.$sheet) {
  var t_recOp_5 = s.$sheet.perform_get("BZY9s61lmNNxBW31EfVNb4vl", s);
  }
  (s.$left_margin = t_recOp_5);
  (s.pc = "3.Gi");
  if (s.$sheet) {
  var t_recOp_6 = s.$sheet.perform_get("rlBRdLfNyC8etUZ7YFUMLIvQ", s);
  }
  (s.$top_margin = t_recOp_6);
  (s.pc = "3.Gl");
  var t_resumeCtx_7 = s.rt.getBlockingResumeCtx(a_rv4uTbsBkglHdyoc2ekrt3Wb$8);
  var t_call_8 = (ok1(s, s.$pic) && s.$pic.width(t_resumeCtx_7));
  return a_rv4uTbsBkglHdyoc2ekrt3Wb$8;
}
cs.registerStep(a_rv4uTbsBkglHdyoc2ekrt3Wb$0, 'a_rv4uTbsBkglHdyoc2ekrt3Wb$0');

function a_rv4uTbsBkglHdyoc2ekrt3Wb$8(s) {
  var t_pauseRes_9 = s.pauseValue;
  var t_infix_10 = (ok1(s, s.$left_margin) && (2 * s.$left_margin));
  var t_infix_11 = (ok2(s, t_pauseRes_9, t_infix_10) && (t_pauseRes_9 - t_infix_10));
  var t_infix_12 = (ok1(s, s.$columns) && (s.$columns - 1));
  var t_infix_13 = (ok2(s, t_infix_12, s.$column_gap) && (t_infix_12 * s.$column_gap));
  var t_infix_14 = (ok2(s, t_infix_11, t_infix_13) && (t_infix_11 - t_infix_13));
  var t_infix_15 = (ok2(s, t_infix_14, s.$columns) && (t_infix_14 / s.$columns));
  if (s.$sheet) {
  s.$sheet.perform_set("cZgN30Klau1iSnUzQQXVt0nw", t_infix_15, s);
  }
  (s.pc = "3.Go");
  var t_resumeCtx_16 = s.rt.getBlockingResumeCtx(a_rv4uTbsBkglHdyoc2ekrt3Wb$10);
  var t_call_17 = (ok1(s, s.$pic) && s.$pic.height(t_resumeCtx_16));
  return a_rv4uTbsBkglHdyoc2ekrt3Wb$10;
}
cs.registerStep(a_rv4uTbsBkglHdyoc2ekrt3Wb$8, 'a_rv4uTbsBkglHdyoc2ekrt3Wb$8');

function a_rv4uTbsBkglHdyoc2ekrt3Wb$10(s) {
  var t_pauseRes_18 = s.pauseValue;
  var t_infix_19 = (ok1(s, s.$top_margin) && (2 * s.$top_margin));
  var t_infix_20 = (ok2(s, t_pauseRes_18, t_infix_19) && (t_pauseRes_18 - t_infix_19));
  var t_infix_21 = (ok1(s, s.$rows) && (s.$rows - 1));
  var t_infix_22 = (ok2(s, t_infix_21, s.$row_gap) && (t_infix_21 * s.$row_gap));
  var t_infix_23 = (ok2(s, t_infix_20, t_infix_22) && (t_infix_20 - t_infix_22));
  var t_infix_24 = (ok2(s, t_infix_23, s.$rows) && (t_infix_23 / s.$rows));
  if (s.$sheet) {
  s.$sheet.perform_set("lmz3Kh04x9Vn35VFJEHm1Mir", t_infix_24, s);
  }
  (s.pc = "3.Gr");
  return s.rt.enter(a_xXepqqhXptC4XpoSlcIj6822(s, a_rv4uTbsBkglHdyoc2ekrt3Wb$12));
}
cs.registerStep(a_rv4uTbsBkglHdyoc2ekrt3Wb$10, 'a_rv4uTbsBkglHdyoc2ekrt3Wb$10');

function a_rv4uTbsBkglHdyoc2ekrt3Wb$12(s) {
  var t_actRes_25 = s.rt.returnedFrom.result;
  t_actRes_25;
  return s.rt.leave();
}
cs.registerStep(a_rv4uTbsBkglHdyoc2ekrt3Wb$12, 'a_rv4uTbsBkglHdyoc2ekrt3Wb$12');

/* ACTION: example */
function a_Jy4AIeUOZLfTXtzBZIWpI2UJ(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Jy4AIeUOZLfTXtzBZIWpI2UJ$0;
  s.name = "example";
  s.$board = undefined;
  s.$rows = undefined;
  s.$columns = undefined;
  s.$pic = undefined;
  s.$i = undefined;
  s.$j = undefined;
  s.$left = undefined;
  s.$top = undefined;
  s.$x = undefined;
  s.$color = undefined;
  s.$sheet_id = undefined;
  s.$sprite_row_index = undefined;
  s.$sprite_column_index = undefined;
  s.$spri = undefined;
  s.$animation_duration = undefined;
  s.$animation_loops = undefined;
  s.$animated = undefined;
  s.$duration = undefined;
  s.$loops = undefined;
  return s;
}
cs.registerAction("example", "Jy4AIeUOZLfTXtzBZIWpI2UJ", a_Jy4AIeUOZLfTXtzBZIWpI2UJ, true);

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$0(s) {
  (s.pc = "3.L2");
  var t_call_0 = lib.Media.create_board(200, s);
  s.rt.markAllocated(t_call_0);
  (s.$board = t_call_0);
  (s.pc = "3.L5");
  var t_call_1 = lib.Colors.light_gray(s);
  s.rt.logObjectMutation(s.$board);
  (ok2(s, s.$board, t_call_1) && s.$board.set_background(t_call_1, s));
  (s.pc = "3.L8");
  (ok1(s, s.$board) && s.$board.post_to_wall(s));
  (s.pc = "3.Lc");
  (s.$rows = 4);
  (s.pc = "3.Lf");
  (s.$columns = 6);
  (s.pc = "3.Li");
  var t_call_2 = lib.Media.create_picture(480, 320, s);
  s.rt.markAllocated(t_call_2);
  (s.$pic = t_call_2);
  (s.pc = "3.Ll");
  s.t_bnd_3 = s.$rows;
  (s.$i = 0);
  return a_Jy4AIeUOZLfTXtzBZIWpI2UJ$1;
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$0, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$0');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$1(s) {
  if ((s.$i < s.t_bnd_3)) {
  (s.pc = "3.Lp0");
  s.t_bnd_4 = s.$columns;
  (s.$j = 0);
  return a_Jy4AIeUOZLfTXtzBZIWpI2UJ$3;
  }
  (s.pc = "3.Lp");
  (ok1(s, s.$pic) && s.$pic.update_on_wall(s));
  (s.pc = "3.Lu");
  return s.rt.enter(a_AWkgzp4gwjt4o4w79a9LatRn(s, a_Jy4AIeUOZLfTXtzBZIWpI2UJ$7, s.$board));
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$1, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$1');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$3(s) {
  if ((s.$j < s.t_bnd_4)) {
  (s.pc = "3.Lp40");
  var t_infix_5 = (ok1(s, s.$j) && (s.$j * 80));
  var t_infix_6 = (ok1(s, t_infix_5) && (20 + t_infix_5));
  (s.$left = t_infix_6);
  (s.pc = "3.Lp43");
  var t_infix_7 = (ok1(s, s.$i) && (s.$i * 80));
  var t_infix_8 = (ok1(s, t_infix_7) && (20 + t_infix_7));
  (s.$top = t_infix_8);
  (s.pc = "3.Lp46");
  var t_infix_9 = (ok2(s, s.$j, s.$rows) && (s.$j * s.$rows));
  var t_infix_10 = (ok2(s, s.$i, t_infix_9) && (s.$i + t_infix_9));
  (s.$x = t_infix_10);
  (s.pc = "3.Lp49");
  var t_call_11 = lib.Colors.magenta(s);
  var t_call_12 = lib.Colors.orange(s);
  var t_infix_13 = (ok1(s, s.$x) && (s.$x / 25));
  var t_call_14 = (ok3(s, t_call_11, t_call_12, t_infix_13) && lib.Colors.linear_gradient(t_call_11, t_call_12, t_infix_13, s));
  (s.$color = t_call_14);
  (s.pc = "3.Lp4c");
  var t_infix_15 = (ok1(s, s.$left) && (s.$left - 10));
  var t_infix_16 = (ok1(s, s.$top) && (s.$top - 10));
  s.rt.logObjectMutation(s.$pic);
  var t_resumeCtx_17 = s.rt.getBlockingResumeCtx(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$5);
  (ok4(s, s.$pic, t_infix_15, t_infix_16, s.$color) && s.$pic.fill_ellipse(t_infix_15, t_infix_16, 60, 60, 0, s.$color, t_resumeCtx_17));
  return a_Jy4AIeUOZLfTXtzBZIWpI2UJ$5;
  }
  (s.$i++);
  return a_Jy4AIeUOZLfTXtzBZIWpI2UJ$1;
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$3, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$3');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$7(s) {
  var t_actRes_24 = s.rt.returnedFrom.result;
  t_actRes_24;
  (s.pc = "3.Lz");
  (s.$sheet_id = "bubbles");
  (s.pc = "3.LC");
  return s.rt.enter(a_PHYFRyCfW0KmUyV6uk97VWId(s, a_Jy4AIeUOZLfTXtzBZIWpI2UJ$8, s.$sheet_id, s.$pic, s.$rows, s.$columns));
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$7, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$7');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$5(s) {
  (s.pc = "3.Lp4f");
  var t_infix_18 = (ok1(s, s.$i) && (s.$i + 1));
  var t_concat_19 = lib.String_.concatAny(t_infix_18, "\u002c");
  var t_infix_20 = (ok1(s, s.$j) && (s.$j + 1));
  var t_concat_21 = lib.String_.concatAny(t_concat_19, t_infix_20);
  var t_call_22 = lib.Colors.white(s);
  s.rt.logObjectMutation(s.$pic);
  var t_resumeCtx_23 = s.rt.getBlockingResumeCtx(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$6);
  (ok5(s, s.$pic, s.$left, s.$top, t_concat_21, t_call_22) && s.$pic.draw_text(s.$left, s.$top, t_concat_21, 24, 0, t_call_22, t_resumeCtx_23));
  return a_Jy4AIeUOZLfTXtzBZIWpI2UJ$6;
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$5, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$5');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$8(s) {
  var t_actRes_25 = s.rt.returnedFrom.result;
  t_actRes_25;
  (s.pc = "3.LG");
  return s.rt.enter(a_Zkf6y2qUXGElCZQFx2Acp2cN(s, a_Jy4AIeUOZLfTXtzBZIWpI2UJ$9, s.$sheet_id));
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$8, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$8');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$6(s) {
  (s.$j++);
  return a_Jy4AIeUOZLfTXtzBZIWpI2UJ$3;
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$6, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$6');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$9(s) {
  var t_actRes_26 = s.rt.returnedFrom.result;
  (ok1(s, t_actRes_26) && t_actRes_26.post_to_wall(s));
  (s.pc = "3.LP");
  (s.$sprite_row_index = 1);
  (s.pc = "3.LS");
  (s.$sprite_column_index = 5);
  (s.pc = "3.LV");
  return s.rt.enter(a_iBz2fjvUTvuuMxl174JV39Iq(s, a_Jy4AIeUOZLfTXtzBZIWpI2UJ$10, s.$sheet_id, s.$sprite_row_index, s.$sprite_column_index));
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$9, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$9');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$10(s) {
  var t_actRes_27 = s.rt.returnedFrom.result;
  (s.$spri = t_actRes_27);
  (s.pc = "3.LY");
  s.rt.logObjectMutation(s.$spri);
  (ok1(s, s.$spri) && s.$spri.set_pos(50, 50, s));
  (s.pc = "3.L63.");
  s.rt.logObjectMutation(s.$board);
  (ok1(s, s.$board) && s.$board.update_on_wall(s));
  (s.pc = "3.L68.");
  return s.rt.enter(a_fa9qr7Vx9rfVuZ5EUvuxBKc2(s, a_Jy4AIeUOZLfTXtzBZIWpI2UJ$11, s.$sheet_id, s.$spri, 1, 5));
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$10, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$10');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$11(s) {
  var t_actRes_28 = s.rt.returnedFrom.result;
  t_actRes_28;
  (s.pc = "3.L71.");
  s.rt.logObjectMutation(s.$board);
  (ok1(s, s.$board) && s.$board.update_on_wall(s));
  (s.pc = "3.L78.");
  (s.$animation_duration = 3);
  (s.pc = "3.L81.");
  (s.$animation_loops = 2);
  (s.pc = "3.L84.");
  return s.rt.enter(a_vJZ80S26SY13iReukIMXzPdy(s, a_Jy4AIeUOZLfTXtzBZIWpI2UJ$12, s.$sheet_id, s.$animation_duration, s.$animation_loops));
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$11, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$11');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$12(s) {
  var t_actRes_29 = s.rt.returnedFrom.result;
  (s.$animated = t_actRes_29);
  (s.pc = "3.L87.");
  s.rt.logObjectMutation(s.$animated);
  (ok1(s, s.$animated) && s.$animated.set_pos(150, 50, s));
  (s.pc = "3.L90.");
  return a_Jy4AIeUOZLfTXtzBZIWpI2UJ$13;
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$12, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$12');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$13(s) {
  if (true) {
  (s.pc = "3.L94.0");
  return s.rt.enter(a_xXepqqhXptC4XpoSlcIj6822(s, a_Jy4AIeUOZLfTXtzBZIWpI2UJ$15));
  }
  (s.pc = "3.L96.");
  (s.$duration = 3);
  (s.pc = "3.L99.");
  (s.$loops = 2);
  (s.pc = "3.L102.");
  return s.rt.enter(a_g0e2F0y8lMxbuhCC6w5hSJ9a(s, a_Jy4AIeUOZLfTXtzBZIWpI2UJ$17, s.$sheet_id, s.$animation_duration, s.$animation_loops, 1, 1, s.$rows, s.$columns));
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$13, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$13');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$15(s) {
  var t_actRes_30 = s.rt.returnedFrom.result;
  t_actRes_30;
  (s.pc = "3.L94.3");
  var t_resumeCtx_31 = s.rt.getAwaitResumeCtx(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$16);
  lib.Time.sleep(0.1, t_resumeCtx_31);
  return a_Jy4AIeUOZLfTXtzBZIWpI2UJ$16;
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$15, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$15');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$17(s) {
  var t_actRes_32 = s.rt.returnedFrom.result;
  (s.$animated = t_actRes_32);
  (s.pc = "3.L107.");
  return s.rt.enter(a_Wm3TTqWIBbOrHYYz43aQL8oz(s, a_Jy4AIeUOZLfTXtzBZIWpI2UJ$18, s.$sheet_id, s.$animated, s.$duration, s.$loops, false, 0, 0, s.$rows, s.$columns));
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$17, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$17');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$16(s) {
  (s.pc = "3.L94.6");
  s.rt.logObjectMutation(s.$board);
  (ok1(s, s.$board) && s.$board.update_on_wall(s));
  return a_Jy4AIeUOZLfTXtzBZIWpI2UJ$13;
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$16, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$16');

function a_Jy4AIeUOZLfTXtzBZIWpI2UJ$18(s) {
  var t_actRes_33 = s.rt.returnedFrom.result;
  t_actRes_33;
  return s.rt.leave();
}
cs.registerStep(a_Jy4AIeUOZLfTXtzBZIWpI2UJ$18, 'a_Jy4AIeUOZLfTXtzBZIWpI2UJ$18');

/* ACTION: set sprite picture */
function a_fa9qr7Vx9rfVuZ5EUvuxBKc2(previous, returnAddr, $sheet_id, $sprite, $row_index, $column_index) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_fa9qr7Vx9rfVuZ5EUvuxBKc2$0;
  s.name = "set sprite picture";
  s.$sheet_id = $sheet_id;
  s.$sprite = $sprite;
  s.$row_index = $row_index;
  s.$column_index = $column_index;
  s.$sheet = undefined;
  return s;
}
cs.registerAction("set sprite picture", "fa9qr7Vx9rfVuZ5EUvuxBKc2", a_fa9qr7Vx9rfVuZ5EUvuxBKc2, true);

function a_fa9qr7Vx9rfVuZ5EUvuxBKc2$0(s) {
  (s.pc = "3.Q1");
  var t_infix_0 = (ok1(s, s.$row_index) && (s.$row_index >= 1));
  (ok1(s, t_infix_0) && lib.Contract.requires(t_infix_0, "row index must be greater or equal to 1", s));
  (s.pc = "3.Q4");
  var t_infix_1 = (ok1(s, s.$column_index) && (s.$column_index >= 1));
  (ok1(s, t_infix_1) && lib.Contract.requires(t_infix_1, "column index must be greater or equal to 1", s));
  (s.pc = "3.Q7");
  var t_call_2 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  (s.$sheet = t_call_2);
  (s.pc = "3.Qa");
  var t_infix_3 = (ok1(s, s.$column_index) && (s.$column_index - 1));
  var t_infix_4 = (ok1(s, s.$row_index) && (s.$row_index - 1));
  return s.rt.enter(a_x8elMgRejELmY0t80h770i2v(s, a_fa9qr7Vx9rfVuZ5EUvuxBKc2$1, s.$sheet, s.$sprite, t_infix_3, t_infix_4));
}
cs.registerStep(a_fa9qr7Vx9rfVuZ5EUvuxBKc2$0, 'a_fa9qr7Vx9rfVuZ5EUvuxBKc2$0');

function a_fa9qr7Vx9rfVuZ5EUvuxBKc2$1(s) {
  var t_actRes_5 = s.rt.returnedFrom.result;
  t_actRes_5;
  return s.rt.leave();
}
cs.registerStep(a_fa9qr7Vx9rfVuZ5EUvuxBKc2$1, 'a_fa9qr7Vx9rfVuZ5EUvuxBKc2$1');

/* ACTION: rows */
function a_hoR5fLJDaWCqEiEZpL2h48LT(previous, returnAddr, $sheet_id) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_hoR5fLJDaWCqEiEZpL2h48LT$0;
  s.name = "rows";
  s.$sheet_id = $sheet_id;
  s.result = undefined;
  return s;
}
cs.registerAction("rows", "hoR5fLJDaWCqEiEZpL2h48LT", a_hoR5fLJDaWCqEiEZpL2h48LT, true);

function a_hoR5fLJDaWCqEiEZpL2h48LT$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_hoR5fLJDaWCqEiEZpL2h48LT$3, lib.RTValue.mkPicker(lib.String_.picker(), "", "sheet id", "$sheet_id"));
  return a_hoR5fLJDaWCqEiEZpL2h48LT$3;
  }
  return a_hoR5fLJDaWCqEiEZpL2h48LT$2;
}
cs.registerStep(a_hoR5fLJDaWCqEiEZpL2h48LT$0, 'a_hoR5fLJDaWCqEiEZpL2h48LT$0');

function a_hoR5fLJDaWCqEiEZpL2h48LT$3(s) {
  return a_hoR5fLJDaWCqEiEZpL2h48LT$2;
}
cs.registerStep(a_hoR5fLJDaWCqEiEZpL2h48LT$3, 'a_hoR5fLJDaWCqEiEZpL2h48LT$3');

function a_hoR5fLJDaWCqEiEZpL2h48LT$2(s) {
  (s.pc = "3.V1");
  var t_call_0 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  if (t_call_0) {
  var t_recOp_1 = t_call_0.perform_get("WTX3n2nWqIYVXj0hFUbVnYwx", s);
  }
  (s.result = t_recOp_1);
  if (s.previous.needsPicker) {
  s.rt.displayResult("r", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_hoR5fLJDaWCqEiEZpL2h48LT$2, 'a_hoR5fLJDaWCqEiEZpL2h48LT$2');

/* ACTION: columns */
function a_BYl1YyPUzY9xO4PIb9WVeywK(previous, returnAddr, $sheet_id) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_BYl1YyPUzY9xO4PIb9WVeywK$0;
  s.name = "columns";
  s.$sheet_id = $sheet_id;
  s.result = undefined;
  return s;
}
cs.registerAction("columns", "BYl1YyPUzY9xO4PIb9WVeywK", a_BYl1YyPUzY9xO4PIb9WVeywK, true);

function a_BYl1YyPUzY9xO4PIb9WVeywK$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_BYl1YyPUzY9xO4PIb9WVeywK$3, lib.RTValue.mkPicker(lib.String_.picker(), "", "sheet id", "$sheet_id"));
  return a_BYl1YyPUzY9xO4PIb9WVeywK$3;
  }
  return a_BYl1YyPUzY9xO4PIb9WVeywK$2;
}
cs.registerStep(a_BYl1YyPUzY9xO4PIb9WVeywK$0, 'a_BYl1YyPUzY9xO4PIb9WVeywK$0');

function a_BYl1YyPUzY9xO4PIb9WVeywK$3(s) {
  return a_BYl1YyPUzY9xO4PIb9WVeywK$2;
}
cs.registerStep(a_BYl1YyPUzY9xO4PIb9WVeywK$3, 'a_BYl1YyPUzY9xO4PIb9WVeywK$3');

function a_BYl1YyPUzY9xO4PIb9WVeywK$2(s) {
  (s.pc = "3.62.1");
  var t_call_0 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  if (t_call_0) {
  var t_recOp_1 = t_call_0.perform_get("V0wVfXUEE41TErckLkYDPlPP", s);
  }
  (s.result = t_recOp_1);
  if (s.previous.needsPicker) {
  s.rt.displayResult("r", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_BYl1YyPUzY9xO4PIb9WVeywK$2, 'a_BYl1YyPUzY9xO4PIb9WVeywK$2');

/* ACTION: evolve */
function a_xXepqqhXptC4XpoSlcIj6822(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xXepqqhXptC4XpoSlcIj6822$0;
  s.name = "evolve";
  s.$dt = undefined;
  s.$sprite = undefined;
  return s;
}
cs.registerAction("evolve", "xXepqqhXptC4XpoSlcIj6822", a_xXepqqhXptC4XpoSlcIj6822, true);

function a_xXepqqhXptC4XpoSlcIj6822$0(s) {
  (s.pc = "3.67.0");
  var t_call_0 = lib.Time.now(s);
  (s.$dt = t_call_0);
  (s.pc = "3.67.3");
  s.t_collArr_1 = (ok1(s, /* _animated sprites */ s.d.$HmpFOp0jnpX9U3gAc1t52p1l) && /* _animated sprites */ s.d.$HmpFOp0jnpX9U3gAc1t52p1l.get_enumerator());
  s.t_idx_2 = 0;
  return a_xXepqqhXptC4XpoSlcIj6822$1;
}
cs.registerStep(a_xXepqqhXptC4XpoSlcIj6822$0, 'a_xXepqqhXptC4XpoSlcIj6822$0');

function a_xXepqqhXptC4XpoSlcIj6822$1(s) {
  if ((s.t_idx_2 < (s.t_collArr_1.length))) {
  (s.$sprite = s.t_collArr_1[(s.t_idx_2)]);
  (s.t_idx_2++);
  if (true) {
  (s.pc = "3.67.80");
  return s.rt.enter(a_j7jARMAVhrGhBgbt5f52sS8v(s, a_xXepqqhXptC4XpoSlcIj6822$4, s.$sprite, s.$dt));
  }
  return a_xXepqqhXptC4XpoSlcIj6822$3;
  }
  return s.rt.leave();
}
cs.registerStep(a_xXepqqhXptC4XpoSlcIj6822$1, 'a_xXepqqhXptC4XpoSlcIj6822$1');

function a_xXepqqhXptC4XpoSlcIj6822$4(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  t_actRes_3;
  return a_xXepqqhXptC4XpoSlcIj6822$3;
}
cs.registerStep(a_xXepqqhXptC4XpoSlcIj6822$4, 'a_xXepqqhXptC4XpoSlcIj6822$4');

function a_xXepqqhXptC4XpoSlcIj6822$3(s) {
  return a_xXepqqhXptC4XpoSlcIj6822$1;
}
cs.registerStep(a_xXepqqhXptC4XpoSlcIj6822$3, 'a_xXepqqhXptC4XpoSlcIj6822$3');


//Ent_BU3ByaXRlIGRlY29yYXRvcgaa
function Ent_BU3ByaXRlIGRlY29yYXRvcgaa(p) {
  this.parent = p;
}
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype = new lib.DecoratorEntry();
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.keys = ["m1MROG42H2bpB0Ho3GNPf6cx"];
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.values = ["PbOsnnXiQWjibwDiWnLIfWar", "xa7N0ZiTjzB0d3bHk0TzRgOU", "mhojY2EAK83g3igfvTb2N8vr", "X7W7PA601Dt7R4W7ENpJLChG", "T8AZDL6rq4ih8v1KDk2Ax7hn", "U3B4QlThh4G22Ug4J0gFI4Wv", "xWcMnRrRoylh2XM1WAbYMpHE", "MIUoRtErSUs8FEps41MfUBo5", "xLagXNlABe3C2KKXrfbnNtdY"];
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.fields = ["m1MROG42H2bpB0Ho3GNPf6cx", "PbOsnnXiQWjibwDiWnLIfWar", "xa7N0ZiTjzB0d3bHk0TzRgOU", "mhojY2EAK83g3igfvTb2N8vr", "X7W7PA601Dt7R4W7ENpJLChG", "T8AZDL6rq4ih8v1KDk2Ax7hn", "U3B4QlThh4G22Ug4J0gFI4Wv", "xWcMnRrRoylh2XM1WAbYMpHE", "MIUoRtErSUs8FEps41MfUBo5", "xLagXNlABe3C2KKXrfbnNtdY"];
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.m1MROG42H2bpB0Ho3GNPf6cx_realname = "target";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.PbOsnnXiQWjibwDiWnLIfWar_realname = "sheet id";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.xa7N0ZiTjzB0d3bHk0TzRgOU_realname = "duration";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.mhojY2EAK83g3igfvTb2N8vr_realname = "start time";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.X7W7PA601Dt7R4W7ENpJLChG_realname = "loops";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.T8AZDL6rq4ih8v1KDk2Ax7hn_realname = "auto delete";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.U3B4QlThh4G22Ug4J0gFI4Wv_realname = "start row";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.xWcMnRrRoylh2XM1WAbYMpHE_realname = "end row";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.MIUoRtErSUs8FEps41MfUBo5_realname = "start column";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.xLagXNlABe3C2KKXrfbnNtdY_realname = "end column";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.PbOsnnXiQWjibwDiWnLIfWar = "";
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.xa7N0ZiTjzB0d3bHk0TzRgOU = 0;
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.mhojY2EAK83g3igfvTb2N8vr = lib.DateTime.defaultValue;
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.X7W7PA601Dt7R4W7ENpJLChG = 0;
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.T8AZDL6rq4ih8v1KDk2Ax7hn = false;
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.U3B4QlThh4G22Ug4J0gFI4Wv = 0;
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.xWcMnRrRoylh2XM1WAbYMpHE = 0;
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.MIUoRtErSUs8FEps41MfUBo5 = 0;
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.xLagXNlABe3C2KKXrfbnNtdY = 0;
//Col_BU3ByaXRlIGRlY29yYXRvcgaa
//Tbl_BU3ByaXRlIGRlY29yYXRvcgaa
function Tbl_BU3ByaXRlIGRlY29yYXRvcgaa(l) {
  this.libName = l;
  this.initParent();
}
Tbl_BU3ByaXRlIGRlY29yYXRvcgaa.prototype = new lib.DecoratorSingleton();
Tbl_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.entryCtor = Ent_BU3ByaXRlIGRlY29yYXRvcgaa;
Tbl_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.selfCtor = Tbl_BU3ByaXRlIGRlY29yYXRvcgaa;
Tbl_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.stableName = "BU3ByaXRlIGRlY29yYXRvcgaa";
Tbl_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.entryKindName = "animation";

// jsonimport
Ent_BU3ByaXRlIGRlY29yYXRvcgaa.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("PbOsnnXiQWjibwDiWnLIfWar", ctx.importString(json, "sheet id"), s);
  this.perform_set("xa7N0ZiTjzB0d3bHk0TzRgOU", ctx.importNumber(json, "duration"), s);
  this.perform_set("mhojY2EAK83g3igfvTb2N8vr", ctx.importDateTime(json, "start time"), s);
  this.perform_set("X7W7PA601Dt7R4W7ENpJLChG", ctx.importNumber(json, "loops"), s);
  this.perform_set("T8AZDL6rq4ih8v1KDk2Ax7hn", ctx.importBoolean(json, "auto delete"), s);
  this.perform_set("U3B4QlThh4G22Ug4J0gFI4Wv", ctx.importNumber(json, "start row"), s);
  this.perform_set("xWcMnRrRoylh2XM1WAbYMpHE", ctx.importNumber(json, "end row"), s);
  this.perform_set("MIUoRtErSUs8FEps41MfUBo5", ctx.importNumber(json, "start column"), s);
  this.perform_set("xLagXNlABe3C2KKXrfbnNtdY", ctx.importNumber(json, "end column"), s);
}
cs.registerGlobal("$BU3ByaXRlIGRlY29yYXRvcgaa");
/* ACTION: clear animation */
function a_t9iHv2TMDpiGNBMaHesDuYn5(previous, returnAddr, $sprite) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_t9iHv2TMDpiGNBMaHesDuYn5$0;
  s.name = "clear animation";
  s.$sprite = $sprite;
  return s;
}
cs.registerAction("clear animation", "t9iHv2TMDpiGNBMaHesDuYn5", a_t9iHv2TMDpiGNBMaHesDuYn5, true);

function a_t9iHv2TMDpiGNBMaHesDuYn5$0(s) {
  (s.pc = "3.73.1");
  var t_call_0 = (ok2(s, /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa, s.$sprite) && /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa.at(s.$sprite, s));
  s.rt.logObjectMutation(t_call_0);
  (ok1(s, t_call_0) && t_call_0.clear_fields(s));
  return s.rt.leave();
}
cs.registerStep(a_t9iHv2TMDpiGNBMaHesDuYn5$0, 'a_t9iHv2TMDpiGNBMaHesDuYn5$0');

/* ACTION: set animation */
function a_Wm3TTqWIBbOrHYYz43aQL8oz(previous, returnAddr, $sheet_id, $sprite, $duration, $loops, $auto_delete, $start_row, $start_column, $end_row, $end_column) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Wm3TTqWIBbOrHYYz43aQL8oz$0;
  s.name = "set animation";
  s.$sheet_id = $sheet_id;
  s.$sprite = $sprite;
  s.$duration = $duration;
  s.$loops = $loops;
  s.$auto_delete = $auto_delete;
  s.$start_row = $start_row;
  s.$start_column = $start_column;
  s.$end_row = $end_row;
  s.$end_column = $end_column;
  s.$sheet = undefined;
  s.$animation = undefined;
  return s;
}
cs.registerAction("set animation", "Wm3TTqWIBbOrHYYz43aQL8oz", a_Wm3TTqWIBbOrHYYz43aQL8oz, true);

function a_Wm3TTqWIBbOrHYYz43aQL8oz$0(s) {
  (s.pc = "3.79.1");
  var t_infix_0 = (ok1(s, s.$start_row) && (s.$start_row >= 1));
  (ok1(s, t_infix_0) && lib.Contract.requires(t_infix_0, "\u0060start row\u0060 must be greater or equal to 1", s));
  (s.pc = "3.79.4");
  var t_infix_1 = (ok1(s, s.$start_column) && (s.$start_column >= 1));
  (ok1(s, t_infix_1) && lib.Contract.requires(t_infix_1, "\u0060start column\u0060 must be greater or equal to 1", s));
  (s.pc = "3.79.7");
  var t_call_2 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  (s.$sheet = t_call_2);
  (s.pc = "3.79.a");
  var t_infix_3 = (ok1(s, s.$start_row) && (s.$start_row - 1));
  var t_call_4 = (ok1(s, t_infix_3) && lib.Math_.max(0, t_infix_3, s));
  (s.$start_row = t_call_4);
  (s.pc = "3.79.d");
  if (s.$sheet) {
  var t_recOp_5 = s.$sheet.perform_get("WTX3n2nWqIYVXj0hFUbVnYwx", s);
  }
  var t_call_6 = (ok2(s, t_recOp_5, s.$end_row) && lib.Math_.min(t_recOp_5, s.$end_row, s));
  (s.$end_row = t_call_6);
  (s.pc = "3.79.g");
  var t_infix_7 = (ok1(s, s.$start_column) && (s.$start_column - 1));
  var t_call_8 = (ok1(s, t_infix_7) && lib.Math_.max(0, t_infix_7, s));
  (s.$start_column = t_call_8);
  (s.pc = "3.79.j");
  if (s.$sheet) {
  var t_recOp_9 = s.$sheet.perform_get("V0wVfXUEE41TErckLkYDPlPP", s);
  }
  var t_call_10 = (ok2(s, t_recOp_9, s.$end_column) && lib.Math_.min(t_recOp_9, s.$end_column, s));
  (s.$end_column = t_call_10);
  var t_elseIf_11 = true;
  (s.pc = "3.79.m");
  var t_infix_12 = (ok1(s, s.$duration) && (s.$duration > 0));
  var t_lazy_13 = t_infix_12;
  if ((ok1(s, t_lazy_13) && t_lazy_13)) {
  var t_infix_14 = (ok2(s, s.$start_row, s.$end_row) && (s.$start_row <= s.$end_row));
  (t_lazy_13 = t_infix_14);
  }
  var t_lazy_15 = t_lazy_13;
  if ((ok1(s, t_lazy_15) && t_lazy_15)) {
  var t_infix_16 = (ok2(s, s.$start_column, s.$end_column) && (s.$start_column <= s.$end_column));
  (t_lazy_15 = t_infix_16);
  }
  var t_lazy_17 = t_lazy_15;
  if ((ok1(s, t_lazy_17) && t_lazy_17)) {
  var t_infix_18 = (ok1(s, s.$loops) && (s.$loops !== 0));
  (t_lazy_17 = t_infix_18);
  }
  ok1(s, t_lazy_17);
  if (t_lazy_17) {
  (s.pc = "3.79.q0");
  s.rt.logObjectMutation(/* _animated sprites */ s.d.$HmpFOp0jnpX9U3gAc1t52p1l);
  var t_call_19 = (ok2(s, /* _animated sprites */ s.d.$HmpFOp0jnpX9U3gAc1t52p1l, s.$sprite) && /* _animated sprites */ s.d.$HmpFOp0jnpX9U3gAc1t52p1l.add(s.$sprite, s));
  t_call_19;
  (s.pc = "3.79.q3");
  var t_call_20 = (ok2(s, /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa, s.$sprite) && /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa.at(s.$sprite, s));
  (s.$animation = t_call_20);
  (s.pc = "3.79.q6");
  if (s.$animation) {
  s.$animation.perform_set("PbOsnnXiQWjibwDiWnLIfWar", s.$sheet_id, s);
  }
  (s.pc = "3.79.q9");
  if (s.$animation) {
  s.$animation.perform_set("xa7N0ZiTjzB0d3bHk0TzRgOU", s.$duration, s);
  }
  (s.pc = "3.79.qc");
  var t_call_21 = lib.Time.now(s);
  if (s.$animation) {
  s.$animation.perform_set("mhojY2EAK83g3igfvTb2N8vr", t_call_21, s);
  }
  (s.pc = "3.79.qf");
  if (s.$animation) {
  s.$animation.perform_set("X7W7PA601Dt7R4W7ENpJLChG", s.$loops, s);
  }
  (s.pc = "3.79.qi");
  if (s.$animation) {
  s.$animation.perform_set("T8AZDL6rq4ih8v1KDk2Ax7hn", s.$auto_delete, s);
  }
  (s.pc = "3.79.ql");
  if (s.$animation) {
  s.$animation.perform_set("U3B4QlThh4G22Ug4J0gFI4Wv", s.$start_row, s);
  }
  (s.pc = "3.79.qo");
  if (s.$animation) {
  s.$animation.perform_set("xWcMnRrRoylh2XM1WAbYMpHE", s.$end_row, s);
  }
  (s.pc = "3.79.qr");
  if (s.$animation) {
  s.$animation.perform_set("MIUoRtErSUs8FEps41MfUBo5", s.$start_column, s);
  }
  (s.pc = "3.79.qu");
  if (s.$animation) {
  s.$animation.perform_set("xLagXNlABe3C2KKXrfbnNtdY", s.$end_column, s);
  }
  } else {
  (s.pc = "3.79.r0");
  null;
  }
  (s.pc = "3.79.r");
  return s.rt.enter(a_xXepqqhXptC4XpoSlcIj6822(s, a_Wm3TTqWIBbOrHYYz43aQL8oz$16));
}
cs.registerStep(a_Wm3TTqWIBbOrHYYz43aQL8oz$0, 'a_Wm3TTqWIBbOrHYYz43aQL8oz$0');

function a_Wm3TTqWIBbOrHYYz43aQL8oz$16(s) {
  var t_actRes_22 = s.rt.returnedFrom.result;
  t_actRes_22;
  return s.rt.leave();
}
cs.registerStep(a_Wm3TTqWIBbOrHYYz43aQL8oz$16, 'a_Wm3TTqWIBbOrHYYz43aQL8oz$16');

/* ACTION: evolve sprite */
function a_j7jARMAVhrGhBgbt5f52sS8v(previous, returnAddr, $sprite, $current_time) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_j7jARMAVhrGhBgbt5f52sS8v$0;
  s.name = "evolve sprite";
  s.$sprite = $sprite;
  s.$current_time = $current_time;
  s.$animation = undefined;
  s.$elapsed = undefined;
  s.$duration = undefined;
  s.$current_loops = undefined;
  s.$loops = undefined;
  s.$sr = undefined;
  s.$sc = undefined;
  s.$er = undefined;
  s.$ec = undefined;
  s.$dc = undefined;
  s.$dr = undefined;
  s.$steps = undefined;
  s.$x = undefined;
  s.$step_index = undefined;
  s.$r = undefined;
  s.$c = undefined;
  return s;
}
cs.registerAction("evolve sprite", "j7jARMAVhrGhBgbt5f52sS8v", a_j7jARMAVhrGhBgbt5f52sS8v, true);

function a_j7jARMAVhrGhBgbt5f52sS8v$0(s) {
  (s.pc = "3.84.0");
  var t_call_0 = (ok2(s, /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa, s.$sprite) && /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa.at(s.$sprite, s));
  (s.$animation = t_call_0);
  var t_elseIf_1 = true;
  (s.pc = "3.84.3");
  var t_call_2 = (ok1(s, s.$sprite) && s.$sprite.is_deleted(s));
  ok1(s, t_call_2);
  if (t_call_2) {
  (s.pc = "3.84.70");
  s.rt.logObjectMutation(s.$animation);
  (ok1(s, s.$animation) && s.$animation.clear_fields(s));
  (s.pc = "3.84.73");
  s.rt.logObjectMutation(/* _animated sprites */ s.d.$HmpFOp0jnpX9U3gAc1t52p1l);
  var t_call_3 = (ok2(s, /* _animated sprites */ s.d.$HmpFOp0jnpX9U3gAc1t52p1l, s.$sprite) && /* _animated sprites */ s.d.$HmpFOp0jnpX9U3gAc1t52p1l.remove(s.$sprite, s));
  t_call_3;
  } else {
  (s.pc = "3.84.80");
  if (s.$animation) {
  var t_recOp_4 = s.$animation.perform_get("mhojY2EAK83g3igfvTb2N8vr", s);
  }
  var t_call_5 = (ok2(s, s.$current_time, t_recOp_4) && s.$current_time.subtract(t_recOp_4, s));
  (s.$elapsed = t_call_5);
  (s.pc = "3.84.83");
  if (s.$animation) {
  var t_recOp_6 = s.$animation.perform_get("xa7N0ZiTjzB0d3bHk0TzRgOU", s);
  }
  (s.$duration = t_recOp_6);
  (s.pc = "3.84.86");
  var t_infix_7 = (ok2(s, s.$elapsed, s.$duration) && (s.$elapsed / s.$duration));
  (s.$current_loops = t_infix_7);
  (s.pc = "3.84.89");
  if (s.$animation) {
  var t_recOp_8 = s.$animation.perform_get("X7W7PA601Dt7R4W7ENpJLChG", s);
  }
  (s.$loops = t_recOp_8);
  var t_elseIf_9 = true;
  (s.pc = "3.84.8c");
  var t_infix_10 = (ok1(s, s.$loops) && (s.$loops > 0));
  var t_lazy_11 = t_infix_10;
  if ((ok1(s, t_lazy_11) && t_lazy_11)) {
  var t_infix_12 = (ok2(s, s.$current_loops, s.$loops) && (s.$current_loops > s.$loops));
  (t_lazy_11 = t_infix_12);
  }
  ok1(s, t_lazy_11);
  if (t_lazy_11) {
  (s.pc = "3.84.8g0");
  return s.rt.enter(a_t9iHv2TMDpiGNBMaHesDuYn5(s, a_j7jARMAVhrGhBgbt5f52sS8v$7, s.$sprite));
  } else {
  (s.pc = "3.84.8h0");
  if (s.$animation) {
  var t_recOp_14 = s.$animation.perform_get("U3B4QlThh4G22Ug4J0gFI4Wv", s);
  }
  (s.$sr = t_recOp_14);
  (s.pc = "3.84.8h3");
  if (s.$animation) {
  var t_recOp_15 = s.$animation.perform_get("MIUoRtErSUs8FEps41MfUBo5", s);
  }
  (s.$sc = t_recOp_15);
  (s.pc = "3.84.8h6");
  if (s.$animation) {
  var t_recOp_16 = s.$animation.perform_get("xWcMnRrRoylh2XM1WAbYMpHE", s);
  }
  (s.$er = t_recOp_16);
  (s.pc = "3.84.8h9");
  if (s.$animation) {
  var t_recOp_17 = s.$animation.perform_get("xLagXNlABe3C2KKXrfbnNtdY", s);
  }
  (s.$ec = t_recOp_17);
  (s.pc = "3.84.8hc");
  var t_infix_18 = (ok2(s, s.$ec, s.$sc) && (s.$ec - s.$sc));
  (s.$dc = t_infix_18);
  (s.pc = "3.84.8hf");
  var t_infix_19 = (ok2(s, s.$er, s.$sr) && (s.$er - s.$sr));
  (s.$dr = t_infix_19);
  (s.pc = "3.84.8hi");
  var t_infix_20 = (ok2(s, s.$dc, s.$dr) && (s.$dc * s.$dr));
  (s.$steps = t_infix_20);
  (s.pc = "3.84.8hl");
  var t_call_21 = (ok2(s, s.$elapsed, s.$duration) && lib.Math_.mod(s.$elapsed, s.$duration, s));
  (s.$x = t_call_21);
  (s.pc = "3.84.8ho");
  var t_infix_22 = (ok2(s, s.$x, s.$duration) && (s.$x / s.$duration));
  var t_infix_23 = (ok2(s, t_infix_22, s.$steps) && (t_infix_22 * s.$steps));
  var t_call_24 = (ok1(s, t_infix_23) && lib.Math_.floor(t_infix_23, s));
  (s.$step_index = t_call_24);
  (s.pc = "3.84.8hr");
  var t_infix_25 = (ok2(s, s.$step_index, s.$dc) && (s.$step_index / s.$dc));
  var t_call_26 = (ok1(s, t_infix_25) && lib.Math_.floor(t_infix_25, s));
  var t_infix_27 = (ok2(s, s.$sr, t_call_26) && (s.$sr + t_call_26));
  var t_infix_28 = (ok1(s, t_infix_27) && (t_infix_27 + 1));
  (s.$r = t_infix_28);
  (s.pc = "3.84.8hu");
  var t_call_29 = (ok2(s, s.$step_index, s.$dc) && lib.Math_.mod(s.$step_index, s.$dc, s));
  var t_infix_30 = (ok2(s, s.$sc, t_call_29) && (s.$sc + t_call_29));
  var t_infix_31 = (ok1(s, t_infix_30) && (t_infix_30 + 1));
  (s.$c = t_infix_31);
  (s.pc = "3.84.8hx");
  var t_concat_32 = lib.String_.concatAny(s.$current_time, "\u002c ");
  var t_concat_33 = lib.String_.concatAny(t_concat_32, s.$x);
  var t_concat_34 = lib.String_.concatAny(t_concat_33, "\u002c ");
  var t_concat_35 = lib.String_.concatAny(t_concat_34, s.$step_index);
  var t_concat_36 = lib.String_.concatAny(t_concat_35, "\u002c ");
  var t_concat_37 = lib.String_.concatAny(t_concat_36, s.$r);
  var t_concat_38 = lib.String_.concatAny(t_concat_37, "\u002c ");
  var t_concat_39 = lib.String_.concatAny(t_concat_38, s.$c);
  (ok1(s, t_concat_39) && lib.Time.log(t_concat_39, s));
  (s.pc = "3.84.8hA");
  if (s.$animation) {
  var t_recOp_40 = s.$animation.perform_get("PbOsnnXiQWjibwDiWnLIfWar", s);
  }
  return s.rt.enter(a_fa9qr7Vx9rfVuZ5EUvuxBKc2(s, a_j7jARMAVhrGhBgbt5f52sS8v$13, t_recOp_40, s.$sprite, s.$r, s.$c));
  }
  return a_j7jARMAVhrGhBgbt5f52sS8v$6;
  }
  return a_j7jARMAVhrGhBgbt5f52sS8v$1;
}
cs.registerStep(a_j7jARMAVhrGhBgbt5f52sS8v$0, 'a_j7jARMAVhrGhBgbt5f52sS8v$0');

function a_j7jARMAVhrGhBgbt5f52sS8v$7(s) {
  var t_actRes_13 = s.rt.returnedFrom.result;
  t_actRes_13;
  (s.pc = "3.84.8g3");
  s.rt.logObjectMutation(s.$sprite);
  (ok1(s, s.$sprite) && s.$sprite.delete_(s));
  return a_j7jARMAVhrGhBgbt5f52sS8v$6;
}
cs.registerStep(a_j7jARMAVhrGhBgbt5f52sS8v$7, 'a_j7jARMAVhrGhBgbt5f52sS8v$7');

function a_j7jARMAVhrGhBgbt5f52sS8v$13(s) {
  var t_actRes_41 = s.rt.returnedFrom.result;
  t_actRes_41;
  return a_j7jARMAVhrGhBgbt5f52sS8v$6;
}
cs.registerStep(a_j7jARMAVhrGhBgbt5f52sS8v$13, 'a_j7jARMAVhrGhBgbt5f52sS8v$13');

function a_j7jARMAVhrGhBgbt5f52sS8v$6(s) {
  return a_j7jARMAVhrGhBgbt5f52sS8v$1;
}
cs.registerStep(a_j7jARMAVhrGhBgbt5f52sS8v$6, 'a_j7jARMAVhrGhBgbt5f52sS8v$6');

function a_j7jARMAVhrGhBgbt5f52sS8v$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_j7jARMAVhrGhBgbt5f52sS8v$1, 'a_j7jARMAVhrGhBgbt5f52sS8v$1');


//Ent_Bc2hlZXQgaW5kZXga
function Ent_Bc2hlZXQgaW5kZXga(p) {
  this.parent = p;
}
Ent_Bc2hlZXQgaW5kZXga.prototype = new lib.IndexEntry();
Ent_Bc2hlZXQgaW5kZXga.prototype.keys = ["WgI848xsgpkLNZwycPN22ptE"];
Ent_Bc2hlZXQgaW5kZXga.prototype.values = ["qIAd2BInjEq6edaHJblgGXLR", "WTX3n2nWqIYVXj0hFUbVnYwx", "V0wVfXUEE41TErckLkYDPlPP", "BZY9s61lmNNxBW31EfVNb4vl", "rlBRdLfNyC8etUZ7YFUMLIvQ", "xk1X2K46Gohe2a2nULBivsfe", "xPbwdlEz1e26Rg2gTnjl4r4L", "cZgN30Klau1iSnUzQQXVt0nw", "lmz3Kh04x9Vn35VFJEHm1Mir"];
Ent_Bc2hlZXQgaW5kZXga.prototype.fields = ["WgI848xsgpkLNZwycPN22ptE", "qIAd2BInjEq6edaHJblgGXLR", "WTX3n2nWqIYVXj0hFUbVnYwx", "V0wVfXUEE41TErckLkYDPlPP", "BZY9s61lmNNxBW31EfVNb4vl", "rlBRdLfNyC8etUZ7YFUMLIvQ", "xk1X2K46Gohe2a2nULBivsfe", "xPbwdlEz1e26Rg2gTnjl4r4L", "cZgN30Klau1iSnUzQQXVt0nw", "lmz3Kh04x9Vn35VFJEHm1Mir"];
Ent_Bc2hlZXQgaW5kZXga.prototype.WgI848xsgpkLNZwycPN22ptE_realname = "id";
Ent_Bc2hlZXQgaW5kZXga.prototype.qIAd2BInjEq6edaHJblgGXLR_realname = "pic";
Ent_Bc2hlZXQgaW5kZXga.prototype.WTX3n2nWqIYVXj0hFUbVnYwx_realname = "rows";
Ent_Bc2hlZXQgaW5kZXga.prototype.V0wVfXUEE41TErckLkYDPlPP_realname = "columns";
Ent_Bc2hlZXQgaW5kZXga.prototype.BZY9s61lmNNxBW31EfVNb4vl_realname = "left";
Ent_Bc2hlZXQgaW5kZXga.prototype.rlBRdLfNyC8etUZ7YFUMLIvQ_realname = "top";
Ent_Bc2hlZXQgaW5kZXga.prototype.xk1X2K46Gohe2a2nULBivsfe_realname = "row gap";
Ent_Bc2hlZXQgaW5kZXga.prototype.xPbwdlEz1e26Rg2gTnjl4r4L_realname = "column gap";
Ent_Bc2hlZXQgaW5kZXga.prototype.cZgN30Klau1iSnUzQQXVt0nw_realname = "column width";
Ent_Bc2hlZXQgaW5kZXga.prototype.lmz3Kh04x9Vn35VFJEHm1Mir_realname = "row height";
Ent_Bc2hlZXQgaW5kZXga.prototype.WTX3n2nWqIYVXj0hFUbVnYwx = 0;
Ent_Bc2hlZXQgaW5kZXga.prototype.V0wVfXUEE41TErckLkYDPlPP = 0;
Ent_Bc2hlZXQgaW5kZXga.prototype.BZY9s61lmNNxBW31EfVNb4vl = 0;
Ent_Bc2hlZXQgaW5kZXga.prototype.rlBRdLfNyC8etUZ7YFUMLIvQ = 0;
Ent_Bc2hlZXQgaW5kZXga.prototype.xk1X2K46Gohe2a2nULBivsfe = 0;
Ent_Bc2hlZXQgaW5kZXga.prototype.xPbwdlEz1e26Rg2gTnjl4r4L = 0;
Ent_Bc2hlZXQgaW5kZXga.prototype.cZgN30Klau1iSnUzQQXVt0nw = 0;
Ent_Bc2hlZXQgaW5kZXga.prototype.lmz3Kh04x9Vn35VFJEHm1Mir = 0;
//Col_Bc2hlZXQgaW5kZXga
function Col_Bc2hlZXQgaW5kZXga(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_Bc2hlZXQgaW5kZXga.prototype = lib.RecordCollection.prototype;
//Tbl_Bc2hlZXQgaW5kZXga
function Tbl_Bc2hlZXQgaW5kZXga(l) {
  this.libName = l;
  this.initParent();
}
Tbl_Bc2hlZXQgaW5kZXga.prototype = new lib.IndexSingleton();
Tbl_Bc2hlZXQgaW5kZXga.prototype.entryCtor = Ent_Bc2hlZXQgaW5kZXga;
Tbl_Bc2hlZXQgaW5kZXga.prototype.selfCtor = Tbl_Bc2hlZXQgaW5kZXga;
Tbl_Bc2hlZXQgaW5kZXga.prototype.collectionCtor = Col_Bc2hlZXQgaW5kZXga;
Tbl_Bc2hlZXQgaW5kZXga.prototype.stableName = "Bc2hlZXQgaW5kZXga";
Tbl_Bc2hlZXQgaW5kZXga.prototype.entryKindName = "sheet";

// jsonimport
Tbl_Bc2hlZXQgaW5kZXga.prototype.importJsonKeys = function (ctx, json) {
  var s = ctx.s;
  var a = [];
  a.push(ctx.importString(json, "id"));
  return a;
}
Ent_Bc2hlZXQgaW5kZXga.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("WTX3n2nWqIYVXj0hFUbVnYwx", ctx.importNumber(json, "rows"), s);
  this.perform_set("V0wVfXUEE41TErckLkYDPlPP", ctx.importNumber(json, "columns"), s);
  this.perform_set("BZY9s61lmNNxBW31EfVNb4vl", ctx.importNumber(json, "left"), s);
  this.perform_set("rlBRdLfNyC8etUZ7YFUMLIvQ", ctx.importNumber(json, "top"), s);
  this.perform_set("xk1X2K46Gohe2a2nULBivsfe", ctx.importNumber(json, "row gap"), s);
  this.perform_set("xPbwdlEz1e26Rg2gTnjl4r4L", ctx.importNumber(json, "column gap"), s);
  this.perform_set("cZgN30Klau1iSnUzQQXVt0nw", ctx.importNumber(json, "column width"), s);
  this.perform_set("lmz3Kh04x9Vn35VFJEHm1Mir", ctx.importNumber(json, "row height"), s);
}
cs.registerGlobal("$Bc2hlZXQgaW5kZXga");
/* ACTION: set sheet */
function a_PHYFRyCfW0KmUyV6uk97VWId(previous, returnAddr, $sheet_id, $pic, $rows, $columns) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_PHYFRyCfW0KmUyV6uk97VWId$0;
  s.name = "set sheet";
  s.$sheet_id = $sheet_id;
  s.$pic = $pic;
  s.$rows = $rows;
  s.$columns = $columns;
  s.$s = undefined;
  return s;
}
cs.registerAction("set sheet", "PHYFRyCfW0KmUyV6uk97VWId", a_PHYFRyCfW0KmUyV6uk97VWId, true);

function a_PHYFRyCfW0KmUyV6uk97VWId$0(s) {
  (s.pc = "3.90.1");
  var t_call_0 = (ok1(s, s.$sheet_id) && lib.String_.is_empty(s.$sheet_id, s));
  var t_call_1 = (ok1(s, t_call_0) && lib.Boolean_.not(t_call_0, s));
  (ok1(s, t_call_1) && lib.Contract.requires(t_call_1, "\u0060sheet id\u0060 must be non-empty", s));
  (s.pc = "3.90.4");
  var t_infix_2 = (ok1(s, s.$rows) && (s.$rows > 0));
  (ok1(s, t_infix_2) && lib.Contract.requires(t_infix_2, "\u0060rows\u0060 must be positive", s));
  (s.pc = "3.90.7");
  var t_infix_3 = (ok1(s, s.$columns) && (s.$columns > 0));
  (ok1(s, t_infix_3) && lib.Contract.requires(t_infix_3, "\u0060columns\u0060 must be positive", s));
  (s.pc = "3.90.a");
  var t_call_4 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  (s.$s = t_call_4);
  (s.pc = "3.90.d");
  if (s.$s) {
  s.$s.perform_set("qIAd2BInjEq6edaHJblgGXLR", s.$pic, s);
  }
  (s.pc = "3.90.g");
  if (s.$s) {
  s.$s.perform_set("WTX3n2nWqIYVXj0hFUbVnYwx", s.$rows, s);
  }
  (s.pc = "3.90.j");
  if (s.$s) {
  s.$s.perform_set("V0wVfXUEE41TErckLkYDPlPP", s.$columns, s);
  }
  (s.pc = "3.90.m");
  return s.rt.enter(a_rv4uTbsBkglHdyoc2ekrt3Wb(s, a_PHYFRyCfW0KmUyV6uk97VWId$4, s.$s));
}
cs.registerStep(a_PHYFRyCfW0KmUyV6uk97VWId$0, 'a_PHYFRyCfW0KmUyV6uk97VWId$0');

function a_PHYFRyCfW0KmUyV6uk97VWId$4(s) {
  var t_actRes_5 = s.rt.returnedFrom.result;
  t_actRes_5;
  return s.rt.leave();
}
cs.registerStep(a_PHYFRyCfW0KmUyV6uk97VWId$4, 'a_PHYFRyCfW0KmUyV6uk97VWId$4');

/* ACTION: set sprite clip */
function a_x8elMgRejELmY0t80h770i2v(previous, returnAddr, $sheet, $sprite, $column_index, $row_index) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_x8elMgRejELmY0t80h770i2v$0;
  s.name = "set sprite clip";
  s.$sheet = $sheet;
  s.$sprite = $sprite;
  s.$column_index = $column_index;
  s.$row_index = $row_index;
  s.$left = undefined;
  s.$top = undefined;
  return s;
}
cs.registerAction("set sprite clip", "x8elMgRejELmY0t80h770i2v", a_x8elMgRejELmY0t80h770i2v, true);

function a_x8elMgRejELmY0t80h770i2v$0(s) {
  (s.pc = "3.95.1");
  var t_call_0 = (ok2(s, /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa, s.$sprite) && /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa.at(s.$sprite, s));
  if (t_call_0) {
  t_call_0.perform_set("PbOsnnXiQWjibwDiWnLIfWar", (ok1(s, s.$sheet) && s.$sheet[("WgI848xsgpkLNZwycPN22ptE")]), s);
  }
  (s.pc = "3.95.4");
  if (s.$sheet) {
  var t_recOp_1 = s.$sheet.perform_get("qIAd2BInjEq6edaHJblgGXLR", s);
  }
  s.rt.logObjectMutation(s.$sprite);
  var t_resumeCtx_2 = s.rt.getBlockingResumeCtx(a_x8elMgRejELmY0t80h770i2v$3);
  (ok2(s, s.$sprite, t_recOp_1) && s.$sprite.set_picture(t_recOp_1, t_resumeCtx_2));
  return a_x8elMgRejELmY0t80h770i2v$3;
}
cs.registerStep(a_x8elMgRejELmY0t80h770i2v$0, 'a_x8elMgRejELmY0t80h770i2v$0');

function a_x8elMgRejELmY0t80h770i2v$3(s) {
  (s.pc = "3.95.7");
  return s.rt.enter(a_U8KRwHyZDdEZoJfsT4VEXNsS(s, a_x8elMgRejELmY0t80h770i2v$4, s.$sheet, s.$column_index));
}
cs.registerStep(a_x8elMgRejELmY0t80h770i2v$3, 'a_x8elMgRejELmY0t80h770i2v$3');

function a_x8elMgRejELmY0t80h770i2v$4(s) {
  var t_actRes_3 = s.rt.returnedFrom.result;
  (s.$left = t_actRes_3);
  (s.pc = "3.95.a");
  return s.rt.enter(a_KPGb82K0RKe3jhJRDhMtq17X(s, a_x8elMgRejELmY0t80h770i2v$5, s.$sheet, s.$row_index));
}
cs.registerStep(a_x8elMgRejELmY0t80h770i2v$4, 'a_x8elMgRejELmY0t80h770i2v$4');

function a_x8elMgRejELmY0t80h770i2v$5(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  (s.$top = t_actRes_4);
  (s.pc = "3.95.d");
  if (s.$sheet) {
  var t_recOp_5 = s.$sheet.perform_get("cZgN30Klau1iSnUzQQXVt0nw", s);
  }
  if (s.$sheet) {
  var t_recOp_6 = s.$sheet.perform_get("lmz3Kh04x9Vn35VFJEHm1Mir", s);
  }
  s.rt.logObjectMutation(s.$sprite);
  (ok5(s, s.$sprite, s.$left, s.$top, t_recOp_5, t_recOp_6) && s.$sprite.set_clip(s.$left, s.$top, t_recOp_5, t_recOp_6, s));
  return s.rt.leave();
}
cs.registerStep(a_x8elMgRejELmY0t80h770i2v$5, 'a_x8elMgRejELmY0t80h770i2v$5');

/* ACTION: create animation */
function a_g0e2F0y8lMxbuhCC6w5hSJ9a(previous, returnAddr, $sheet_id, $duration, $loops, $start_row, $start_column, $end_row, $end_column) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_g0e2F0y8lMxbuhCC6w5hSJ9a$0;
  s.name = "create animation";
  s.$sheet_id = $sheet_id;
  s.$duration = $duration;
  s.$loops = $loops;
  s.$start_row = $start_row;
  s.$start_column = $start_column;
  s.$end_row = $end_row;
  s.$end_column = $end_column;
  s.result = undefined;
  s.$sheet = undefined;
  return s;
}
cs.registerAction("create animation", "g0e2F0y8lMxbuhCC6w5hSJ9a", a_g0e2F0y8lMxbuhCC6w5hSJ9a, true);

function a_g0e2F0y8lMxbuhCC6w5hSJ9a$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_g0e2F0y8lMxbuhCC6w5hSJ9a$5, lib.RTValue.mkPicker(lib.String_.picker(), "", "sheet id", "$sheet_id"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "duration", "$duration"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "loops", "$loops"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "start row", "$start_row"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "start column", "$start_column"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "end row", "$end_row"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "end column", "$end_column"));
  return a_g0e2F0y8lMxbuhCC6w5hSJ9a$5;
  }
  return a_g0e2F0y8lMxbuhCC6w5hSJ9a$4;
}
cs.registerStep(a_g0e2F0y8lMxbuhCC6w5hSJ9a$0, 'a_g0e2F0y8lMxbuhCC6w5hSJ9a$0');

function a_g0e2F0y8lMxbuhCC6w5hSJ9a$5(s) {
  return a_g0e2F0y8lMxbuhCC6w5hSJ9a$4;
}
cs.registerStep(a_g0e2F0y8lMxbuhCC6w5hSJ9a$5, 'a_g0e2F0y8lMxbuhCC6w5hSJ9a$5');

function a_g0e2F0y8lMxbuhCC6w5hSJ9a$4(s) {
  (s.pc = "3.100.1");
  var t_call_0 = (ok2(s, /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga, s.$sheet_id) && /* sheet index */ s.d.$Bc2hlZXQgaW5kZXga.at(s.$sheet_id, s));
  (s.$sheet = t_call_0);
  (s.pc = "3.100.4");
  if (s.$sheet) {
  var t_recOp_1 = s.$sheet.perform_get("qIAd2BInjEq6edaHJblgGXLR", s);
  }
  var t_resumeCtx_2 = s.rt.getBlockingResumeCtx(a_g0e2F0y8lMxbuhCC6w5hSJ9a$2);
  var t_call_3 = (ok2(s, /* board */ s.d.$ttDB4Z14tS2D49H96olVfxPC, t_recOp_1) && /* board */ s.d.$ttDB4Z14tS2D49H96olVfxPC.create_picture(t_recOp_1, t_resumeCtx_2));
  return a_g0e2F0y8lMxbuhCC6w5hSJ9a$2;
}
cs.registerStep(a_g0e2F0y8lMxbuhCC6w5hSJ9a$4, 'a_g0e2F0y8lMxbuhCC6w5hSJ9a$4');

function a_g0e2F0y8lMxbuhCC6w5hSJ9a$2(s) {
  var t_pauseRes_4 = s.pauseValue;
  s.rt.markAllocated(t_pauseRes_4);
  (s.result = t_pauseRes_4);
  (s.pc = "3.100.7");
  return s.rt.enter(a_Wm3TTqWIBbOrHYYz43aQL8oz(s, a_g0e2F0y8lMxbuhCC6w5hSJ9a$3, s.$sheet_id, s.result, s.$duration, s.$loops, true, s.$start_row, s.$start_column, s.$end_row, s.$end_column));
}
cs.registerStep(a_g0e2F0y8lMxbuhCC6w5hSJ9a$2, 'a_g0e2F0y8lMxbuhCC6w5hSJ9a$2');

function a_g0e2F0y8lMxbuhCC6w5hSJ9a$3(s) {
  var t_actRes_5 = s.rt.returnedFrom.result;
  t_actRes_5;
  if (s.previous.needsPicker) {
  s.rt.displayResult("sprite", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_g0e2F0y8lMxbuhCC6w5hSJ9a$3, 'a_g0e2F0y8lMxbuhCC6w5hSJ9a$3');

/* ACTION: is animated */
function a_Gk0qYhq6br8nL1O07mtqFesS(previous, returnAddr, $sprite) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Gk0qYhq6br8nL1O07mtqFesS$0;
  s.name = "is animated";
  s.$sprite = $sprite;
  s.result = undefined;
  return s;
}
cs.registerAction("is animated", "Gk0qYhq6br8nL1O07mtqFesS", a_Gk0qYhq6br8nL1O07mtqFesS, true);

function a_Gk0qYhq6br8nL1O07mtqFesS$0(s) {
  (s.pc = "3.105.1");
  var t_call_0 = (ok2(s, /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa, s.$sprite) && /* Sprite decorator */ s.d.$BU3ByaXRlIGRlY29yYXRvcgaa.at(s.$sprite, s));
  if (t_call_0) {
  var t_recOp_1 = t_call_0.perform_get("PbOsnnXiQWjibwDiWnLIfWar", s);
  }
  var t_call_2 = (ok1(s, t_recOp_1) && lib.String_.is_empty(t_recOp_1, s));
  var t_call_3 = (ok1(s, t_call_2) && lib.Boolean_.not(t_call_2, s));
  (s.result = t_call_3);
  return s.rt.leave();
}
cs.registerStep(a_Gk0qYhq6br8nL1O07mtqFesS$0, 'a_Gk0qYhq6br8nL1O07mtqFesS$0');

/* ACTION: create full animation */
function a_vJZ80S26SY13iReukIMXzPdy(previous, returnAddr, $sheet_id, $duration, $loops) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_vJZ80S26SY13iReukIMXzPdy$0;
  s.name = "create full animation";
  s.$sheet_id = $sheet_id;
  s.$duration = $duration;
  s.$loops = $loops;
  s.result = undefined;
  return s;
}
cs.registerAction("create full animation", "vJZ80S26SY13iReukIMXzPdy", a_vJZ80S26SY13iReukIMXzPdy, true);

function a_vJZ80S26SY13iReukIMXzPdy$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_vJZ80S26SY13iReukIMXzPdy$5, lib.RTValue.mkPicker(lib.String_.picker(), "", "sheet id", "$sheet_id"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "duration", "$duration"), lib.RTValue.mkPicker(lib.Number_.picker(), 0, "loops", "$loops"));
  return a_vJZ80S26SY13iReukIMXzPdy$5;
  }
  return a_vJZ80S26SY13iReukIMXzPdy$4;
}
cs.registerStep(a_vJZ80S26SY13iReukIMXzPdy$0, 'a_vJZ80S26SY13iReukIMXzPdy$0');

function a_vJZ80S26SY13iReukIMXzPdy$5(s) {
  return a_vJZ80S26SY13iReukIMXzPdy$4;
}
cs.registerStep(a_vJZ80S26SY13iReukIMXzPdy$5, 'a_vJZ80S26SY13iReukIMXzPdy$5');

function a_vJZ80S26SY13iReukIMXzPdy$4(s) {
  (s.pc = "3.110.1");
  return s.rt.enter(a_hoR5fLJDaWCqEiEZpL2h48LT(s, a_vJZ80S26SY13iReukIMXzPdy$1, s.$sheet_id));
}
cs.registerStep(a_vJZ80S26SY13iReukIMXzPdy$4, 'a_vJZ80S26SY13iReukIMXzPdy$4');

function a_vJZ80S26SY13iReukIMXzPdy$1(s) {
  s.t_actRes_0 = s.rt.returnedFrom.result;
  return s.rt.enter(a_BYl1YyPUzY9xO4PIb9WVeywK(s, a_vJZ80S26SY13iReukIMXzPdy$2, s.$sheet_id));
}
cs.registerStep(a_vJZ80S26SY13iReukIMXzPdy$1, 'a_vJZ80S26SY13iReukIMXzPdy$1');

function a_vJZ80S26SY13iReukIMXzPdy$2(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  return s.rt.enter(a_g0e2F0y8lMxbuhCC6w5hSJ9a(s, a_vJZ80S26SY13iReukIMXzPdy$3, s.$sheet_id, s.$duration, s.$loops, 1, 1, s.t_actRes_0, t_actRes_1));
}
cs.registerStep(a_vJZ80S26SY13iReukIMXzPdy$2, 'a_vJZ80S26SY13iReukIMXzPdy$2');

function a_vJZ80S26SY13iReukIMXzPdy$3(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  (s.result = t_actRes_2);
  if (s.previous.needsPicker) {
  s.rt.displayResult("sprite", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_vJZ80S26SY13iReukIMXzPdy$3, 'a_vJZ80S26SY13iReukIMXzPdy$3');

cs.startFn = function(rt) {
lib.App.rt_start(rt);
lib.Player.rt_start(rt);
lib.Senses.rt_start(rt);
lib.Time.rt_start(rt);
lib.Web.rt_start(rt);
};

cs.stopFn = function(rt) {
lib.App.rt_stop(rt);
lib.Player.rt_stop(rt);
lib.Senses.rt_stop(rt);
lib.Time.rt_stop(rt);
lib.Web.rt_stop(rt);
};

cs._compilerVersion = '1';cs._initGlobals = function(d) {
  if(!d.hasOwnProperty("$BU3ByaXRlIGRlY29yYXRvcgaa") || !d["$BU3ByaXRlIGRlY29yYXRvcgaa"]) d.$BU3ByaXRlIGRlY29yYXRvcgaa = new Tbl_BU3ByaXRlIGRlY29yYXRvcgaa(d.libName);
  if(!d.hasOwnProperty("$Bc2hlZXQgaW5kZXga") || !d["$Bc2hlZXQgaW5kZXga"]) d.$Bc2hlZXQgaW5kZXga = new Tbl_Bc2hlZXQgaW5kZXga(d.libName);

};

cs._initGlobals2 = function(d) {
};

cs._resetGlobals = function(d) {
  d.$ttDB4Z14tS2D49H96olVfxPC = undefined;
  d.$BU3ByaXRlIGRlY29yYXRvcgaa = undefined;
  d.$HmpFOp0jnpX9U3gAc1t52p1l = undefined;
  d.$Bc2hlZXQgaW5kZXga = undefined;
};

cs.mainActionName = "create sprite";
cs.authorId = "jjef";
cs.scriptId = "vroyc";
}),

// **************************************************************
"d2bbpYdDq6mcoCpqp1dEtgbi": (function (cs) {
'use strict';
var libs = cs.libs = {};
var lib = TDev.RT;
var callstackcurdepth = 0;
cs.scriptTitle = "game menu";
cs.scriptColor = "\u00239955bb";
/* ACTION: start */
function a_start(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_start$0;
  s.name = "start";
  s.$_ = undefined;
  return s;
}
cs.registerPage("start", "start", a_start, false);

function ok1(s, a0) {
  return (a0 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok2(s, a0, a1) {
  return (a0 == undefined || a1 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok3(s, a0, a1, a2) {
  return (a0 == undefined || a1 == undefined || a2 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok4(s, a0, a1, a2, a3) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok5(s, a0, a1, a2, a3, a4) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_start$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.60");
  var t_call_1 = lib.Box.is_init(s);
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.rt.getCurrentPage().model = s.d.$Bc3RhcnQgcGFnZSBkYXRh.create(s));
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.640");
  return s.rt.enter(a_stylepage(s, a_start$2));
  } else {
  (s.pc = "4.650");
  null;
  }
  return a_start$1;
}
cs.registerStep(a_start$0, 'a_start$0');

function a_start$2(s) {
  return a_start$1;
}
cs.registerStep(a_start$2, 'a_start$2');

function a_start$1(s) {
  var t_elseIf_2 = true;
  (s.pc = "4.65");
  true;
  if (true) {
  s.rt.enter_render();
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.690");
  var t_call_3 = lib.Box.page_height(s);
  var t_infix_4 = (ok1(s, t_call_3) && (t_call_3 / 8));
  (ok1(s, t_infix_4) && lib.Box.set_padding(t_infix_4, 1, 1, 1, s));
  (s.pc = "4.693");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.696");
  return s.rt.enter(a_QHP9ho2IGjrPxqq9F80pZmqj(s, a_start$4));
  } else {
  (s.pc = "4.6a0");
  null;
  }
  return a_start$3;
}
cs.registerStep(a_start$1, 'a_start$1');

function a_start$4(s) {
  (s.pc = "4.699");
  return s.rt.enter(a_LJpox6YpuCvn6ERcUlisZc56(s, a_start$5));
}
cs.registerStep(a_start$4, 'a_start$4');

function a_start$3(s) {
  return s.rt.leave();
}
cs.registerStep(a_start$3, 'a_start$3');

function a_start$5(s) {
  (s.pc = "4.69c");
  return s.rt.enter(a_mqb129Wh4dEV1uyHJF1oS5IJ(s, a_start$6));
}
cs.registerStep(a_start$5, 'a_start$5');

function a_start$6(s) {
  (s.pc = "4.69f");
  return s.rt.enter(a_XNqQQCzJZlGV2I6w0FE2aVvf(s, a_start$7));
}
cs.registerStep(a_start$6, 'a_start$6');

function a_start$7(s) {
  (s.pc = "4.69i");
  return s.rt.enter(a_OP6CcdaCET95J4x6c4vLnjpz(s, a_start$8));
}
cs.registerStep(a_start$7, 'a_start$7');

function a_start$8(s) {
  (s.pc = "4.69l");
  return s.rt.enter(a_VBoM3w1YjF9BzIB6ry8gv2PO(s, a_start$9));
}
cs.registerStep(a_start$8, 'a_start$8');

function a_start$9(s) {
  s.rt.leave_render();
  return a_start$3;
}
cs.registerStep(a_start$9, 'a_start$9');


//Ent_Bc3RhcnQgcGFnZSBkYXRh
function Ent_Bc3RhcnQgcGFnZSBkYXRh(p) {
  this.parent = p;
}
Ent_Bc3RhcnQgcGFnZSBkYXRh.prototype = new lib.ObjectEntry();
Ent_Bc3RhcnQgcGFnZSBkYXRh.prototype.keys = [];
Ent_Bc3RhcnQgcGFnZSBkYXRh.prototype.values = [];
Ent_Bc3RhcnQgcGFnZSBkYXRh.prototype.fields = [];
//Col_Bc3RhcnQgcGFnZSBkYXRh
function Col_Bc3RhcnQgcGFnZSBkYXRh(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_Bc3RhcnQgcGFnZSBkYXRh.prototype = lib.RecordCollection.prototype;
//Tbl_Bc3RhcnQgcGFnZSBkYXRh
function Tbl_Bc3RhcnQgcGFnZSBkYXRh(l) {
  this.libName = l;
  this.initParent();
}
Tbl_Bc3RhcnQgcGFnZSBkYXRh.prototype = new lib.ObjectSingleton();
Tbl_Bc3RhcnQgcGFnZSBkYXRh.prototype.entryCtor = Ent_Bc3RhcnQgcGFnZSBkYXRh;
Tbl_Bc3RhcnQgcGFnZSBkYXRh.prototype.selfCtor = Tbl_Bc3RhcnQgcGFnZSBkYXRh;
Tbl_Bc3RhcnQgcGFnZSBkYXRh.prototype.collectionCtor = Col_Bc3RhcnQgcGFnZSBkYXRh;
Tbl_Bc3RhcnQgcGFnZSBkYXRh.prototype.stableName = "Bc3RhcnQgcGFnZSBkYXRh";
Tbl_Bc3RhcnQgcGFnZSBkYXRh.prototype.entryKindName = "start page data";

// jsonimport
Ent_Bc3RhcnQgcGFnZSBkYXRh.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
}
cs.registerGlobal("$Bc3RhcnQgcGFnZSBkYXRh");
/* ACTION: show level selection */
function a_levelselection(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_levelselection$0;
  s.name = "show level selection";
  s.$_ = undefined;
  s.$grid_width = undefined;
  s.$grid_height = undefined;
  s.$numboxes = undefined;
  s.$area = undefined;
  s.$bsize = undefined;
  s.$cols = undefined;
  s.$rows = undefined;
  s.$alt1 = undefined;
  s.$alt2 = undefined;
  s.$mgn = undefined;
  s.$i = undefined;
  s.$j = undefined;
  s.$level_id = undefined;
  s.$lvl = undefined;
  return s;
}
cs.registerPage("show level selection", "levelselection", a_levelselection, false);

function a_levelselection$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.e0");
  var t_call_1 = lib.Box.is_init(s);
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.rt.getCurrentPage().model = s.d.$BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.create(s));
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.e40");
  return s.rt.enter(a_stylepage(s, a_levelselection$2));
  } else {
  (s.pc = "4.e50");
  null;
  }
  return a_levelselection$1;
}
cs.registerStep(a_levelselection$0, 'a_levelselection$0');

function a_levelselection$2(s) {
  (s.pc = "4.e43");
  lib.Wall.set_title("select a level", s);
  return a_levelselection$1;
}
cs.registerStep(a_levelselection$2, 'a_levelselection$2');

function a_levelselection$1(s) {
  var t_elseIf_2 = true;
  (s.pc = "4.e5");
  true;
  if (true) {
  s.rt.enter_render();
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.e90");
  lib.Box.push_box(s);
  (s.pc = "4.e920");
  lib.Box.set_margins(1, 1, 1, 1, s);
  (s.pc = "4.e923");
  var t_call_3 = lib.Box.page_width(s);
  var t_infix_4 = (ok1(s, t_call_3) && (t_call_3 - 3));
  (s.$grid_width = t_infix_4);
  (s.pc = "4.e926");
  var t_call_5 = lib.Box.page_height(s);
  var t_infix_6 = (ok1(s, t_call_5) && (t_call_5 - 3));
  (s.$grid_height = t_infix_6);
  (s.pc = "4.e929");
  (s.$numboxes = /* _level count */ s.d.$levelcount);
  (s.pc = "4.e92c");
  var t_infix_7 = (ok2(s, s.$grid_width, s.$grid_height) && (s.$grid_width * s.$grid_height));
  (s.$area = t_infix_7);
  (s.pc = "4.e92f");
  var t_infix_8 = (ok2(s, s.$area, s.$numboxes) && (s.$area / s.$numboxes));
  var t_call_9 = (ok1(s, t_infix_8) && lib.Math_.sqrt(t_infix_8, s));
  (s.$bsize = t_call_9);
  (s.pc = "4.e92i");
  var t_infix_10 = (ok2(s, s.$grid_width, s.$bsize) && (s.$grid_width / s.$bsize));
  var t_call_11 = (ok1(s, t_infix_10) && lib.Math_.floor(t_infix_10, s));
  (s.$cols = t_call_11);
  (s.pc = "4.e92l");
  var t_infix_12 = (ok2(s, s.$numboxes, s.$cols) && (s.$numboxes / s.$cols));
  var t_call_13 = (ok1(s, t_infix_12) && lib.Math_.ceiling(t_infix_12, s));
  (s.$rows = t_call_13);
  (s.pc = "4.e92o");
  return a_levelselection$4;
  } else {
  (s.pc = "4.ea0");
  null;
  }
  return a_levelselection$3;
}
cs.registerStep(a_levelselection$1, 'a_levelselection$1');

function a_levelselection$4(s) {
  var t_infix_14 = (ok2(s, s.$rows, s.$bsize) && (s.$rows * s.$bsize));
  var t_infix_15 = (ok2(s, t_infix_14, s.$grid_height) && (t_infix_14 > s.$grid_height));
  if (t_infix_15) {
  (s.pc = "4.e92s0");
  var t_infix_16 = (ok1(s, s.$cols) && (s.$cols + 1));
  var t_infix_17 = (ok2(s, s.$grid_width, t_infix_16) && (s.$grid_width / t_infix_16));
  var t_infix_18 = (ok1(s, t_infix_17) && (t_infix_17 - 0.001));
  (s.$alt1 = t_infix_18);
  (s.pc = "4.e92s3");
  var t_infix_19 = (ok2(s, s.$grid_height, s.$rows) && (s.$grid_height / s.$rows));
  var t_infix_20 = (ok1(s, t_infix_19) && (t_infix_19 - 0.001));
  (s.$alt2 = t_infix_20);
  (s.pc = "4.e92s6");
  var t_call_21 = (ok2(s, s.$alt1, s.$alt2) && lib.Math_.max(s.$alt1, s.$alt2, s));
  (s.$bsize = t_call_21);
  (s.pc = "4.e92s9");
  var t_infix_22 = (ok2(s, s.$grid_width, s.$bsize) && (s.$grid_width / s.$bsize));
  var t_call_23 = (ok1(s, t_infix_22) && lib.Math_.floor(t_infix_22, s));
  (s.$cols = t_call_23);
  (s.pc = "4.e92sc");
  var t_infix_24 = (ok2(s, s.$numboxes, s.$cols) && (s.$numboxes / s.$cols));
  var t_call_25 = (ok1(s, t_infix_24) && lib.Math_.ceiling(t_infix_24, s));
  (s.$rows = t_call_25);
  return a_levelselection$4;
  }
  (s.pc = "4.e92s");
  var t_call_26 = (ok1(s, s.$bsize) && lib.Math_.min(13, s.$bsize, s));
  (s.$bsize = t_call_26);
  (s.pc = "4.e92v");
  var t_infix_27 = (ok1(s, s.$bsize) && (0.03 * s.$bsize));
  (s.$mgn = t_infix_27);
  var t_elseIf_28 = true;
  (s.pc = "4.e92y");
  var t_call_29 = lib.Box.pixels_per_em(s);
  var t_infix_30 = (ok2(s, s.$mgn, t_call_29) && (s.$mgn * t_call_29));
  var t_infix_31 = (ok1(s, t_infix_30) && (t_infix_30 < 2));
  ok1(s, t_infix_31);
  if (t_infix_31) {
  (s.pc = "4.e92C0");
  var t_call_32 = lib.Box.pixels_per_em(s);
  var t_infix_33 = (ok1(s, t_call_32) && (2 / t_call_32));
  (s.$mgn = t_infix_33);
  } else {
  (s.pc = "4.e92D0");
  null;
  }
  (s.pc = "4.e92D");
  var t_infix_34 = (ok2(s, s.$bsize, s.$mgn) && (s.$bsize - s.$mgn));
  (s.$bsize = t_infix_34);
  (s.pc = "4.e92G");
  lib.Box.push_box(s);
  (s.pc = "4.e92I0");
  var t_infix_35 = (ok2(s, s.$rows, s.$bsize) && (s.$rows * s.$bsize));
  var t_infix_36 = (ok1(s, s.$rows) && (s.$rows - 1));
  var t_infix_37 = (ok2(s, t_infix_36, s.$mgn) && (t_infix_36 * s.$mgn));
  var t_infix_38 = (ok2(s, t_infix_35, t_infix_37) && (t_infix_35 + t_infix_37));
  (ok1(s, t_infix_38) && lib.Box.set_height(t_infix_38, s));
  (s.pc = "4.e92I3");
  lib.Box.use_vertical_layout(s);
  (s.pc = "4.e92I6");
  lib.Box.set_vertical_align("justify", s);
  (s.pc = "4.e92I9");
  s.t_bnd_39 = s.$rows;
  (s.$i = 0);
  return a_levelselection$7;
}
cs.registerStep(a_levelselection$4, 'a_levelselection$4');

function a_levelselection$3(s) {
  return s.rt.leave();
}
cs.registerStep(a_levelselection$3, 'a_levelselection$3');

function a_levelselection$7(s) {
  if ((s.$i < s.t_bnd_39)) {
  (s.pc = "4.e92Id0");
  lib.Box.push_box(s);
  (s.pc = "4.e92Id20");
  var t_infix_40 = (ok2(s, s.$cols, s.$bsize) && (s.$cols * s.$bsize));
  var t_infix_41 = (ok1(s, s.$cols) && (s.$cols - 1));
  var t_infix_42 = (ok2(s, t_infix_41, s.$mgn) && (t_infix_41 * s.$mgn));
  var t_infix_43 = (ok2(s, t_infix_40, t_infix_42) && (t_infix_40 + t_infix_42));
  (ok1(s, t_infix_43) && lib.Box.set_width(t_infix_43, s));
  (s.pc = "4.e92Id23");
  lib.Box.use_horizontal_layout(s);
  (s.pc = "4.e92Id26");
  lib.Box.set_horizontal_align("justify", s);
  (s.pc = "4.e92Id29");
  s.t_bnd_44 = s.$cols;
  (s.$j = 0);
  return a_levelselection$9;
  }
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  s.rt.leave_render();
  return a_levelselection$3;
}
cs.registerStep(a_levelselection$7, 'a_levelselection$7');

function a_levelselection$9(s) {
  if ((s.$j < s.t_bnd_44)) {
  (s.pc = "4.e92Id2d0");
  var t_infix_45 = (ok2(s, s.$i, s.$cols) && (s.$i * s.$cols));
  var t_infix_46 = (ok2(s, t_infix_45, s.$j) && (t_infix_45 + s.$j));
  var t_infix_47 = (ok1(s, t_infix_46) && (t_infix_46 + 1));
  (s.$level_id = t_infix_47);
  (s.pc = "4.e92Id2d3");
  lib.Box.push_box(s);
  (s.pc = "4.e92Id2d50");
  (ok1(s, s.$bsize) && lib.Box.set_width(s.$bsize, s));
  (s.pc = "4.e92Id2d53");
  (ok1(s, s.$bsize) && lib.Box.set_height(s.$bsize, s));
  (s.pc = "4.e92Id2d56");
  lib.Box.use_overlay_layout(s);
  var t_elseIf_48 = true;
  (s.pc = "4.e92Id2d59");
  var t_infix_49 = (ok2(s, s.$level_id, /* _level count */ s.d.$levelcount) && (s.$level_id <= /* _level count */ s.d.$levelcount));
  ok1(s, t_infix_49);
  if (t_infix_49) {
  (s.pc = "4.e92Id2d5d0");
  return s.rt.enter(a_uIQCNem1kvZBE4J6UHoWPCK1(s, a_levelselection$12, s.$level_id));
  } else {
  (s.pc = "4.e92Id2d5e0");
  null;
  }
  return a_levelselection$11;
  }
  lib.Box.pop_box(s);
  (s.$i++);
  return a_levelselection$7;
}
cs.registerStep(a_levelselection$9, 'a_levelselection$9');

function a_levelselection$12(s) {
  var t_actRes_50 = s.rt.returnedFrom.result;
  (s.$lvl = t_actRes_50);
  (s.pc = "4.e92Id2d5d3");
  return s.rt.enter(a_RiKp9WsgmJDFjpU5f9NbOSB6(s, a_levelselection$13, s.$lvl, s.$bsize, s.$bsize));
}
cs.registerStep(a_levelselection$12, 'a_levelselection$12');

function a_levelselection$11(s) {
  lib.Box.pop_box(s);
  (s.$j++);
  return a_levelselection$9;
}
cs.registerStep(a_levelselection$11, 'a_levelselection$11');

function a_levelselection$13(s) {
  return a_levelselection$11;
}
cs.registerStep(a_levelselection$13, 'a_levelselection$13');


//Ent_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa
function Ent_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa(p) {
  this.parent = p;
}
Ent_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype = new lib.ObjectEntry();
Ent_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype.keys = [];
Ent_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype.values = [];
Ent_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype.fields = [];
//Col_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa
function Col_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype = lib.RecordCollection.prototype;
//Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa
function Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa(l) {
  this.libName = l;
  this.initParent();
}
Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype = new lib.ObjectSingleton();
Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype.entryCtor = Ent_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa;
Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype.selfCtor = Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa;
Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype.collectionCtor = Col_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa;
Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype.stableName = "BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa";
Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype.entryKindName = "show level selection page data";

// jsonimport
Ent_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
}
cs.registerGlobal("$BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa");

//Ent_BbGV2ZWwgaW5kZXga
function Ent_BbGV2ZWwgaW5kZXga(p) {
  this.parent = p;
}
Ent_BbGV2ZWwgaW5kZXga.prototype = new lib.CloudIndexEntry();
Ent_BbGV2ZWwgaW5kZXga.prototype.keys = ["xneF5ygmtTQb4TogUvxfMDe1"];
Ent_BbGV2ZWwgaW5kZXga.prototype.values = ["xF2SoxL0oxSdoSCsMwe5wRzo", "e6cQUfw2298se1yYeqTlPcX8", "FcypXS06YlmK2KAQ327sEovl", "qhCetiH2Bj2wrY6fz4oObZF5", "KVEfbkQ37muzCX37bf2bTBbl", "qod2mWVTq0MtY6ZGt7IA6uUe"];
Ent_BbGV2ZWwgaW5kZXga.prototype.fields = ["xneF5ygmtTQb4TogUvxfMDe1", "xF2SoxL0oxSdoSCsMwe5wRzo", "e6cQUfw2298se1yYeqTlPcX8", "FcypXS06YlmK2KAQ327sEovl", "qhCetiH2Bj2wrY6fz4oObZF5", "KVEfbkQ37muzCX37bf2bTBbl", "qod2mWVTq0MtY6ZGt7IA6uUe"];
Ent_BbGV2ZWwgaW5kZXga.prototype.xneF5ygmtTQb4TogUvxfMDe1_realname = "_index";
Ent_BbGV2ZWwgaW5kZXga.prototype.xF2SoxL0oxSdoSCsMwe5wRzo_realname = "_score";
Ent_BbGV2ZWwgaW5kZXga.prototype.e6cQUfw2298se1yYeqTlPcX8_realname = "_completed";
Ent_BbGV2ZWwgaW5kZXga.prototype.FcypXS06YlmK2KAQ327sEovl_realname = "_description";
Ent_BbGV2ZWwgaW5kZXga.prototype.qhCetiH2Bj2wrY6fz4oObZF5_realname = "_unlocked";
Ent_BbGV2ZWwgaW5kZXga.prototype.KVEfbkQ37muzCX37bf2bTBbl_realname = "_skip details";
Ent_BbGV2ZWwgaW5kZXga.prototype.qod2mWVTq0MtY6ZGt7IA6uUe_realname = "_max score";
//Col_BbGV2ZWwgaW5kZXga
function Col_BbGV2ZWwgaW5kZXga(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_BbGV2ZWwgaW5kZXga.prototype = lib.RecordCollection.prototype;
//Tbl_BbGV2ZWwgaW5kZXga
function Tbl_BbGV2ZWwgaW5kZXga(l) {
  this.libName = l;
  this.initParent();
}
Tbl_BbGV2ZWwgaW5kZXga.prototype = new lib.CloudIndexSingleton();
Tbl_BbGV2ZWwgaW5kZXga.prototype.entryCtor = Ent_BbGV2ZWwgaW5kZXga;
Tbl_BbGV2ZWwgaW5kZXga.prototype.selfCtor = Tbl_BbGV2ZWwgaW5kZXga;
Tbl_BbGV2ZWwgaW5kZXga.prototype.collectionCtor = Col_BbGV2ZWwgaW5kZXga;
Tbl_BbGV2ZWwgaW5kZXga.prototype.stableName = "BbGV2ZWwgaW5kZXga";
Tbl_BbGV2ZWwgaW5kZXga.prototype.entryKindName = "level";
Tbl_BbGV2ZWwgaW5kZXga.prototype.cloudtype = "BbGV2ZWwgaW5kZXga\u005bdouble\u005d";
Tbl_BbGV2ZWwgaW5kZXga.prototype.key_cloudtypes = ["double"];
Tbl_BbGV2ZWwgaW5kZXga.prototype.value_cloudtypes = ["xF2SoxL0oxSdoSCsMwe5wRzo\u002cdouble\u005bBbGV2ZWwgaW5kZXga\u005bdouble\u005d\u005d", "e6cQUfw2298se1yYeqTlPcX8\u002cboolean\u005bBbGV2ZWwgaW5kZXga\u005bdouble\u005d\u005d", "FcypXS06YlmK2KAQ327sEovl\u002cstring\u005bBbGV2ZWwgaW5kZXga\u005bdouble\u005d\u005d", "qhCetiH2Bj2wrY6fz4oObZF5\u002cboolean\u005bBbGV2ZWwgaW5kZXga\u005bdouble\u005d\u005d", "KVEfbkQ37muzCX37bf2bTBbl\u002cboolean\u005bBbGV2ZWwgaW5kZXga\u005bdouble\u005d\u005d", "qod2mWVTq0MtY6ZGt7IA6uUe\u002cdouble\u005bBbGV2ZWwgaW5kZXga\u005bdouble\u005d\u005d"];
Tbl_BbGV2ZWwgaW5kZXga.prototype.localsession = true;

// jsonimport
Tbl_BbGV2ZWwgaW5kZXga.prototype.importJsonKeys = function (ctx, json) {
  var s = ctx.s;
  var a = [];
  a.push(ctx.importNumber(json, "_index"));
  return a;
}
Ent_BbGV2ZWwgaW5kZXga.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("xF2SoxL0oxSdoSCsMwe5wRzo", ctx.importNumber(json, "_score"), s);
  this.perform_set("e6cQUfw2298se1yYeqTlPcX8", ctx.importBoolean(json, "_completed"), s);
  this.perform_set("FcypXS06YlmK2KAQ327sEovl", ctx.importString(json, "_description"), s);
  this.perform_set("qhCetiH2Bj2wrY6fz4oObZF5", ctx.importBoolean(json, "_unlocked"), s);
  this.perform_set("KVEfbkQ37muzCX37bf2bTBbl", ctx.importBoolean(json, "_skip details"), s);
  this.perform_set("qod2mWVTq0MtY6ZGt7IA6uUe", ctx.importNumber(json, "_max score"), s);
}
cs.registerGlobal("$BbGV2ZWwgaW5kZXga");
/* ACTION: test start */
function a_teststart(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_teststart$0;
  s.name = "test start";
  s.$start_level = undefined;
  s.$level = undefined;
  s.$board = undefined;
  s.$theme = undefined;
  s.$level2 = undefined;
  s.$level3 = undefined;
  s.$pic = undefined;
  return s;
}
cs.registerAction("test start", "teststart", a_teststart, true);

function ok6(s, a0, a1, a2, a3, a4, a5) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined || a5 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok7(s, a0, a1, a2, a3, a4, a5, a6) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined || a5 == undefined || a6 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function ok8(s, a0, a1, a2, a3, a4, a5, a6, a7) {
  return (a0 == undefined || a1 == undefined || a2 == undefined || a3 == undefined || a4 == undefined || a5 == undefined || a6 == undefined || a7 == undefined) ?
       TDev.Util.userError("using invalid value") : true;
}

function a_teststart$0(s) {
  (s.pc = "4.l40");
  var t_lmbProxy_0 = s.libs.mkLambdaProxy;
  (s.$start_level = function(la0, la1, la2) { return a_a_teststart$1(t_lmbProxy_0(la0), la1, la2) });
  (s.pc = "4.l0");
  return s.rt.enter(a_initialize(s, a_teststart$2, "test title", "test subtitle", 4, s.$start_level));
}
cs.registerStep(a_teststart$0, 'a_teststart$0');

function a_teststart$2(s) {
  (s.pc = "4.l4");
  return s.rt.enter(a_onF52KFta97Q2Qwj5GSJFw9u(s, a_teststart$3));
}
cs.registerStep(a_teststart$2, 'a_teststart$2');

function a_teststart$3(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (s.$theme = t_actRes_1);
  (s.pc = "4.l7");
  var t_call_2 = lib.Colors.blue(s);
  return s.rt.enter(a_xOGMqFGX0oajGlVqWyq6ciVg(s, a_teststart$4, s.$theme, t_call_2));
}
cs.registerStep(a_teststart$3, 'a_teststart$3');

function a_teststart$4(s) {
  (s.pc = "4.la");
  var t_call_3 = lib.Colors.white(s);
  return s.rt.enter(a_wjHWOo2L9s4mti20Bl4xgRr7(s, a_teststart$5, s.$theme, t_call_3));
}
cs.registerStep(a_teststart$4, 'a_teststart$4');

function a_teststart$5(s) {
  (s.pc = "4.ld");
  return s.rt.enter(a_JuYMgo4f6JZDHLov4on94izn(s, a_teststart$6));
}
cs.registerStep(a_teststart$5, 'a_teststart$5');

function a_teststart$6(s) {
  var t_actRes_4 = s.rt.returnedFrom.result;
  var t_call_5 = lib.Colors.green(s);
  var t_call_6 = (ok1(s, t_call_5) && t_call_5.darken(0.5, s));
  return s.rt.enter(a_xOGMqFGX0oajGlVqWyq6ciVg(s, a_teststart$7, t_actRes_4, t_call_6));
}
cs.registerStep(a_teststart$6, 'a_teststart$6');

function a_teststart$7(s) {
  (s.pc = "4.lg");
  return s.rt.enter(a_vEMbt6oeR6yVzubwR225d5o2(s, a_teststart$8, "The credits"));
}
cs.registerStep(a_teststart$7, 'a_teststart$7');

function a_teststart$8(s) {
  (s.pc = "4.lj");
  return s.rt.enter(a_jEFN2SCBqk8f47TxtO4wNwH1(s, a_teststart$9, "Follow the rules"));
}
cs.registerStep(a_teststart$8, 'a_teststart$8');

function a_teststart$9(s) {
  (s.pc = "4.lm");
  return s.rt.enter(a_uIQCNem1kvZBE4J6UHoWPCK1(s, a_teststart$10, 1));
}
cs.registerStep(a_teststart$9, 'a_teststart$9');

function a_teststart$10(s) {
  var t_actRes_7 = s.rt.returnedFrom.result;
  (s.$level2 = t_actRes_7);
  (s.pc = "4.lp");
  return s.rt.enter(a_LDiEr2d1hh8lQDdpGiAfUUDk(s, a_teststart$11, s.$level2, 2100));
}
cs.registerStep(a_teststart$10, 'a_teststart$10');

function a_teststart$11(s) {
  (s.pc = "4.ls");
  return s.rt.enter(a_kU2A1tJvfkjT2FPkIK08A1Aq(s, a_teststart$12, s.$level2, "tutorial"));
}
cs.registerStep(a_teststart$11, 'a_teststart$11');

function a_teststart$12(s) {
  (s.pc = "4.lv");
  return s.rt.enter(a_uIQCNem1kvZBE4J6UHoWPCK1(s, a_teststart$13, 2));
}
cs.registerStep(a_teststart$12, 'a_teststart$12');

function a_teststart$13(s) {
  var t_actRes_8 = s.rt.returnedFrom.result;
  (s.$level3 = t_actRes_8);
  (s.pc = "4.ly");
  return s.rt.enter(a_LDiEr2d1hh8lQDdpGiAfUUDk(s, a_teststart$14, s.$level3, 2100));
}
cs.registerStep(a_teststart$13, 'a_teststart$13');

function a_teststart$14(s) {
  (s.pc = "4.lB");
  return s.rt.enter(a_kyM6BKxra6FMoP8AENJbQMGs(s, a_teststart$15, s.$level3));
}
cs.registerStep(a_teststart$14, 'a_teststart$14');

function a_teststart$15(s) {
  var t_actRes_9 = s.rt.returnedFrom.result;
  var t_call_10 = lib.Colors.orange(s);
  return s.rt.enter(a_xOGMqFGX0oajGlVqWyq6ciVg(s, a_teststart$16, t_actRes_9, t_call_10));
}
cs.registerStep(a_teststart$15, 'a_teststart$15');

function a_teststart$16(s) {
  (s.pc = "4.lE");
  var t_call_11 = lib.Media.create_picture(480, 800, s);
  s.rt.markAllocated(t_call_11);
  (s.$pic = t_call_11);
  (s.pc = "4.lH");
  var t_call_12 = lib.Colors.red(s);
  s.rt.logObjectMutation(s.$pic);
  var t_resumeCtx_13 = s.rt.getBlockingResumeCtx(a_teststart$17);
  (ok2(s, s.$pic, t_call_12) && s.$pic.clear(t_call_12, t_resumeCtx_13));
  return a_teststart$17;
}
cs.registerStep(a_teststart$16, 'a_teststart$16');

function a_teststart$17(s) {
  (s.pc = "4.lK");
  var t_call_14 = lib.Colors.accent(s);
  s.rt.logObjectMutation(s.$pic);
  var t_resumeCtx_15 = s.rt.getBlockingResumeCtx(a_teststart$18);
  (ok2(s, s.$pic, t_call_14) && s.$pic.draw_line(0, 0, 480, 800, t_call_14, 3, t_resumeCtx_15));
  return a_teststart$18;
}
cs.registerStep(a_teststart$17, 'a_teststart$17');

function a_teststart$18(s) {
  (s.pc = "4.lN");
  return s.rt.enter(a_kyM6BKxra6FMoP8AENJbQMGs(s, a_teststart$19, s.$level3));
}
cs.registerStep(a_teststart$18, 'a_teststart$18');

function a_teststart$19(s) {
  var t_actRes_16 = s.rt.returnedFrom.result;
  return s.rt.enter(a_AKTQU67EzzZS6W1xy70h9dH4(s, a_teststart$20, t_actRes_16, s.$pic));
}
cs.registerStep(a_teststart$19, 'a_teststart$19');

function a_teststart$20(s) {
  (s.pc = "4.lQ");
  return s.rt.enter(a_kU2A1tJvfkjT2FPkIK08A1Aq(s, a_teststart$21, s.$level3, "Lorem ipsum dolor sit amet\u002c consectetur adipisicing elit\u002c sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam\u002c quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident\u002c sunt in culpa qui officia deserunt mollit anim id est laborum."));
}
cs.registerStep(a_teststart$20, 'a_teststart$20');

function a_teststart$21(s) {
  (s.pc = "4.lT");
  return s.rt.enter(a_uIQCNem1kvZBE4J6UHoWPCK1(s, a_teststart$22, 4));
}
cs.registerStep(a_teststart$21, 'a_teststart$21');

function a_teststart$22(s) {
  var t_actRes_17 = s.rt.returnedFrom.result;
  return s.rt.enter(a_abOWAkFdJLtkXvCwDz9Uucwc(s, a_teststart$23, t_actRes_17, true));
}
cs.registerStep(a_teststart$22, 'a_teststart$22');

function a_teststart$23(s) {
  (s.pc = "4.lW");
  s.rt.forceNonRender();
  s.rt.forcePageRefresh();
  s.rt.postAutoPage(s.d.libName, "start");
  return s.rt.leave();
}
cs.registerStep(a_teststart$23, 'a_teststart$23');

/* ACTION: a_teststart::lambda::1 */
function a_a_teststart$1(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_teststart$1$0;
  s.name = "test start";
  s.$board = undefined;
  return s;
}
cs.registerLambda("a_teststart\u003a\u003alambda\u003a\u003a1", "a_teststart$1", a_a_teststart$1, true);

function a_a_teststart$1$0(s) {
  (s.pc = "4.l420");
  var t_libcall_0 = s.libs["game"]["start"](s);
  return s.rt.enter(t_libcall_0.invoke(t_libcall_0, a_a_teststart$1$1));
}
cs.registerStep(a_a_teststart$1$0, 'a_a_teststart$1$0');

function a_a_teststart$1$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (s.$board = t_actRes_1);
  (s.pc = "4.l423");
  var t_call_2 = lib.Math_.random(2100, s);
  var t_libcall_3 = s.libs["game"]["set score"](s);
  return s.rt.enter(t_libcall_3.invoke(t_libcall_3, a_a_teststart$1$2, t_call_2));
}
cs.registerStep(a_a_teststart$1$1, 'a_a_teststart$1$1');

function a_a_teststart$1$2(s) {
  (s.pc = "4.l426");
  var t_libcall_4 = s.libs["game"]["end"](s);
  return s.rt.enter(t_libcall_4.invoke(t_libcall_4, a_a_teststart$1$3));
}
cs.registerStep(a_a_teststart$1$2, 'a_a_teststart$1$2');

function a_a_teststart$1$3(s) {
  var t_actRes_5 = s.rt.returnedFrom.result;
  t_actRes_5;
  return s.rt.leave();
}
cs.registerStep(a_a_teststart$1$3, 'a_a_teststart$1$3');

/* ACTION: apply page theme */
function a_stylepage(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_stylepage$0;
  s.name = "apply page theme";
  return s;
}
cs.registerAction("apply page theme", "stylepage", a_stylepage, false);

function a_stylepage$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.q0");
  if (/* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N) {
  var t_recOp_1 = /* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N[("xB8gTd6eYdzIepWazYoNI284")];
  }
  var t_call_2 = (ok1(s, t_recOp_1) && t_recOp_1.A(s));
  var t_infix_3 = (ok1(s, t_call_2) && (t_call_2 > 0));
  ok1(s, t_infix_3);
  if (t_infix_3) {
  (s.pc = "4.q40");
  if (/* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N) {
  var t_recOp_4 = /* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N[("xB8gTd6eYdzIepWazYoNI284")];
  }
  (ok1(s, t_recOp_4) && lib.Wall.set_background(t_recOp_4, s));
  } else {
  (s.pc = "4.q50");
  null;
  }
  var t_elseIf_5 = true;
  (s.pc = "4.q5");
  if (/* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N) {
  var t_recOp_6 = /* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N[("xePTIfIYg4fJ3yUz2Cv0ucfs")];
  }
  var t_call_7 = (ok1(s, t_recOp_6) && t_recOp_6.A(s));
  var t_infix_8 = (ok1(s, t_call_7) && (t_call_7 > 0));
  ok1(s, t_infix_8);
  if (t_infix_8) {
  (s.pc = "4.q90");
  if (/* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N) {
  var t_recOp_9 = /* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N[("xePTIfIYg4fJ3yUz2Cv0ucfs")];
  }
  (ok1(s, t_recOp_9) && lib.Wall.set_foreground(t_recOp_9, s));
  } else {
  (s.pc = "4.qa0");
  null;
  }
  var t_elseIf_10 = true;
  (s.pc = "4.qa");
  if (/* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N) {
  var t_recOp_11 = /* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N[("GKYkcMSe7G5kwyFRmRdC9FWX")];
  }
  var t_call_12 = lib.Boolean_.not((t_recOp_11 == undefined), s);
  ok1(s, t_call_12);
  if (t_call_12) {
  (s.pc = "4.qe0");
  if (/* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N) {
  var t_recOp_13 = /* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N[("GKYkcMSe7G5kwyFRmRdC9FWX")];
  }
  var t_resumeCtx_14 = s.rt.getBlockingResumeCtx(a_stylepage$10);
  (ok1(s, t_recOp_13) && lib.Wall.set_background_picture(t_recOp_13, t_resumeCtx_14));
  return a_stylepage$10;
  } else {
  (s.pc = "4.qf0");
  null;
  }
  return a_stylepage$8;
}
cs.registerStep(a_stylepage$0, 'a_stylepage$0');

function a_stylepage$10(s) {
  return a_stylepage$8;
}
cs.registerStep(a_stylepage$10, 'a_stylepage$10');

function a_stylepage$8(s) {
  return s.rt.leave();
}
cs.registerStep(a_stylepage$8, 'a_stylepage$8');

/* ACTION: on game end */
function a_ongameend(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_ongameend$0;
  s.name = "on game end";
  s.$level = $level;
  s.$total = undefined;
  s.$next_level = undefined;
  return s;
}
cs.registerAction("on game end", "ongameend", a_ongameend, true);

function a_ongameend$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.v0");
  var t_libcall_1 = s.libs["game"]["score"](s);
  return s.rt.enter(t_libcall_1.invoke(t_libcall_1, a_ongameend$1));
}
cs.registerStep(a_ongameend$0, 'a_ongameend$0');

function a_ongameend$1(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  var t_infix_3 = (ok1(s, t_actRes_2) && (t_actRes_2 > 0));
  ok1(s, t_infix_3);
  if (t_infix_3) {
  (s.pc = "4.v40");
  var t_libcall_4 = s.libs["game"]["score"](s);
  return s.rt.enter(t_libcall_4.invoke(t_libcall_4, a_ongameend$3));
  } else {
  (s.pc = "4.v50");
  null;
  }
  return a_ongameend$2;
}
cs.registerStep(a_ongameend$1, 'a_ongameend$1');

function a_ongameend$3(s) {
  var t_actRes_5 = s.rt.returnedFrom.result;
  if (s.$level) {
  var t_recOp_6 = s.$level.perform_get("xF2SoxL0oxSdoSCsMwe5wRzo", s);
  }
  var t_call_7 = (ok2(s, t_actRes_5, t_recOp_6) && lib.Math_.max(t_actRes_5, t_recOp_6, s));
  if (s.$level) {
  s.$level.perform_set("xF2SoxL0oxSdoSCsMwe5wRzo", t_call_7, s);
  }
  var t_elseIf_8 = true;
  (s.pc = "4.v43");
  if (s.$level) {
  var t_recOp_9 = s.$level.perform_get("qod2mWVTq0MtY6ZGt7IA6uUe", s);
  }
  var t_infix_10 = (ok1(s, t_recOp_9) && (t_recOp_9 > 0));
  ok1(s, t_infix_10);
  if (t_infix_10) {
  (s.pc = "4.v470");
  if (s.$level) {
  var t_recOp_11 = s.$level.perform_get("xF2SoxL0oxSdoSCsMwe5wRzo", s);
  }
  if (s.$level) {
  var t_recOp_12 = s.$level.perform_get("qod2mWVTq0MtY6ZGt7IA6uUe", s);
  }
  var t_call_13 = (ok2(s, t_recOp_11, t_recOp_12) && lib.Math_.min(t_recOp_11, t_recOp_12, s));
  if (s.$level) {
  s.$level.perform_set("xF2SoxL0oxSdoSCsMwe5wRzo", t_call_13, s);
  }
  } else {
  (s.pc = "4.v480");
  null;
  }
  return a_ongameend$2;
}
cs.registerStep(a_ongameend$3, 'a_ongameend$3');

function a_ongameend$2(s) {
  (s.pc = "4.v5");
  if (s.$level) {
  s.$level.perform_set("e6cQUfw2298se1yYeqTlPcX8", true, s);
  }
  (s.pc = "4.v9");
  return s.rt.enter(a_vhNGQ52iSlYqwQHeL8LQGR8e(s, a_ongameend$12));
}
cs.registerStep(a_ongameend$2, 'a_ongameend$2');

function a_ongameend$12(s) {
  var t_actRes_14 = s.rt.returnedFrom.result;
  (s.$total = t_actRes_14);
  (s.pc = "4.vc");
  s.rt.logObjectMutation(null);
  var t_resumeCtx_15 = s.rt.getAwaitResumeCtx(a_ongameend$13);
  (ok1(s, s.$total) && lib.Bazaar.post_leaderboard_score(s.$total, t_resumeCtx_15));
  return a_ongameend$13;
}
cs.registerStep(a_ongameend$12, 'a_ongameend$12');

function a_ongameend$13(s) {
  var t_elseIf_16 = true;
  (s.pc = "4.vg");
  var t_infix_17 = (ok1(s, (ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")])) && ((ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")]) + 1));
  var t_infix_18 = (ok2(s, t_infix_17, /* _level count */ s.d.$levelcount) && (t_infix_17 <= /* _level count */ s.d.$levelcount));
  ok1(s, t_infix_18);
  if (t_infix_18) {
  (s.pc = "4.vk0");
  var t_infix_19 = (ok1(s, (ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")])) && ((ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")]) + 1));
  return s.rt.enter(a_uIQCNem1kvZBE4J6UHoWPCK1(s, a_ongameend$15, t_infix_19));
  } else {
  (s.pc = "4.vl0");
  null;
  }
  return a_ongameend$14;
}
cs.registerStep(a_ongameend$13, 'a_ongameend$13');

function a_ongameend$15(s) {
  var t_actRes_20 = s.rt.returnedFrom.result;
  (s.$next_level = t_actRes_20);
  (s.pc = "4.vk3");
  if (s.$next_level) {
  s.$next_level.perform_set("qhCetiH2Bj2wrY6fz4oObZF5", true, s);
  }
  return a_ongameend$14;
}
cs.registerStep(a_ongameend$15, 'a_ongameend$15');

function a_ongameend$14(s) {
  (s.pc = "4.vm");
  var t_call_21 = lib.Wall.pop_page(s);
  t_call_21;
  return s.rt.leave();
}
cs.registerStep(a_ongameend$14, 'a_ongameend$14');

/* ACTION: example */
function a_example(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_example$0;
  s.name = "example";
  s.$title = undefined;
  s.$subtitle = undefined;
  s.$level_count = undefined;
  s.$start_level = undefined;
  s.$level = undefined;
  s.$theme = undefined;
  s.$pic = undefined;
  s.$lvl = undefined;
  return s;
}
cs.registerAction("example", "example", a_example, true);

function a_example$0(s) {
  (s.pc = "4.A9");
  (s.$title = "my awesome game");
  (s.pc = "4.Ac");
  (s.$subtitle = "yay!");
  (s.pc = "4.Af");
  (s.$level_count = 10);
  (s.pc = "4.Am0");
  var t_lmbProxy_0 = s.libs.mkLambdaProxy;
  (s.$start_level = function(la0, la1, la2) { return a_a_example$1(t_lmbProxy_0(la0), la1, la2) });
  (s.pc = "4.Ai");
  return s.rt.enter(a_initialize(s, a_example$2, s.$title, s.$subtitle, s.$level_count, s.$start_level));
}
cs.registerStep(a_example$0, 'a_example$0');

function a_example$2(s) {
  (s.pc = "4.Ao");
  s.rt.forceNonRender();
  s.rt.forcePageRefresh();
  s.rt.postAutoPage(s.d.libName, "start");
  (s.pc = "4.Ar");
  null;
  (s.pc = "4.Az");
  return s.rt.enter(a_vEMbt6oeR6yVzubwR225d5o2(s, a_example$3, "Thanks to my friends..."));
}
cs.registerStep(a_example$2, 'a_example$2');

function a_example$3(s) {
  (s.pc = "4.AD");
  return s.rt.enter(a_jEFN2SCBqk8f47TxtO4wNwH1(s, a_example$4, "Here are the rules\u003a ..."));
}
cs.registerStep(a_example$3, 'a_example$3');

function a_example$4(s) {
  (s.pc = "4.AI");
  return s.rt.enter(a_onF52KFta97Q2Qwj5GSJFw9u(s, a_example$5));
}
cs.registerStep(a_example$4, 'a_example$4');

function a_example$5(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (s.$theme = t_actRes_1);
  (s.pc = "4.AM");
  var t_call_2 = lib.Colors.blue(s);
  return s.rt.enter(a_xOGMqFGX0oajGlVqWyq6ciVg(s, a_example$6, s.$theme, t_call_2));
}
cs.registerStep(a_example$5, 'a_example$5');

function a_example$6(s) {
  (s.pc = "4.AQ");
  var t_call_3 = lib.Colors.white(s);
  return s.rt.enter(a_wjHWOo2L9s4mti20Bl4xgRr7(s, a_example$7, s.$theme, t_call_3));
}
cs.registerStep(a_example$6, 'a_example$6');

function a_example$7(s) {
  (s.pc = "4.AV");
  var t_call_4 = lib.Media.create_picture(480, 800, s);
  s.rt.markAllocated(t_call_4);
  (s.$pic = t_call_4);
  (s.pc = "4.AZ");
  return s.rt.enter(a_AKTQU67EzzZS6W1xy70h9dH4(s, a_example$8, s.$theme, s.$pic));
}
cs.registerStep(a_example$7, 'a_example$7');

function a_example$8(s) {
  (s.pc = "4.A65.");
  return s.rt.enter(a_JuYMgo4f6JZDHLov4on94izn(s, a_example$9));
}
cs.registerStep(a_example$8, 'a_example$8');

function a_example$9(s) {
  var t_actRes_5 = s.rt.returnedFrom.result;
  var t_call_6 = lib.Colors.green(s);
  return s.rt.enter(a_xOGMqFGX0oajGlVqWyq6ciVg(s, a_example$10, t_actRes_5, t_call_6));
}
cs.registerStep(a_example$9, 'a_example$9');

function a_example$10(s) {
  (s.pc = "4.A70.");
  return s.rt.enter(a_uIQCNem1kvZBE4J6UHoWPCK1(s, a_example$11, 1));
}
cs.registerStep(a_example$10, 'a_example$10');

function a_example$11(s) {
  var t_actRes_7 = s.rt.returnedFrom.result;
  (s.$lvl = t_actRes_7);
  (s.pc = "4.A74.");
  return s.rt.enter(a_kU2A1tJvfkjT2FPkIK08A1Aq(s, a_example$12, s.$lvl, "This is the description of the first level"));
}
cs.registerStep(a_example$11, 'a_example$11');

function a_example$12(s) {
  (s.pc = "4.A78.");
  return s.rt.enter(a_abOWAkFdJLtkXvCwDz9Uucwc(s, a_example$13, s.$lvl, true));
}
cs.registerStep(a_example$12, 'a_example$12');

function a_example$13(s) {
  (s.pc = "4.A82.");
  return s.rt.enter(a_kyM6BKxra6FMoP8AENJbQMGs(s, a_example$14, s.$lvl));
}
cs.registerStep(a_example$13, 'a_example$13');

function a_example$14(s) {
  var t_actRes_8 = s.rt.returnedFrom.result;
  var t_call_9 = lib.Colors.red(s);
  return s.rt.enter(a_xOGMqFGX0oajGlVqWyq6ciVg(s, a_example$15, t_actRes_8, t_call_9));
}
cs.registerStep(a_example$14, 'a_example$14');

function a_example$15(s) {
  return s.rt.leave();
}
cs.registerStep(a_example$15, 'a_example$15');

/* ACTION: a_example::lambda::1 */
function a_a_example$1(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_example$1$0;
  s.name = "example";
  return s;
}
cs.registerLambda("a_example\u003a\u003alambda\u003a\u003a1", "a_example$1", a_a_example$1, true);

function a_a_example$1$0(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_example$1$0, 'a_a_example$1$0');

/* ACTION: initialize */
function a_initialize(previous, returnAddr, $title, $subtitle, $level_count, $start_level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_initialize$0;
  s.name = "initialize";
  s.$title = $title;
  s.$subtitle = $subtitle;
  s.$level_count = $level_count;
  s.$start_level = $start_level;
  s.$i = undefined;
  return s;
}
cs.registerAction("initialize", "initialize", a_initialize, false);

function a_initialize$0(s) {
  (s.pc = "4.F1");
  var t_infix_0 = (ok1(s, s.$level_count) && (s.$level_count > 0));
  (ok1(s, t_infix_0) && lib.Contract.requires(t_infix_0, "game must have at least one level", s));
  (s.pc = "4.F4");
  return s.rt.enter(a_TuvYc3CSeDzlxw7k4r66Yrcb(s, a_initialize$1));
}
cs.registerStep(a_initialize$0, 'a_initialize$0');

function a_initialize$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  (/* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N = t_actRes_1);
  s.rt.logDataWrite();
  (s.pc = "4.F7");
  return s.rt.enter(a_TuvYc3CSeDzlxw7k4r66Yrcb(s, a_initialize$2));
}
cs.registerStep(a_initialize$1, 'a_initialize$1');

function a_initialize$2(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  (/* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V = t_actRes_2);
  s.rt.logDataWrite();
  (s.pc = "4.Fa");
  var t_call_3 = lib.Colors.blue(s);
  if (/* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V) {
  /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V.perform_set("xB8gTd6eYdzIepWazYoNI284", t_call_3, s);
  }
  (s.pc = "4.Fd");
  var t_call_4 = lib.Colors.white(s);
  if (/* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V) {
  /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V.perform_set("xePTIfIYg4fJ3yUz2Cv0ucfs", t_call_4, s);
  }
  (s.pc = "4.Fg");
  var t_call_5 = (ok1(s, s.$level_count) && lib.Math_.ceiling(s.$level_count, s));
  var t_call_6 = (ok1(s, t_call_5) && lib.Math_.max(1, t_call_5, s));
  (/* _level count */ s.d.$levelcount = t_call_6);
  s.rt.logDataWrite();
  (s.pc = "4.Fj");
  (/* _title */ s.d.$Puz9SxF3xc92nwYRLTnhhcli = s.$title);
  s.rt.logDataWrite();
  (s.pc = "4.Fm");
  (/* _subtitle */ s.d.$I51gPgcwfFqs55JGIhivi2xz = s.$subtitle);
  s.rt.logDataWrite();
  (s.pc = "4.Fp");
  (/* _start level action */ s.d.$lJMupn7S4c2MRWeFYgzYI3sM = s.$start_level);
  s.rt.logDataWrite();
  (s.pc = "4.Fs");
  (/* _level selection */ s.d.$xNNKA4FtL05eZdMpVoUDEmtz = true);
  s.rt.logDataWrite();
  (s.pc = "4.Fw");
  return s.rt.enter(a_uIQCNem1kvZBE4J6UHoWPCK1(s, a_initialize$5, 1));
}
cs.registerStep(a_initialize$2, 'a_initialize$2');

function a_initialize$5(s) {
  var t_actRes_7 = s.rt.returnedFrom.result;
  if (t_actRes_7) {
  t_actRes_7.perform_set("qhCetiH2Bj2wrY6fz4oObZF5", true, s);
  }
  (s.pc = "4.Fz");
  s.t_bnd_8 = /* _level count */ s.d.$levelcount;
  (s.$i = 0);
  return a_initialize$7;
}
cs.registerStep(a_initialize$5, 'a_initialize$5');

function a_initialize$7(s) {
  if ((s.$i < s.t_bnd_8)) {
  (s.pc = "4.FD0");
  return s.rt.enter(a_TuvYc3CSeDzlxw7k4r66Yrcb(s, a_initialize$9));
  }
  return s.rt.leave();
}
cs.registerStep(a_initialize$7, 'a_initialize$7');

function a_initialize$9(s) {
  var t_actRes_9 = s.rt.returnedFrom.result;
  var t_infix_10 = (ok1(s, s.$i) && (s.$i + 1));
  var t_call_11 = (ok2(s, /* level theme index */ s.d.$BdGhpbmca, t_infix_10) && /* level theme index */ s.d.$BdGhpbmca.at(t_infix_10, s));
  if (t_call_11) {
  t_call_11.perform_set("T7dTa1GYk6ojgTI0G2RprFyk", t_actRes_9, s);
  }
  (s.$i++);
  return a_initialize$7;
}
cs.registerStep(a_initialize$9, 'a_initialize$9');

/* ACTION: start game */
function a_startgame(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_startgame$0;
  s.name = "start game";
  s.$level = $level;
  s.$action = undefined;
  return s;
}
cs.registerAction("start game", "startgame", a_startgame, true);

function a_startgame$0(s) {
  (s.pc = "4.K0");
  var t_call_0 = lib.Wall.push_new_page(s);
  t_call_0;
  (s.pc = "4.K3");
  return s.rt.enter(a_stylepage(s, a_startgame$1));
}
cs.registerStep(a_startgame$0, 'a_startgame$0');

function a_startgame$1(s) {
  (s.pc = "4.K6");
  var t_libcall_1 = s.libs["game"]["reset"](s);
  return s.rt.enter(t_libcall_1.invoke(t_libcall_1, a_startgame$2));
}
cs.registerStep(a_startgame$1, 'a_startgame$1');

function a_startgame$2(s) {
  (s.pc = "4.Kd0");
  var t_lmbv_2 = s.$level;
  var t_lmbProxy_3 = s.libs.mkLambdaProxy;
  (s.$action = function(la0, la1) { return a_a_startgame$3(t_lmbProxy_3(la0), la1, t_lmbv_2) });
  (s.pc = "4.K9");
  var t_libcall_4 = s.libs["game"]["on end"](s);
  return s.rt.enter(t_libcall_4.invoke(t_libcall_4, a_startgame$4, s.$action));
}
cs.registerStep(a_startgame$2, 'a_startgame$2');

function a_startgame$4(s) {
  (s.pc = "4.Kd");
  return s.rt.enter((ok1(s, /* _start level action */ s.d.$lJMupn7S4c2MRWeFYgzYI3sM) && /* _start level action */ s.d.$lJMupn7S4c2MRWeFYgzYI3sM(s, a_startgame$5, s.$level)));
}
cs.registerStep(a_startgame$4, 'a_startgame$4');

function a_startgame$5(s) {
  return s.rt.leave();
}
cs.registerStep(a_startgame$5, 'a_startgame$5');

/* ACTION: a_startgame::lambda::3 */
function a_a_startgame$3(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_startgame$3$0;
  s.name = "start game";
  s.$level = $level;
  return s;
}
cs.registerLambda("a_startgame\u003a\u003alambda\u003a\u003a3", "a_startgame$3", a_a_startgame$3, true);

function a_a_startgame$3$0(s) {
  (s.pc = "4.Kd20");
  return s.rt.enter(a_ongameend(s, a_a_startgame$3$1, s.$level));
}
cs.registerStep(a_a_startgame$3$0, 'a_a_startgame$3$0');

function a_a_startgame$3$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  t_actRes_0;
  return s.rt.leave();
}
cs.registerStep(a_a_startgame$3$1, 'a_a_startgame$3$1');

/* ACTION: show level details */
function a_leveldetails(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_leveldetails$0;
  s.name = "show level details";
  s.$_ = undefined;
  s.$level = $level;
  s.$sc = undefined;
  s.$handler = undefined;
  s.$next = undefined;
  s.$handler1 = undefined;
  return s;
}
cs.registerPage("show level details", "leveldetails", a_leveldetails, false);

function a_leveldetails$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.P0");
  var t_call_1 = lib.Box.is_init(s);
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.rt.getCurrentPage().model = s.d.$BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.create(s));
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.P40");
  return s.rt.enter(a_stylepage(s, a_leveldetails$2));
  } else {
  (s.pc = "4.P50");
  null;
  }
  return a_leveldetails$1;
}
cs.registerStep(a_leveldetails$0, 'a_leveldetails$0');

function a_leveldetails$2(s) {
  return a_leveldetails$1;
}
cs.registerStep(a_leveldetails$2, 'a_leveldetails$2');

function a_leveldetails$1(s) {
  var t_elseIf_2 = true;
  (s.pc = "4.P5");
  true;
  if (true) {
  s.rt.enter_render();
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.P90");
  lib.Box.push_box(s);
  (s.pc = "4.P920");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.P923");
  lib.Box.set_vertical_align("center", s);
  (s.pc = "4.P926");
  lib.Box.set_vertical_stretch(1, s);
  (s.pc = "4.P929");
  lib.Box.set_horizontal_stretch(1, s);
  (s.pc = "4.P92c");
  lib.Box.push_box(s);
  (s.pc = "4.P92e0");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.P92e3");
  lib.Box.push_box(s);
  (s.pc = "4.P92e50");
  lib.String_.post_to_wall("level", s);
  lib.Box.pop_box(s);
  (s.pc = "4.P92e5");
  lib.Box.push_box(s);
  (s.pc = "4.P92e70");
  lib.Box.set_font_size(8, s);
  (s.pc = "4.P92e73");
  (ok1(s, (ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")])) && lib.Number_.post_to_wall((ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")]), s));
  lib.Box.pop_box(s);
  var t_elseIf_3 = true;
  (s.pc = "4.P92e7");
  if (s.$level) {
  var t_recOp_4 = s.$level.perform_get("FcypXS06YlmK2KAQ327sEovl", s);
  }
  var t_call_5 = (ok1(s, t_recOp_4) && lib.String_.is_empty(t_recOp_4, s));
  var t_call_6 = (ok1(s, t_call_5) && lib.Boolean_.not(t_call_5, s));
  ok1(s, t_call_6);
  if (t_call_6) {
  (s.pc = "4.P92eb0");
  lib.Box.push_box(s);
  (s.pc = "4.P92eb20");
  lib.Box.set_width(21, s);
  (s.pc = "4.P92eb23");
  lib.Box.set_font_size(0.8, s);
  (s.pc = "4.P92eb26");
  lib.Box.set_text_wrapping(true, 15, s);
  (s.pc = "4.P92eb29");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.P92eb2c");
  if (s.$level) {
  var t_recOp_7 = s.$level.perform_get("FcypXS06YlmK2KAQ327sEovl", s);
  }
  (ok1(s, t_recOp_7) && lib.String_.post_to_wall(t_recOp_7, s));
  lib.Box.pop_box(s);
  } else {
  (s.pc = "4.P92ec0");
  null;
  }
  (s.pc = "4.P92ec");
  return s.rt.enter(a_g5G6V1r466rXedV0GC2DdMLq(s, a_leveldetails$7, s.$level));
  } else {
  (s.pc = "4.Pa0");
  null;
  }
  return a_leveldetails$3;
}
cs.registerStep(a_leveldetails$1, 'a_leveldetails$1');

function a_leveldetails$7(s) {
  var t_actRes_8 = s.rt.returnedFrom.result;
  (s.$sc = t_actRes_8);
  var t_elseIf_9 = true;
  (s.pc = "4.P92ef");
  var t_infix_10 = (ok1(s, s.$sc) && (s.$sc > 0));
  ok1(s, t_infix_10);
  if (t_infix_10) {
  (s.pc = "4.P92ej0");
  lib.Box.push_box(s);
  (s.pc = "4.P92ej20");
  lib.Box.set_font_size(2, s);
  (s.pc = "4.P92ej23");
  var t_concat_11 = lib.String_.concatAny("score\u003a ", s.$sc);
  (ok1(s, t_concat_11) && lib.String_.post_to_wall(t_concat_11, s));
  lib.Box.pop_box(s);
  } else {
  (s.pc = "4.P92ek0");
  null;
  }
  var t_elseIf_12 = true;
  (s.pc = "4.P92ek");
  if (s.$level) {
  var t_recOp_13 = s.$level.perform_get("qod2mWVTq0MtY6ZGt7IA6uUe", s);
  }
  var t_infix_14 = (ok1(s, t_recOp_13) && (t_recOp_13 > 0));
  ok1(s, t_infix_14);
  if (t_infix_14) {
  (s.pc = "4.P92eo0");
  lib.Box.push_box(s);
  (s.pc = "4.P92eo20");
  lib.Box.set_margins(0.5, 0, 0, 0, s);
  (s.pc = "4.P92eo23");
  return s.rt.enter(a_syCJwBkyr1jcu3Z9uQnocktT(s, a_leveldetails$11, s.$level, 21, 3));
  } else {
  (s.pc = "4.P92ep0");
  null;
  }
  return a_leveldetails$10;
}
cs.registerStep(a_leveldetails$7, 'a_leveldetails$7');

function a_leveldetails$3(s) {
  return s.rt.leave();
}
cs.registerStep(a_leveldetails$3, 'a_leveldetails$3');

function a_leveldetails$11(s) {
  lib.Box.pop_box(s);
  return a_leveldetails$10;
}
cs.registerStep(a_leveldetails$11, 'a_leveldetails$11');

function a_leveldetails$10(s) {
  (s.pc = "4.P92ep");
  lib.Box.push_box(s);
  (s.pc = "4.P92er0");
  lib.Box.use_horizontal_layout(s);
  (s.pc = "4.P92er3");
  lib.Box.push_box(s);
  (s.pc = "4.P92er50");
  lib.Box.set_margins(1.5, 1, 1, 1, s);
  (s.pc = "4.P92er53");
  lib.Box.set_padding(0.5, 4, 0.5, 4, s);
  (s.pc = "4.P92er56");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.P92er59");
  lib.Box.set_vertical_align("center", s);
  (s.pc = "4.P92er5c");
  return s.rt.enter(a_Rqqe3CxvoK7XWqNZh9kQWX7G(s, a_leveldetails$12, /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V));
}
cs.registerStep(a_leveldetails$10, 'a_leveldetails$10');

function a_leveldetails$12(s) {
  (s.pc = "4.P92er5f");
  var t_call_15 = lib.Colors.white(s);
  (ok1(s, t_call_15) && lib.Box.set_foreground(t_call_15, s));
  (s.pc = "4.P92er5i");
  lib.Box.set_font_size(2, s);
  (s.pc = "4.P92er5l");
  lib.Box.set_height(4, s);
  (s.pc = "4.P92er5s0");
  var t_lmbv_16 = s.$level;
  var t_lmbProxy_17 = s.libs.mkLambdaProxy;
  (s.$handler = function(la0, la1) { return a_a_leveldetails$13(t_lmbProxy_17(la0), la1, t_lmbv_16) });
  (s.pc = "4.P92er5o");
  (ok1(s, s.$handler) && lib.Box.on_tapped(s.$handler, s));
  (s.pc = "4.P92er5s");
  lib.Box.push_box(s);
  (s.pc = "4.P92er5u0");
  lib.String_.post_to_wall("play", s);
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  var t_elseIf_18 = true;
  (s.pc = "4.P92er5");
  var t_infix_19 = (ok1(s, (ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")])) && ((ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")]) + 1));
  var t_infix_20 = (ok2(s, t_infix_19, /* _level count */ s.d.$levelcount) && (t_infix_19 <= /* _level count */ s.d.$levelcount));
  s.t_lazy_21 = t_infix_20;
  if ((ok1(s, s.t_lazy_21) && s.t_lazy_21)) {
  return s.rt.enter(a_v1ibFfse8BhlXhYDaC3Wh2fN(s, a_leveldetails$15, s.$level));
  }
  return a_leveldetails$14;
}
cs.registerStep(a_leveldetails$12, 'a_leveldetails$12');

function a_leveldetails$15(s) {
  var t_actRes_22 = s.rt.returnedFrom.result;
  if (t_actRes_22) {
  var t_recOp_23 = t_actRes_22.perform_get("qhCetiH2Bj2wrY6fz4oObZF5", s);
  }
  (s.t_lazy_21 = t_recOp_23);
  return a_leveldetails$14;
}
cs.registerStep(a_leveldetails$15, 'a_leveldetails$15');

function a_leveldetails$14(s) {
  ok1(s, s.t_lazy_21);
  if (s.t_lazy_21) {
  (s.pc = "4.P92er90");
  return s.rt.enter(a_v1ibFfse8BhlXhYDaC3Wh2fN(s, a_leveldetails$18, s.$level));
  } else {
  (s.pc = "4.P92era0");
  null;
  }
  return a_leveldetails$17;
}
cs.registerStep(a_leveldetails$14, 'a_leveldetails$14');

function a_leveldetails$18(s) {
  var t_actRes_24 = s.rt.returnedFrom.result;
  (s.$next = t_actRes_24);
  (s.pc = "4.P92er93");
  lib.Box.push_box(s);
  (s.pc = "4.P92er950");
  lib.Box.set_margins(1.5, 1, 1, 1, s);
  (s.pc = "4.P92er953");
  lib.Box.set_padding(0.5, 4, 0.5, 4, s);
  (s.pc = "4.P92er956");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.P92er959");
  lib.Box.set_vertical_align("center", s);
  (s.pc = "4.P92er95c");
  return s.rt.enter(a_Rqqe3CxvoK7XWqNZh9kQWX7G(s, a_leveldetails$19, /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V));
}
cs.registerStep(a_leveldetails$18, 'a_leveldetails$18');

function a_leveldetails$17(s) {
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  s.rt.leave_render();
  return a_leveldetails$3;
}
cs.registerStep(a_leveldetails$17, 'a_leveldetails$17');

function a_leveldetails$19(s) {
  (s.pc = "4.P92er95f");
  var t_call_25 = lib.Colors.white(s);
  (ok1(s, t_call_25) && lib.Box.set_foreground(t_call_25, s));
  (s.pc = "4.P92er95i");
  lib.Box.set_font_size(2, s);
  (s.pc = "4.P92er95l");
  lib.Box.set_height(4, s);
  (s.pc = "4.P92er95s0");
  var t_lmbv_26 = s.$next;
  var t_lmbProxy_27 = s.libs.mkLambdaProxy;
  (s.$handler1 = function(la0, la1) { return a_a_leveldetails$20(t_lmbProxy_27(la0), la1, t_lmbv_26) });
  (s.pc = "4.P92er95o");
  (ok1(s, s.$handler1) && lib.Box.on_tapped(s.$handler1, s));
  (s.pc = "4.P92er95s");
  lib.Box.push_box(s);
  (s.pc = "4.P92er95u0");
  lib.String_.post_to_wall("next level", s);
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  return a_leveldetails$17;
}
cs.registerStep(a_leveldetails$19, 'a_leveldetails$19');

/* ACTION: a_leveldetails::lambda::13 */
function a_a_leveldetails$13(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_leveldetails$13$0;
  s.name = "show level details";
  s.$level = $level;
  return s;
}
cs.registerLambda("a_leveldetails\u003a\u003alambda\u003a\u003a13", "a_leveldetails$13", a_a_leveldetails$13, true);

function a_a_leveldetails$13$0(s) {
  (s.pc = "4.P92er5s20");
  return s.rt.enter(a_startgame(s, a_a_leveldetails$13$1, s.$level));
}
cs.registerStep(a_a_leveldetails$13$0, 'a_a_leveldetails$13$0');

function a_a_leveldetails$13$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  t_actRes_0;
  return s.rt.leave();
}
cs.registerStep(a_a_leveldetails$13$1, 'a_a_leveldetails$13$1');

/* ACTION: a_leveldetails::lambda::20 */
function a_a_leveldetails$20(previous, returnAddr, $next) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_leveldetails$20$0;
  s.name = "show level details";
  s.$next = $next;
  return s;
}
cs.registerLambda("a_leveldetails\u003a\u003alambda\u003a\u003a20", "a_leveldetails$20", a_a_leveldetails$20, true);

function a_a_leveldetails$20$0(s) {
  (s.pc = "4.P92er95s21");
  var t_call_0 = lib.Wall.pop_page(s);
  t_call_0;
  (s.pc = "4.P92er95s25");
  return s.rt.enter(a_hkrBuHpdV719LOBB6mZewhJD(s, a_a_leveldetails$20$1, s.$next));
}
cs.registerStep(a_a_leveldetails$20$0, 'a_a_leveldetails$20$0');

function a_a_leveldetails$20$1(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  t_actRes_1;
  return s.rt.leave();
}
cs.registerStep(a_a_leveldetails$20$1, 'a_a_leveldetails$20$1');


//Ent_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa
function Ent_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa(p) {
  this.parent = p;
}
Ent_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype = new lib.ObjectEntry();
Ent_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype.keys = [];
Ent_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype.values = [];
Ent_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype.fields = [];
//Col_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa
function Col_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype = lib.RecordCollection.prototype;
//Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa
function Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa(l) {
  this.libName = l;
  this.initParent();
}
Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype = new lib.ObjectSingleton();
Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype.entryCtor = Ent_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa;
Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype.selfCtor = Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa;
Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype.collectionCtor = Col_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa;
Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype.stableName = "BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa";
Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype.entryKindName = "show level details page data";

// jsonimport
Ent_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
}
cs.registerGlobal("$BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa");
/* ACTION: set credits */
function a_vEMbt6oeR6yVzubwR225d5o2(previous, returnAddr, $credits) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_vEMbt6oeR6yVzubwR225d5o2$0;
  s.name = "set credits";
  s.$credits = $credits;
  return s;
}
cs.registerAction("set credits", "vEMbt6oeR6yVzubwR225d5o2", a_vEMbt6oeR6yVzubwR225d5o2, false);

function a_vEMbt6oeR6yVzubwR225d5o2$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_vEMbt6oeR6yVzubwR225d5o2$2, lib.RTValue.mkPicker(lib.String_.picker(), "", "credits", "$credits"));
  return a_vEMbt6oeR6yVzubwR225d5o2$2;
  }
  return a_vEMbt6oeR6yVzubwR225d5o2$1;
}
cs.registerStep(a_vEMbt6oeR6yVzubwR225d5o2$0, 'a_vEMbt6oeR6yVzubwR225d5o2$0');

function a_vEMbt6oeR6yVzubwR225d5o2$2(s) {
  return a_vEMbt6oeR6yVzubwR225d5o2$1;
}
cs.registerStep(a_vEMbt6oeR6yVzubwR225d5o2$2, 'a_vEMbt6oeR6yVzubwR225d5o2$2');

function a_vEMbt6oeR6yVzubwR225d5o2$1(s) {
  (s.pc = "4.X1");
  (/* _credits */ s.d.$qTILdrMWpOE7W6v8fyiOqO8E = s.$credits);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_vEMbt6oeR6yVzubwR225d5o2$1, 'a_vEMbt6oeR6yVzubwR225d5o2$1');

/* ACTION: show leaderboard button */
function a_XNqQQCzJZlGV2I6w0FE2aVvf(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_XNqQQCzJZlGV2I6w0FE2aVvf$0;
  s.name = "show leaderboard button";
  s.$handler = undefined;
  return s;
}
cs.registerAction("show leaderboard button", "XNqQQCzJZlGV2I6w0FE2aVvf", a_XNqQQCzJZlGV2I6w0FE2aVvf, false);

function a_XNqQQCzJZlGV2I6w0FE2aVvf$0(s) {
  (s.pc = "4.65.0");
  lib.Box.push_box(s);
  (s.pc = "4.65.20");
  lib.Box.set_margins(0, 1, 1, 1, s);
  (s.pc = "4.65.23");
  lib.Box.set_width(10, s);
  (s.pc = "4.65.26");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.65.29");
  return s.rt.enter(a_Rqqe3CxvoK7XWqNZh9kQWX7G(s, a_XNqQQCzJZlGV2I6w0FE2aVvf$1, /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V));
}
cs.registerStep(a_XNqQQCzJZlGV2I6w0FE2aVvf$0, 'a_XNqQQCzJZlGV2I6w0FE2aVvf$0');

function a_XNqQQCzJZlGV2I6w0FE2aVvf$1(s) {
  (s.pc = "4.65.2c");
  lib.Box.set_padding(0.5, 2, 0.5, 2, s);
  (s.pc = "4.65.2j0");
  var t_lmbProxy_0 = s.libs.mkLambdaProxy;
  (s.$handler = function(la0, la1) { return a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2(t_lmbProxy_0(la0), la1) });
  (s.pc = "4.65.2f");
  (ok1(s, s.$handler) && lib.Box.on_tapped(s.$handler, s));
  (s.pc = "4.65.2j");
  lib.Box.push_box(s);
  (s.pc = "4.65.2l0");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.65.2l3");
  lib.Box.set_font_size(1, s);
  (s.pc = "4.65.2l6");
  var t_call_1 = lib.Colors.white(s);
  (ok1(s, t_call_1) && lib.Box.set_foreground(t_call_1, s));
  (s.pc = "4.65.2l9");
  lib.String_.post_to_wall("leaderboards", s);
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  return s.rt.leave();
}
cs.registerStep(a_XNqQQCzJZlGV2I6w0FE2aVvf$1, 'a_XNqQQCzJZlGV2I6w0FE2aVvf$1');

/* ACTION: a_XNqQQCzJZlGV2I6w0FE2aVvf::lambda::2 */
function a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$0;
  s.name = "show leaderboard button";
  return s;
}
cs.registerLambda("a_XNqQQCzJZlGV2I6w0FE2aVvf\u003a\u003alambda\u003a\u003a2", "a_XNqQQCzJZlGV2I6w0FE2aVvf$2", a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2, true);

function a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$0(s) {
  (s.pc = "4.65.2j20");
  var t_call_0 = lib.Wall.push_new_page(s);
  t_call_0;
  (s.pc = "4.65.2j23");
  return s.rt.enter(a_stylepage(s, a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$1));
}
cs.registerStep(a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$0, 'a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$0');

function a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$1(s) {
  (s.pc = "4.65.2j26");
  lib.Wall.set_title("leaderboards", s);
  (s.pc = "4.65.2j29");
  var t_resumeCtx_1 = s.rt.getBlockingResumeCtx(a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$2);
  lib.Bazaar.post_leaderboard_to_wall(t_resumeCtx_1);
  return a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$2;
}
cs.registerStep(a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$1, 'a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$1');

function a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$2(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$2, 'a_a_XNqQQCzJZlGV2I6w0FE2aVvf$2$2');

/* ACTION: show start button */
function a_mqb129Wh4dEV1uyHJF1oS5IJ(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_mqb129Wh4dEV1uyHJF1oS5IJ$0;
  s.name = "show start button";
  s.$handler = undefined;
  return s;
}
cs.registerAction("show start button", "mqb129Wh4dEV1uyHJF1oS5IJ", a_mqb129Wh4dEV1uyHJF1oS5IJ, false);

function a_mqb129Wh4dEV1uyHJF1oS5IJ$0(s) {
  (s.pc = "4.70.0");
  lib.Box.push_box(s);
  (s.pc = "4.70.20");
  lib.Box.set_margins(2.5, 1, 1.5, 1, s);
  (s.pc = "4.70.23");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.70.26");
  return s.rt.enter(a_Rqqe3CxvoK7XWqNZh9kQWX7G(s, a_mqb129Wh4dEV1uyHJF1oS5IJ$1, /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V));
}
cs.registerStep(a_mqb129Wh4dEV1uyHJF1oS5IJ$0, 'a_mqb129Wh4dEV1uyHJF1oS5IJ$0');

function a_mqb129Wh4dEV1uyHJF1oS5IJ$1(s) {
  (s.pc = "4.70.29");
  lib.Box.set_padding(0.5, 4, 0.5, 4, s);
  (s.pc = "4.70.2g0");
  var t_lmbProxy_0 = s.libs.mkLambdaProxy;
  (s.$handler = function(la0, la1) { return a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2(t_lmbProxy_0(la0), la1) });
  (s.pc = "4.70.2c");
  (ok1(s, s.$handler) && lib.Box.on_tapped(s.$handler, s));
  (s.pc = "4.70.2g");
  lib.Box.push_box(s);
  (s.pc = "4.70.2i0");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.70.2i3");
  lib.Box.set_font_size(2, s);
  (s.pc = "4.70.2i6");
  var t_call_1 = lib.Colors.white(s);
  (ok1(s, t_call_1) && lib.Box.set_foreground(t_call_1, s));
  (s.pc = "4.70.2i9");
  lib.String_.post_to_wall("start", s);
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  return s.rt.leave();
}
cs.registerStep(a_mqb129Wh4dEV1uyHJF1oS5IJ$1, 'a_mqb129Wh4dEV1uyHJF1oS5IJ$1');

/* ACTION: a_mqb129Wh4dEV1uyHJF1oS5IJ::lambda::2 */
function a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$0;
  s.name = "show start button";
  return s;
}
cs.registerLambda("a_mqb129Wh4dEV1uyHJF1oS5IJ\u003a\u003alambda\u003a\u003a2", "a_mqb129Wh4dEV1uyHJF1oS5IJ$2", a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2, true);

function a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.70.2g20");
  ok1(s, /* _level selection */ s.d.$xNNKA4FtL05eZdMpVoUDEmtz);
  if (/* _level selection */ s.d.$xNNKA4FtL05eZdMpVoUDEmtz) {
  (s.pc = "4.70.2g240");
  s.rt.forceNonRender();
  s.rt.forcePageRefresh();
  s.rt.postAutoPage(s.d.libName, "show level selection");
  } else {
  (s.pc = "4.70.2g250");
  return s.rt.enter(a_XT6yz9vjh6Ci02AGh2Y9e9pe(s, a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$2));
  }
  return a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$1;
}
cs.registerStep(a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$0, 'a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$0');

function a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$2(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  s.rt.forceNonRender();
  s.rt.forcePageRefresh();
  s.rt.postAutoPage(s.d.libName, "show level details", t_actRes_1);
  return a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$1;
}
cs.registerStep(a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$2, 'a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$2');

function a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$1, 'a_a_mqb129Wh4dEV1uyHJF1oS5IJ$2$1');

/* ACTION: show titles */
function a_QHP9ho2IGjrPxqq9F80pZmqj(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_QHP9ho2IGjrPxqq9F80pZmqj$0;
  s.name = "show titles";
  return s;
}
cs.registerAction("show titles", "QHP9ho2IGjrPxqq9F80pZmqj", a_QHP9ho2IGjrPxqq9F80pZmqj, false);

function a_QHP9ho2IGjrPxqq9F80pZmqj$0(s) {
  (s.pc = "4.75.0");
  lib.Box.push_box(s);
  (s.pc = "4.75.20");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.75.23");
  lib.Box.set_text_wrapping(true, 15, s);
  (s.pc = "4.75.26");
  lib.Box.set_font_size(4, s);
  (s.pc = "4.75.29");
  (ok1(s, /* _title */ s.d.$Puz9SxF3xc92nwYRLTnhhcli) && lib.String_.post_to_wall(/* _title */ s.d.$Puz9SxF3xc92nwYRLTnhhcli, s));
  lib.Box.pop_box(s);
  var t_elseIf_0 = true;
  (s.pc = "4.75.2");
  var t_call_1 = (ok1(s, /* _subtitle */ s.d.$I51gPgcwfFqs55JGIhivi2xz) && lib.String_.is_empty(/* _subtitle */ s.d.$I51gPgcwfFqs55JGIhivi2xz, s));
  var t_call_2 = (ok1(s, t_call_1) && lib.Boolean_.not(t_call_1, s));
  ok1(s, t_call_2);
  if (t_call_2) {
  (s.pc = "4.75.60");
  lib.Box.push_box(s);
  (s.pc = "4.75.620");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.75.623");
  lib.Box.set_text_wrapping(true, 15, s);
  (s.pc = "4.75.626");
  lib.Box.set_font_size(1, s);
  (s.pc = "4.75.629");
  (ok1(s, /* _subtitle */ s.d.$I51gPgcwfFqs55JGIhivi2xz) && lib.String_.post_to_wall(/* _subtitle */ s.d.$I51gPgcwfFqs55JGIhivi2xz, s));
  lib.Box.pop_box(s);
  } else {
  (s.pc = "4.75.70");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_QHP9ho2IGjrPxqq9F80pZmqj$0, 'a_QHP9ho2IGjrPxqq9F80pZmqj$0');

/* ACTION: show credits button */
function a_VBoM3w1YjF9BzIB6ry8gv2PO(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_VBoM3w1YjF9BzIB6ry8gv2PO$0;
  s.name = "show credits button";
  s.$handler = undefined;
  return s;
}
cs.registerAction("show credits button", "VBoM3w1YjF9BzIB6ry8gv2PO", a_VBoM3w1YjF9BzIB6ry8gv2PO, false);

function a_VBoM3w1YjF9BzIB6ry8gv2PO$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.80.0");
  var t_call_1 = (ok1(s, /* _credits */ s.d.$qTILdrMWpOE7W6v8fyiOqO8E) && lib.String_.is_empty(/* _credits */ s.d.$qTILdrMWpOE7W6v8fyiOqO8E, s));
  var t_call_2 = (ok1(s, t_call_1) && lib.Boolean_.not(t_call_1, s));
  ok1(s, t_call_2);
  if (t_call_2) {
  (s.pc = "4.80.40");
  lib.Box.push_box(s);
  (s.pc = "4.80.420");
  lib.Box.set_margins(1, 1, 1, 1, s);
  (s.pc = "4.80.423");
  lib.Box.set_width(10, s);
  (s.pc = "4.80.426");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.80.429");
  return s.rt.enter(a_Rqqe3CxvoK7XWqNZh9kQWX7G(s, a_VBoM3w1YjF9BzIB6ry8gv2PO$2, /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V));
  } else {
  (s.pc = "4.80.50");
  null;
  }
  return a_VBoM3w1YjF9BzIB6ry8gv2PO$1;
}
cs.registerStep(a_VBoM3w1YjF9BzIB6ry8gv2PO$0, 'a_VBoM3w1YjF9BzIB6ry8gv2PO$0');

function a_VBoM3w1YjF9BzIB6ry8gv2PO$2(s) {
  (s.pc = "4.80.42c");
  lib.Box.set_padding(0.5, 2, 0.5, 2, s);
  (s.pc = "4.80.42j0");
  var t_lmbProxy_3 = s.libs.mkLambdaProxy;
  (s.$handler = function(la0, la1) { return a_a_VBoM3w1YjF9BzIB6ry8gv2PO$3(t_lmbProxy_3(la0), la1) });
  (s.pc = "4.80.42f");
  (ok1(s, s.$handler) && lib.Box.on_tapped(s.$handler, s));
  (s.pc = "4.80.42j");
  lib.Box.push_box(s);
  (s.pc = "4.80.42l0");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.80.42l3");
  lib.Box.set_font_size(0.7, s);
  (s.pc = "4.80.42l6");
  var t_call_4 = lib.Colors.white(s);
  (ok1(s, t_call_4) && lib.Box.set_foreground(t_call_4, s));
  (s.pc = "4.80.42l9");
  lib.String_.post_to_wall("credits", s);
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  return a_VBoM3w1YjF9BzIB6ry8gv2PO$1;
}
cs.registerStep(a_VBoM3w1YjF9BzIB6ry8gv2PO$2, 'a_VBoM3w1YjF9BzIB6ry8gv2PO$2');

function a_VBoM3w1YjF9BzIB6ry8gv2PO$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_VBoM3w1YjF9BzIB6ry8gv2PO$1, 'a_VBoM3w1YjF9BzIB6ry8gv2PO$1');

/* ACTION: a_VBoM3w1YjF9BzIB6ry8gv2PO::lambda::3 */
function a_a_VBoM3w1YjF9BzIB6ry8gv2PO$3(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_VBoM3w1YjF9BzIB6ry8gv2PO$3$0;
  s.name = "show credits button";
  return s;
}
cs.registerLambda("a_VBoM3w1YjF9BzIB6ry8gv2PO\u003a\u003alambda\u003a\u003a3", "a_VBoM3w1YjF9BzIB6ry8gv2PO$3", a_a_VBoM3w1YjF9BzIB6ry8gv2PO$3, true);

function a_a_VBoM3w1YjF9BzIB6ry8gv2PO$3$0(s) {
  (s.pc = "4.80.42j20");
  s.rt.forceNonRender();
  s.rt.forcePageRefresh();
  s.rt.postAutoPage(s.d.libName, "show credits");
  return s.rt.leave();
}
cs.registerStep(a_a_VBoM3w1YjF9BzIB6ry8gv2PO$3$0, 'a_a_VBoM3w1YjF9BzIB6ry8gv2PO$3$0');

/* ACTION: show credits */
function a_iajDu749O2HH5AG4pth9fr7D(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_iajDu749O2HH5AG4pth9fr7D$0;
  s.name = "show credits";
  s.$_ = undefined;
  return s;
}
cs.registerPage("show credits", "iajDu749O2HH5AG4pth9fr7D", a_iajDu749O2HH5AG4pth9fr7D, false);

function a_iajDu749O2HH5AG4pth9fr7D$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.85.0");
  var t_call_1 = lib.Box.is_init(s);
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.rt.getCurrentPage().model = s.d.$BICBuYW1lICAa.create(s));
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.85.40");
  return s.rt.enter(a_stylepage(s, a_iajDu749O2HH5AG4pth9fr7D$2));
  } else {
  (s.pc = "4.85.50");
  null;
  }
  return a_iajDu749O2HH5AG4pth9fr7D$1;
}
cs.registerStep(a_iajDu749O2HH5AG4pth9fr7D$0, 'a_iajDu749O2HH5AG4pth9fr7D$0');

function a_iajDu749O2HH5AG4pth9fr7D$2(s) {
  (s.pc = "4.85.43");
  lib.Wall.set_subtitle("credits", s);
  return a_iajDu749O2HH5AG4pth9fr7D$1;
}
cs.registerStep(a_iajDu749O2HH5AG4pth9fr7D$2, 'a_iajDu749O2HH5AG4pth9fr7D$2');

function a_iajDu749O2HH5AG4pth9fr7D$1(s) {
  var t_elseIf_2 = true;
  (s.pc = "4.85.5");
  true;
  if (true) {
  s.rt.enter_render();
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.85.90");
  lib.Box.push_box(s);
  (s.pc = "4.85.920");
  lib.Box.set_margins(2, 2, 2, 2, s);
  (s.pc = "4.85.923");
  (ok1(s, /* _credits */ s.d.$qTILdrMWpOE7W6v8fyiOqO8E) && lib.String_.post_to_wall(/* _credits */ s.d.$qTILdrMWpOE7W6v8fyiOqO8E, s));
  lib.Box.pop_box(s);
  (s.pc = "4.85.92");
  null;
  s.rt.leave_render();
  } else {
  (s.pc = "4.85.a0");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_iajDu749O2HH5AG4pth9fr7D$1, 'a_iajDu749O2HH5AG4pth9fr7D$1');


//Ent_BICBuYW1lICAa
function Ent_BICBuYW1lICAa(p) {
  this.parent = p;
}
Ent_BICBuYW1lICAa.prototype = new lib.ObjectEntry();
Ent_BICBuYW1lICAa.prototype.keys = [];
Ent_BICBuYW1lICAa.prototype.values = [];
Ent_BICBuYW1lICAa.prototype.fields = [];
//Col_BICBuYW1lICAa
function Col_BICBuYW1lICAa(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_BICBuYW1lICAa.prototype = lib.RecordCollection.prototype;
//Tbl_BICBuYW1lICAa
function Tbl_BICBuYW1lICAa(l) {
  this.libName = l;
  this.initParent();
}
Tbl_BICBuYW1lICAa.prototype = new lib.ObjectSingleton();
Tbl_BICBuYW1lICAa.prototype.entryCtor = Ent_BICBuYW1lICAa;
Tbl_BICBuYW1lICAa.prototype.selfCtor = Tbl_BICBuYW1lICAa;
Tbl_BICBuYW1lICAa.prototype.collectionCtor = Col_BICBuYW1lICAa;
Tbl_BICBuYW1lICAa.prototype.stableName = "BICBuYW1lICAa";
Tbl_BICBuYW1lICAa.prototype.entryKindName = "show instructions page data";

// jsonimport
Ent_BICBuYW1lICAa.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
}
cs.registerGlobal("$BICBuYW1lICAa");
/* ACTION: level count */
function a_vFMu7blAisIqCobn2nv4yZ8F(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_vFMu7blAisIqCobn2nv4yZ8F$0;
  s.name = "level count";
  s.result = undefined;
  return s;
}
cs.registerAction("level count", "vFMu7blAisIqCobn2nv4yZ8F", a_vFMu7blAisIqCobn2nv4yZ8F, false);

function a_vFMu7blAisIqCobn2nv4yZ8F$0(s) {
  (s.pc = "4.91.1");
  (s.result = /* _level count */ s.d.$levelcount);
  if (s.previous.needsPicker) {
  s.rt.displayResult("n", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_vFMu7blAisIqCobn2nv4yZ8F$0, 'a_vFMu7blAisIqCobn2nv4yZ8F$0');

/* ACTION: set description */
function a_kU2A1tJvfkjT2FPkIK08A1Aq(previous, returnAddr, $level, $description) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_kU2A1tJvfkjT2FPkIK08A1Aq$0;
  s.name = "set description";
  s.$level = $level;
  s.$description = $description;
  return s;
}
cs.registerAction("set description", "kU2A1tJvfkjT2FPkIK08A1Aq", a_kU2A1tJvfkjT2FPkIK08A1Aq, false);

function a_kU2A1tJvfkjT2FPkIK08A1Aq$0(s) {
  (s.pc = "4.96.1");
  if (s.$level) {
  s.$level.perform_set("FcypXS06YlmK2KAQ327sEovl", s.$description, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_kU2A1tJvfkjT2FPkIK08A1Aq$0, 'a_kU2A1tJvfkjT2FPkIK08A1Aq$0');

/* ACTION: level action */
function a_xKLeWedSh1oV84ApAcS1lv8z(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xKLeWedSh1oV84ApAcS1lv8z$0;
  s.name = "level action";
  s.$level = $level;
  return s;
}
cs.registerAction("level action", "xKLeWedSh1oV84ApAcS1lv8z", a_xKLeWedSh1oV84ApAcS1lv8z, true);

function a_xKLeWedSh1oV84ApAcS1lv8z$0(s) {
  (s.pc = "4.101.0");
  null;
  return s.rt.leave();
}
cs.registerStep(a_xKLeWedSh1oV84ApAcS1lv8z$0, 'a_xKLeWedSh1oV84ApAcS1lv8z$0');

/* ACTION: level by id */
function a_uIQCNem1kvZBE4J6UHoWPCK1(previous, returnAddr, $index) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_uIQCNem1kvZBE4J6UHoWPCK1$0;
  s.name = "level by id";
  s.$index = $index;
  s.result = undefined;
  return s;
}
cs.registerAction("level by id", "uIQCNem1kvZBE4J6UHoWPCK1", a_uIQCNem1kvZBE4J6UHoWPCK1, false);

function a_uIQCNem1kvZBE4J6UHoWPCK1$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_uIQCNem1kvZBE4J6UHoWPCK1$4, lib.RTValue.mkPicker(lib.Number_.picker(), 0, "index", "$index"));
  return a_uIQCNem1kvZBE4J6UHoWPCK1$4;
  }
  return a_uIQCNem1kvZBE4J6UHoWPCK1$3;
}
cs.registerStep(a_uIQCNem1kvZBE4J6UHoWPCK1$0, 'a_uIQCNem1kvZBE4J6UHoWPCK1$0');

function a_uIQCNem1kvZBE4J6UHoWPCK1$4(s) {
  return a_uIQCNem1kvZBE4J6UHoWPCK1$3;
}
cs.registerStep(a_uIQCNem1kvZBE4J6UHoWPCK1$4, 'a_uIQCNem1kvZBE4J6UHoWPCK1$4');

function a_uIQCNem1kvZBE4J6UHoWPCK1$3(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.108.1");
  var t_infix_1 = (ok1(s, s.$index) && (s.$index > 0));
  var t_lazy_2 = t_infix_1;
  if ((ok1(s, t_lazy_2) && t_lazy_2)) {
  var t_infix_3 = (ok2(s, s.$index, /* _level count */ s.d.$levelcount) && (s.$index <= /* _level count */ s.d.$levelcount));
  (t_lazy_2 = t_infix_3);
  }
  ok1(s, t_lazy_2);
  if (t_lazy_2) {
  (s.pc = "4.108.50");
  var t_call_4 = (ok2(s, /* level index */ s.d.$BbGV2ZWwgaW5kZXga, s.$index) && /* level index */ s.d.$BbGV2ZWwgaW5kZXga.at(s.$index, s));
  (s.result = t_call_4);
  } else {
  (s.pc = "4.108.60");
  var t_call_5 = (ok1(s, /* level index */ s.d.$BbGV2ZWwgaW5kZXga) && /* level index */ s.d.$BbGV2ZWwgaW5kZXga.invalid(s));
  (s.result = t_call_5);
  }
  if (s.previous.needsPicker) {
  s.rt.displayResult("level", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_uIQCNem1kvZBE4J6UHoWPCK1$3, 'a_uIQCNem1kvZBE4J6UHoWPCK1$3');

/* ACTION: set locked */
function a_QDvbUJNoGliny617FskfXRJN(previous, returnAddr, $level, $b) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_QDvbUJNoGliny617FskfXRJN$0;
  s.name = "set locked";
  s.$level = $level;
  s.$b = $b;
  return s;
}
cs.registerAction("set locked", "QDvbUJNoGliny617FskfXRJN", a_QDvbUJNoGliny617FskfXRJN, false);

function a_QDvbUJNoGliny617FskfXRJN$0(s) {
  (s.pc = "4.113.1");
  var t_call_0 = (ok1(s, s.$b) && lib.Boolean_.not(s.$b, s));
  if (s.$level) {
  s.$level.perform_set("qhCetiH2Bj2wrY6fz4oObZF5", t_call_0, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_QDvbUJNoGliny617FskfXRJN$0, 'a_QDvbUJNoGliny617FskfXRJN$0');

/* ACTION: locked */
function a_WbBySlwgYc5I8faUKWaFep8o(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_WbBySlwgYc5I8faUKWaFep8o$0;
  s.name = "locked";
  s.$level = $level;
  s.result = undefined;
  return s;
}
cs.registerAction("locked", "WbBySlwgYc5I8faUKWaFep8o", a_WbBySlwgYc5I8faUKWaFep8o, false);

function a_WbBySlwgYc5I8faUKWaFep8o$0(s) {
  (s.pc = "4.118.1");
  if (s.$level) {
  var t_recOp_0 = s.$level.perform_get("qhCetiH2Bj2wrY6fz4oObZF5", s);
  }
  var t_call_1 = (ok1(s, t_recOp_0) && lib.Boolean_.not(t_recOp_0, s));
  (s.result = t_call_1);
  return s.rt.leave();
}
cs.registerStep(a_WbBySlwgYc5I8faUKWaFep8o$0, 'a_WbBySlwgYc5I8faUKWaFep8o$0');

/* ACTION: set instructions */
function a_jEFN2SCBqk8f47TxtO4wNwH1(previous, returnAddr, $instructions) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_jEFN2SCBqk8f47TxtO4wNwH1$0;
  s.name = "set instructions";
  s.$instructions = $instructions;
  return s;
}
cs.registerAction("set instructions", "jEFN2SCBqk8f47TxtO4wNwH1", a_jEFN2SCBqk8f47TxtO4wNwH1, false);

function a_jEFN2SCBqk8f47TxtO4wNwH1$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_jEFN2SCBqk8f47TxtO4wNwH1$2, lib.RTValue.mkPicker(lib.String_.picker(), "", "instructions", "$instructions"));
  return a_jEFN2SCBqk8f47TxtO4wNwH1$2;
  }
  return a_jEFN2SCBqk8f47TxtO4wNwH1$1;
}
cs.registerStep(a_jEFN2SCBqk8f47TxtO4wNwH1$0, 'a_jEFN2SCBqk8f47TxtO4wNwH1$0');

function a_jEFN2SCBqk8f47TxtO4wNwH1$2(s) {
  return a_jEFN2SCBqk8f47TxtO4wNwH1$1;
}
cs.registerStep(a_jEFN2SCBqk8f47TxtO4wNwH1$2, 'a_jEFN2SCBqk8f47TxtO4wNwH1$2');

function a_jEFN2SCBqk8f47TxtO4wNwH1$1(s) {
  (s.pc = "4.123.1");
  (/* _instructions */ s.d.$xmXSki2Kan2xPa8mJmNvEq7E = s.$instructions);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_jEFN2SCBqk8f47TxtO4wNwH1$1, 'a_jEFN2SCBqk8f47TxtO4wNwH1$1');

/* ACTION: show instructions */
function a_rhe4BNymJXHZr2coRC1gPgnW(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_rhe4BNymJXHZr2coRC1gPgnW$0;
  s.name = "show instructions";
  s.$_ = undefined;
  s.$handler = undefined;
  return s;
}
cs.registerPage("show instructions", "rhe4BNymJXHZr2coRC1gPgnW", a_rhe4BNymJXHZr2coRC1gPgnW, false);

function a_rhe4BNymJXHZr2coRC1gPgnW$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.128.0");
  var t_call_1 = lib.Box.is_init(s);
  ok1(s, t_call_1);
  if (t_call_1) {
  (s.rt.getCurrentPage().model = s.d.$BICBuYW1lICAa.create(s));
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.128.40");
  return s.rt.enter(a_stylepage(s, a_rhe4BNymJXHZr2coRC1gPgnW$2));
  } else {
  (s.pc = "4.128.50");
  null;
  }
  return a_rhe4BNymJXHZr2coRC1gPgnW$1;
}
cs.registerStep(a_rhe4BNymJXHZr2coRC1gPgnW$0, 'a_rhe4BNymJXHZr2coRC1gPgnW$0');

function a_rhe4BNymJXHZr2coRC1gPgnW$2(s) {
  (s.pc = "4.128.43");
  lib.Wall.set_subtitle("instructions", s);
  return a_rhe4BNymJXHZr2coRC1gPgnW$1;
}
cs.registerStep(a_rhe4BNymJXHZr2coRC1gPgnW$2, 'a_rhe4BNymJXHZr2coRC1gPgnW$2');

function a_rhe4BNymJXHZr2coRC1gPgnW$1(s) {
  var t_elseIf_2 = true;
  (s.pc = "4.128.5");
  true;
  if (true) {
  s.rt.enter_render();
  (s.$_ = s.rt.getCurrentPage().model);
  (s.pc = "4.128.90");
  lib.Box.push_box(s);
  (s.pc = "4.128.920");
  lib.Box.set_margins(2, 2, 2, 2, s);
  (s.pc = "4.128.923");
  (ok1(s, /* _instructions */ s.d.$xmXSki2Kan2xPa8mJmNvEq7E) && lib.String_.post_to_wall(/* _instructions */ s.d.$xmXSki2Kan2xPa8mJmNvEq7E, s));
  lib.Box.pop_box(s);
  (s.pc = "4.128.92");
  lib.Box.push_box(s);
  (s.pc = "4.128.940");
  lib.Box.set_margins(2.5, 1, 2.5, 1, s);
  (s.pc = "4.128.943");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.128.946");
  var t_call_3 = lib.Colors.white(s);
  (ok1(s, t_call_3) && lib.Box.set_foreground(t_call_3, s));
  (s.pc = "4.128.949");
  return s.rt.enter(a_Rqqe3CxvoK7XWqNZh9kQWX7G(s, a_rhe4BNymJXHZr2coRC1gPgnW$4, /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V));
  } else {
  (s.pc = "4.128.a0");
  null;
  }
  return a_rhe4BNymJXHZr2coRC1gPgnW$3;
}
cs.registerStep(a_rhe4BNymJXHZr2coRC1gPgnW$1, 'a_rhe4BNymJXHZr2coRC1gPgnW$1');

function a_rhe4BNymJXHZr2coRC1gPgnW$4(s) {
  (s.pc = "4.128.94c");
  lib.Box.set_padding(0.5, 4, 0.5, 4, s);
  (s.pc = "4.128.94j0");
  var t_lmbProxy_4 = s.libs.mkLambdaProxy;
  (s.$handler = function(la0, la1) { return a_a_rhe4BNymJXHZr2coRC1gPgnW$5(t_lmbProxy_4(la0), la1) });
  (s.pc = "4.128.94f");
  (ok1(s, s.$handler) && lib.Box.on_tapped(s.$handler, s));
  (s.pc = "4.128.94j");
  lib.Box.push_box(s);
  (s.pc = "4.128.94l0");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.128.94l3");
  lib.Box.set_font_size(2, s);
  (s.pc = "4.128.94l6");
  lib.String_.post_to_wall("start", s);
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  s.rt.leave_render();
  return a_rhe4BNymJXHZr2coRC1gPgnW$3;
}
cs.registerStep(a_rhe4BNymJXHZr2coRC1gPgnW$4, 'a_rhe4BNymJXHZr2coRC1gPgnW$4');

function a_rhe4BNymJXHZr2coRC1gPgnW$3(s) {
  return s.rt.leave();
}
cs.registerStep(a_rhe4BNymJXHZr2coRC1gPgnW$3, 'a_rhe4BNymJXHZr2coRC1gPgnW$3');

/* ACTION: a_rhe4BNymJXHZr2coRC1gPgnW::lambda::5 */
function a_a_rhe4BNymJXHZr2coRC1gPgnW$5(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_rhe4BNymJXHZr2coRC1gPgnW$5$0;
  s.name = "show instructions";
  return s;
}
cs.registerLambda("a_rhe4BNymJXHZr2coRC1gPgnW\u003a\u003alambda\u003a\u003a5", "a_rhe4BNymJXHZr2coRC1gPgnW$5", a_a_rhe4BNymJXHZr2coRC1gPgnW$5, true);

function a_a_rhe4BNymJXHZr2coRC1gPgnW$5$0(s) {
  (s.pc = "4.128.94j20");
  return s.rt.enter(a_uIQCNem1kvZBE4J6UHoWPCK1(s, a_a_rhe4BNymJXHZr2coRC1gPgnW$5$1, 1));
}
cs.registerStep(a_a_rhe4BNymJXHZr2coRC1gPgnW$5$0, 'a_a_rhe4BNymJXHZr2coRC1gPgnW$5$0');

function a_a_rhe4BNymJXHZr2coRC1gPgnW$5$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  return s.rt.enter(a_startgame(s, a_a_rhe4BNymJXHZr2coRC1gPgnW$5$2, t_actRes_0));
}
cs.registerStep(a_a_rhe4BNymJXHZr2coRC1gPgnW$5$1, 'a_a_rhe4BNymJXHZr2coRC1gPgnW$5$1');

function a_a_rhe4BNymJXHZr2coRC1gPgnW$5$2(s) {
  var t_actRes_1 = s.rt.returnedFrom.result;
  t_actRes_1;
  return s.rt.leave();
}
cs.registerStep(a_a_rhe4BNymJXHZr2coRC1gPgnW$5$2, 'a_a_rhe4BNymJXHZr2coRC1gPgnW$5$2');

/* ACTION: show instructions button */
function a_OP6CcdaCET95J4x6c4vLnjpz(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_OP6CcdaCET95J4x6c4vLnjpz$0;
  s.name = "show instructions button";
  s.$handler = undefined;
  return s;
}
cs.registerAction("show instructions button", "OP6CcdaCET95J4x6c4vLnjpz", a_OP6CcdaCET95J4x6c4vLnjpz, false);

function a_OP6CcdaCET95J4x6c4vLnjpz$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.134.0");
  var t_call_1 = (ok1(s, /* _instructions */ s.d.$xmXSki2Kan2xPa8mJmNvEq7E) && lib.String_.is_empty(/* _instructions */ s.d.$xmXSki2Kan2xPa8mJmNvEq7E, s));
  var t_call_2 = (ok1(s, t_call_1) && lib.Boolean_.not(t_call_1, s));
  ok1(s, t_call_2);
  if (t_call_2) {
  (s.pc = "4.134.40");
  lib.Box.push_box(s);
  (s.pc = "4.134.420");
  lib.Box.set_margins(0, 1, 1, 1, s);
  (s.pc = "4.134.423");
  lib.Box.set_width(10, s);
  (s.pc = "4.134.426");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.134.429");
  return s.rt.enter(a_Rqqe3CxvoK7XWqNZh9kQWX7G(s, a_OP6CcdaCET95J4x6c4vLnjpz$2, /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V));
  } else {
  (s.pc = "4.134.50");
  null;
  }
  return a_OP6CcdaCET95J4x6c4vLnjpz$1;
}
cs.registerStep(a_OP6CcdaCET95J4x6c4vLnjpz$0, 'a_OP6CcdaCET95J4x6c4vLnjpz$0');

function a_OP6CcdaCET95J4x6c4vLnjpz$2(s) {
  (s.pc = "4.134.42c");
  lib.Box.set_padding(0.5, 2, 0.5, 2, s);
  (s.pc = "4.134.42j0");
  var t_lmbProxy_3 = s.libs.mkLambdaProxy;
  (s.$handler = function(la0, la1) { return a_a_OP6CcdaCET95J4x6c4vLnjpz$3(t_lmbProxy_3(la0), la1) });
  (s.pc = "4.134.42f");
  (ok1(s, s.$handler) && lib.Box.on_tapped(s.$handler, s));
  (s.pc = "4.134.42j");
  lib.Box.push_box(s);
  (s.pc = "4.134.42l0");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.134.42l3");
  lib.Box.set_font_size(0.7, s);
  (s.pc = "4.134.42l6");
  var t_call_4 = lib.Colors.white(s);
  (ok1(s, t_call_4) && lib.Box.set_foreground(t_call_4, s));
  (s.pc = "4.134.42l9");
  lib.String_.post_to_wall("instructions", s);
  lib.Box.pop_box(s);
  lib.Box.pop_box(s);
  return a_OP6CcdaCET95J4x6c4vLnjpz$1;
}
cs.registerStep(a_OP6CcdaCET95J4x6c4vLnjpz$2, 'a_OP6CcdaCET95J4x6c4vLnjpz$2');

function a_OP6CcdaCET95J4x6c4vLnjpz$1(s) {
  return s.rt.leave();
}
cs.registerStep(a_OP6CcdaCET95J4x6c4vLnjpz$1, 'a_OP6CcdaCET95J4x6c4vLnjpz$1');

/* ACTION: a_OP6CcdaCET95J4x6c4vLnjpz::lambda::3 */
function a_a_OP6CcdaCET95J4x6c4vLnjpz$3(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_OP6CcdaCET95J4x6c4vLnjpz$3$0;
  s.name = "show instructions button";
  return s;
}
cs.registerLambda("a_OP6CcdaCET95J4x6c4vLnjpz\u003a\u003alambda\u003a\u003a3", "a_OP6CcdaCET95J4x6c4vLnjpz$3", a_a_OP6CcdaCET95J4x6c4vLnjpz$3, true);

function a_a_OP6CcdaCET95J4x6c4vLnjpz$3$0(s) {
  (s.pc = "4.134.42j20");
  s.rt.forceNonRender();
  s.rt.forcePageRefresh();
  s.rt.postAutoPage(s.d.libName, "show instructions");
  return s.rt.leave();
}
cs.registerStep(a_a_OP6CcdaCET95J4x6c4vLnjpz$3$0, 'a_a_OP6CcdaCET95J4x6c4vLnjpz$3$0');

/* ACTION: set skip details */
function a_abOWAkFdJLtkXvCwDz9Uucwc(previous, returnAddr, $level, $skip) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_abOWAkFdJLtkXvCwDz9Uucwc$0;
  s.name = "set skip details";
  s.$level = $level;
  s.$skip = $skip;
  return s;
}
cs.registerAction("set skip details", "abOWAkFdJLtkXvCwDz9Uucwc", a_abOWAkFdJLtkXvCwDz9Uucwc, false);

function a_abOWAkFdJLtkXvCwDz9Uucwc$0(s) {
  (s.pc = "4.139.1");
  if (s.$level) {
  s.$level.perform_set("KVEfbkQ37muzCX37bf2bTBbl", s.$skip, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_abOWAkFdJLtkXvCwDz9Uucwc$0, 'a_abOWAkFdJLtkXvCwDz9Uucwc$0');

/* ACTION: show level selection button */
function a_RiKp9WsgmJDFjpU5f9NbOSB6(previous, returnAddr, $lvl, $width, $height) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_RiKp9WsgmJDFjpU5f9NbOSB6$0;
  s.name = "show level selection button";
  s.$lvl = $lvl;
  s.$width = $width;
  s.$height = $height;
  s.$theme = undefined;
  s.$handler = undefined;
  s.$c = undefined;
  s.$pic = undefined;
  return s;
}
cs.registerAction("show level selection button", "RiKp9WsgmJDFjpU5f9NbOSB6", a_RiKp9WsgmJDFjpU5f9NbOSB6, false);

function a_RiKp9WsgmJDFjpU5f9NbOSB6$0(s) {
  (s.pc = "4.144.0");
  return s.rt.enter(a_kyM6BKxra6FMoP8AENJbQMGs(s, a_RiKp9WsgmJDFjpU5f9NbOSB6$1, s.$lvl));
}
cs.registerStep(a_RiKp9WsgmJDFjpU5f9NbOSB6$0, 'a_RiKp9WsgmJDFjpU5f9NbOSB6$0');

function a_RiKp9WsgmJDFjpU5f9NbOSB6$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  (s.$theme = t_actRes_0);
  var t_elseIf_1 = true;
  (s.pc = "4.144.3");
  if (s.$lvl) {
  var t_recOp_2 = s.$lvl.perform_get("qhCetiH2Bj2wrY6fz4oObZF5", s);
  }
  ok1(s, t_recOp_2);
  if (t_recOp_2) {
  (s.pc = "4.144.740");
  var t_lmbv_3 = s.$lvl;
  var t_lmbProxy_4 = s.libs.mkLambdaProxy;
  (s.$handler = function(la0, la1) { return a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4(t_lmbProxy_4(la0), la1, t_lmbv_3) });
  (s.pc = "4.144.70");
  (ok1(s, s.$handler) && lib.Box.on_tapped(s.$handler, s));
  } else {
  (s.pc = "4.144.80");
  null;
  }
  (s.pc = "4.144.9");
  return s.rt.enter(a_E4ynNjmdl86AziAtb5ofey4w(s, a_RiKp9WsgmJDFjpU5f9NbOSB6$5, s.$lvl));
}
cs.registerStep(a_RiKp9WsgmJDFjpU5f9NbOSB6$1, 'a_RiKp9WsgmJDFjpU5f9NbOSB6$1');

function a_RiKp9WsgmJDFjpU5f9NbOSB6$5(s) {
  var t_actRes_5 = s.rt.returnedFrom.result;
  (s.$c = t_actRes_5);
  var t_elseIf_6 = true;
  (s.pc = "4.144.c");
  if (s.$lvl) {
  var t_recOp_7 = s.$lvl.perform_get("qhCetiH2Bj2wrY6fz4oObZF5", s);
  }
  ok1(s, t_recOp_7);
  if (t_recOp_7) {
  (s.pc = "4.144.g0");
  (ok1(s, s.$c) && lib.Box.set_background(s.$c, s));
  } else {
  (s.pc = "4.144.h0");
  var t_call_8 = lib.Colors.gray(s);
  (ok1(s, t_call_8) && lib.Box.set_background(t_call_8, s));
  }
  (s.pc = "4.144.h");
  var t_call_9 = lib.Colors.white(s);
  (ok1(s, t_call_9) && lib.Box.set_foreground(t_call_9, s));
  var t_elseIf_10 = true;
  (s.pc = "4.144.l");
  if (s.$theme) {
  var t_recOp_11 = s.$theme[("GKYkcMSe7G5kwyFRmRdC9FWX")];
  }
  var t_call_12 = lib.Boolean_.not((t_recOp_11 == undefined), s);
  ok1(s, t_call_12);
  if (t_call_12) {
  (s.pc = "4.144.p0");
  lib.Box.push_box(s);
  (s.pc = "4.144.p20");
  if (s.$theme) {
  var t_recOp_13 = s.$theme[("GKYkcMSe7G5kwyFRmRdC9FWX")];
  }
  (s.$pic = t_recOp_13);
  (s.pc = "4.144.p23");
  (ok1(s, s.$pic) && s.$pic.post_to_wall(s));
  (s.pc = "4.144.p26");
  (ok1(s, s.$width) && lib.Box.set_width(s.$width, s));
  (s.pc = "4.144.p29");
  (ok1(s, s.$height) && lib.Box.set_height(s.$height, s));
  lib.Box.pop_box(s);
  } else {
  (s.pc = "4.144.q0");
  null;
  }
  (s.pc = "4.144.q");
  lib.Box.push_box(s);
  (s.pc = "4.144.s0");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.144.s3");
  lib.Box.set_vertical_align("center", s);
  (s.pc = "4.144.s6");
  (ok1(s, s.$width) && lib.Box.set_width(s.$width, s));
  (s.pc = "4.144.s9");
  (ok1(s, s.$height) && lib.Box.set_height(s.$height, s));
  (s.pc = "4.144.sc");
  lib.Box.set_font_size(5, s);
  (s.pc = "4.144.sf");
  (ok1(s, (ok1(s, s.$lvl) && s.$lvl[("xneF5ygmtTQb4TogUvxfMDe1")])) && lib.Number_.post_to_wall((ok1(s, s.$lvl) && s.$lvl[("xneF5ygmtTQb4TogUvxfMDe1")]), s));
  lib.Box.pop_box(s);
  var t_elseIf_14 = true;
  (s.pc = "4.144.s");
  if (s.$lvl) {
  var t_recOp_15 = s.$lvl.perform_get("qhCetiH2Bj2wrY6fz4oObZF5", s);
  }
  var t_call_16 = (ok1(s, t_recOp_15) && lib.Boolean_.not(t_recOp_15, s));
  ok1(s, t_call_16);
  if (t_call_16) {
  (s.pc = "4.144.w0");
  lib.Box.push_box(s);
  (s.pc = "4.144.w20");
  lib.Box.set_horizontal_align("right", s);
  (s.pc = "4.144.w23");
  lib.Box.set_vertical_align("bottom", s);
  (s.pc = "4.144.w26");
  (ok1(s, s.$width) && lib.Box.set_width(s.$width, s));
  (s.pc = "4.144.w29");
  (ok1(s, s.$height) && lib.Box.set_height(s.$height, s));
  (s.pc = "4.144.w2c");
  lib.Box.set_font_size(1.2, s);
  (s.pc = "4.144.w2f");
  var t_call_17 = lib.Colors.light_gray(s);
  (ok1(s, t_call_17) && lib.Box.set_foreground(t_call_17, s));
  (s.pc = "4.144.w2i");
  lib.Box.set_padding(0.5, 0.5, 0.5, 0.5, s);
  (s.pc = "4.144.w2l");
  lib.String_.post_to_wall("locked", s);
  lib.Box.pop_box(s);
  } else {
  (s.pc = "4.144.x0");
  null;
  }
  var t_elseIf_18 = true;
  (s.pc = "4.144.x");
  if (s.$lvl) {
  var t_recOp_19 = s.$lvl.perform_get("e6cQUfw2298se1yYeqTlPcX8", s);
  }
  ok1(s, t_recOp_19);
  if (t_recOp_19) {
  var t_elseIf_20 = true;
  (s.pc = "4.144.B0");
  if (s.$lvl) {
  var t_recOp_21 = s.$lvl.perform_get("qod2mWVTq0MtY6ZGt7IA6uUe", s);
  }
  var t_infix_22 = (ok1(s, t_recOp_21) && (t_recOp_21 > 0));
  ok1(s, t_infix_22);
  if (t_infix_22) {
  (s.pc = "4.144.B40");
  return s.rt.enter(a_syCJwBkyr1jcu3Z9uQnocktT(s, a_RiKp9WsgmJDFjpU5f9NbOSB6$17, s.$lvl, s.$width, s.$height));
  } else {
  (s.pc = "4.144.B50");
  lib.Box.push_box(s);
  (s.pc = "4.144.B520");
  lib.Box.set_padding(0, 0, 1, 0, s);
  (s.pc = "4.144.B523");
  (ok1(s, s.$width) && lib.Box.set_width(s.$width, s));
  (s.pc = "4.144.B526");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.144.B529");
  lib.Box.set_vertical_align("bottom", s);
  (s.pc = "4.144.B52c");
  (ok1(s, s.$height) && lib.Box.set_height(s.$height, s));
  (s.pc = "4.144.B52f");
  lib.Box.set_font_size(1, s);
  (s.pc = "4.144.B52i");
  var t_call_23 = lib.Colors.orange(s);
  var t_call_24 = (ok1(s, t_call_23) && t_call_23.lighten(0.4, s));
  (ok1(s, t_call_24) && lib.Box.set_foreground(t_call_24, s));
  (s.pc = "4.144.B52l");
  return s.rt.enter(a_g5G6V1r466rXedV0GC2DdMLq(s, a_RiKp9WsgmJDFjpU5f9NbOSB6$18, s.$lvl));
  }
  return a_RiKp9WsgmJDFjpU5f9NbOSB6$16;
  } else {
  (s.pc = "4.144.C0");
  null;
  }
  return a_RiKp9WsgmJDFjpU5f9NbOSB6$14;
}
cs.registerStep(a_RiKp9WsgmJDFjpU5f9NbOSB6$5, 'a_RiKp9WsgmJDFjpU5f9NbOSB6$5');

function a_RiKp9WsgmJDFjpU5f9NbOSB6$17(s) {
  return a_RiKp9WsgmJDFjpU5f9NbOSB6$16;
}
cs.registerStep(a_RiKp9WsgmJDFjpU5f9NbOSB6$17, 'a_RiKp9WsgmJDFjpU5f9NbOSB6$17');

function a_RiKp9WsgmJDFjpU5f9NbOSB6$18(s) {
  var t_actRes_25 = s.rt.returnedFrom.result;
  var t_concat_26 = lib.String_.concatAny("score\u003a ", t_actRes_25);
  (ok1(s, t_concat_26) && lib.String_.post_to_wall(t_concat_26, s));
  lib.Box.pop_box(s);
  return a_RiKp9WsgmJDFjpU5f9NbOSB6$16;
}
cs.registerStep(a_RiKp9WsgmJDFjpU5f9NbOSB6$18, 'a_RiKp9WsgmJDFjpU5f9NbOSB6$18');

function a_RiKp9WsgmJDFjpU5f9NbOSB6$16(s) {
  return a_RiKp9WsgmJDFjpU5f9NbOSB6$14;
}
cs.registerStep(a_RiKp9WsgmJDFjpU5f9NbOSB6$16, 'a_RiKp9WsgmJDFjpU5f9NbOSB6$16');

function a_RiKp9WsgmJDFjpU5f9NbOSB6$14(s) {
  return s.rt.leave();
}
cs.registerStep(a_RiKp9WsgmJDFjpU5f9NbOSB6$14, 'a_RiKp9WsgmJDFjpU5f9NbOSB6$14');

/* ACTION: a_RiKp9WsgmJDFjpU5f9NbOSB6::lambda::4 */
function a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4(previous, returnAddr, $lvl) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4$0;
  s.name = "show level selection button";
  s.$lvl = $lvl;
  return s;
}
cs.registerLambda("a_RiKp9WsgmJDFjpU5f9NbOSB6\u003a\u003alambda\u003a\u003a4", "a_RiKp9WsgmJDFjpU5f9NbOSB6$4", a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4, true);

function a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4$0(s) {
  (s.pc = "4.144.7420");
  return s.rt.enter(a_hkrBuHpdV719LOBB6mZewhJD(s, a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4$1, s.$lvl));
}
cs.registerStep(a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4$0, 'a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4$0');

function a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  t_actRes_0;
  return s.rt.leave();
}
cs.registerStep(a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4$1, 'a_a_RiKp9WsgmJDFjpU5f9NbOSB6$4$1');

/* ACTION: level button color */
function a_E4ynNjmdl86AziAtb5ofey4w(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_E4ynNjmdl86AziAtb5ofey4w$0;
  s.name = "level button color";
  s.$level = $level;
  s.result = undefined;
  s.$level_theme = undefined;
  return s;
}
cs.registerAction("level button color", "E4ynNjmdl86AziAtb5ofey4w", a_E4ynNjmdl86AziAtb5ofey4w, false);

function a_E4ynNjmdl86AziAtb5ofey4w$0(s) {
  (s.pc = "4.149.0");
  var t_call_0 = (ok2(s, /* level theme index */ s.d.$BdGhpbmca, (ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")])) && /* level theme index */ s.d.$BdGhpbmca.at((ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")]), s));
  if (t_call_0) {
  var t_recOp_1 = t_call_0.perform_get("T7dTa1GYk6ojgTI0G2RprFyk", s);
  }
  (s.$level_theme = t_recOp_1);
  var t_elseIf_2 = true;
  (s.pc = "4.149.3");
  var t_call_3 = lib.Boolean_.not((s.$level_theme == undefined), s);
  var t_lazy_4 = t_call_3;
  if ((ok1(s, t_lazy_4) && t_lazy_4)) {
  if (s.$level_theme) {
  var t_recOp_5 = s.$level_theme[("xB8gTd6eYdzIepWazYoNI284")];
  }
  var t_call_6 = (ok1(s, t_recOp_5) && t_recOp_5.A(s));
  var t_infix_7 = (ok1(s, t_call_6) && (t_call_6 > 0));
  (t_lazy_4 = t_infix_7);
  }
  ok1(s, t_lazy_4);
  if (t_lazy_4) {
  (s.pc = "4.149.70");
  if (s.$level_theme) {
  var t_recOp_8 = s.$level_theme[("xB8gTd6eYdzIepWazYoNI284")];
  }
  (s.result = t_recOp_8);
  } else {
  (s.pc = "4.149.80");
  if (/* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V) {
  var t_recOp_9 = /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V[("xB8gTd6eYdzIepWazYoNI284")];
  }
  (s.result = t_recOp_9);
  }
  return s.rt.leave();
}
cs.registerStep(a_E4ynNjmdl86AziAtb5ofey4w$0, 'a_E4ynNjmdl86AziAtb5ofey4w$0');


//Ent_BdGhpbmca
function Ent_BdGhpbmca(p) {
  this.parent = p;
}
Ent_BdGhpbmca.prototype = new lib.IndexEntry();
Ent_BdGhpbmca.prototype.keys = ["xO347bTesUjy1mM30AP1wH3n"];
Ent_BdGhpbmca.prototype.values = ["T7dTa1GYk6ojgTI0G2RprFyk"];
Ent_BdGhpbmca.prototype.fields = ["xO347bTesUjy1mM30AP1wH3n", "T7dTa1GYk6ojgTI0G2RprFyk"];
Ent_BdGhpbmca.prototype.xO347bTesUjy1mM30AP1wH3n_realname = "id";
Ent_BdGhpbmca.prototype.T7dTa1GYk6ojgTI0G2RprFyk_realname = "_theme";
//Col_BdGhpbmca
function Col_BdGhpbmca(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_BdGhpbmca.prototype = lib.RecordCollection.prototype;
//Tbl_BdGhpbmca
function Tbl_BdGhpbmca(l) {
  this.libName = l;
  this.initParent();
}
Tbl_BdGhpbmca.prototype = new lib.IndexSingleton();
Tbl_BdGhpbmca.prototype.entryCtor = Ent_BdGhpbmca;
Tbl_BdGhpbmca.prototype.selfCtor = Tbl_BdGhpbmca;
Tbl_BdGhpbmca.prototype.collectionCtor = Col_BdGhpbmca;
Tbl_BdGhpbmca.prototype.stableName = "BdGhpbmca";
Tbl_BdGhpbmca.prototype.entryKindName = "level theme";

// jsonimport
Tbl_BdGhpbmca.prototype.importJsonKeys = function (ctx, json) {
  var s = ctx.s;
  var a = [];
  a.push(ctx.importNumber(json, "id"));
  return a;
}
Ent_BdGhpbmca.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("T7dTa1GYk6ojgTI0G2RprFyk", ctx.importRecord(json, this.perform_get("T7dTa1GYk6ojgTI0G2RprFyk",s),"_theme", s.d.$jm2ILvhcUMczcfijkGG49dZ2), s);
}
cs.registerGlobal("$BdGhpbmca");

//Ent_jm2ILvhcUMczcfijkGG49dZ2
function Ent_jm2ILvhcUMczcfijkGG49dZ2(p) {
  this.parent = p;
}
Ent_jm2ILvhcUMczcfijkGG49dZ2.prototype = new lib.ObjectEntry();
Ent_jm2ILvhcUMczcfijkGG49dZ2.prototype.keys = [];
Ent_jm2ILvhcUMczcfijkGG49dZ2.prototype.values = ["xB8gTd6eYdzIepWazYoNI284", "GKYkcMSe7G5kwyFRmRdC9FWX", "xePTIfIYg4fJ3yUz2Cv0ucfs"];
Ent_jm2ILvhcUMczcfijkGG49dZ2.prototype.fields = ["xB8gTd6eYdzIepWazYoNI284", "GKYkcMSe7G5kwyFRmRdC9FWX", "xePTIfIYg4fJ3yUz2Cv0ucfs"];
Ent_jm2ILvhcUMczcfijkGG49dZ2.prototype.xB8gTd6eYdzIepWazYoNI284_realname = "_background";
Ent_jm2ILvhcUMczcfijkGG49dZ2.prototype.GKYkcMSe7G5kwyFRmRdC9FWX_realname = "_background picture";
Ent_jm2ILvhcUMczcfijkGG49dZ2.prototype.xePTIfIYg4fJ3yUz2Cv0ucfs_realname = "_foreground";
//Col_jm2ILvhcUMczcfijkGG49dZ2
function Col_jm2ILvhcUMczcfijkGG49dZ2(p) {
  this.parent = p;
  lib.RecordCollection.call(this);
}
Col_jm2ILvhcUMczcfijkGG49dZ2.prototype = lib.RecordCollection.prototype;
//Tbl_jm2ILvhcUMczcfijkGG49dZ2
function Tbl_jm2ILvhcUMczcfijkGG49dZ2(l) {
  this.libName = l;
  this.initParent();
}
Tbl_jm2ILvhcUMczcfijkGG49dZ2.prototype = new lib.ObjectSingleton();
Tbl_jm2ILvhcUMczcfijkGG49dZ2.prototype.entryCtor = Ent_jm2ILvhcUMczcfijkGG49dZ2;
Tbl_jm2ILvhcUMczcfijkGG49dZ2.prototype.selfCtor = Tbl_jm2ILvhcUMczcfijkGG49dZ2;
Tbl_jm2ILvhcUMczcfijkGG49dZ2.prototype.collectionCtor = Col_jm2ILvhcUMczcfijkGG49dZ2;
Tbl_jm2ILvhcUMczcfijkGG49dZ2.prototype.stableName = "jm2ILvhcUMczcfijkGG49dZ2";
Tbl_jm2ILvhcUMczcfijkGG49dZ2.prototype.entryKindName = "theme";

// jsonimport
Ent_jm2ILvhcUMczcfijkGG49dZ2.prototype.importJsonFields = function (ctx, json) {
  var s = ctx.s;
  this.perform_set("xB8gTd6eYdzIepWazYoNI284", ctx.importColor(json, "_background"), s);
  this.perform_set("xePTIfIYg4fJ3yUz2Cv0ucfs", ctx.importColor(json, "_foreground"), s);
}
cs.registerGlobal("$jm2ILvhcUMczcfijkGG49dZ2");
/* ACTION: button theme */
function a_JuYMgo4f6JZDHLov4on94izn(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_JuYMgo4f6JZDHLov4on94izn$0;
  s.name = "button theme";
  s.result = undefined;
  return s;
}
cs.registerAction("button theme", "JuYMgo4f6JZDHLov4on94izn", a_JuYMgo4f6JZDHLov4on94izn, false);

function a_JuYMgo4f6JZDHLov4on94izn$0(s) {
  (s.pc = "4.157.1");
  (s.result = /* _button theme */ s.d.$yX2e8ghq4LTf5saYPyFh4j7V);
  if (s.previous.needsPicker) {
  s.rt.displayResult("theme", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_JuYMgo4f6JZDHLov4on94izn$0, 'a_JuYMgo4f6JZDHLov4on94izn$0');

/* ACTION: create theme */
function a_TuvYc3CSeDzlxw7k4r66Yrcb(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_TuvYc3CSeDzlxw7k4r66Yrcb$0;
  s.name = "create theme";
  s.result = undefined;
  return s;
}
cs.registerAction("create theme", "TuvYc3CSeDzlxw7k4r66Yrcb", a_TuvYc3CSeDzlxw7k4r66Yrcb, false);

function a_TuvYc3CSeDzlxw7k4r66Yrcb$0(s) {
  (s.pc = "4.162.0");
  var t_call_0 = (ok1(s, /* theme */ s.d.$jm2ILvhcUMczcfijkGG49dZ2) && /* theme */ s.d.$jm2ILvhcUMczcfijkGG49dZ2.create(s));
  s.rt.markAllocated(t_call_0);
  (s.result = t_call_0);
  (s.pc = "4.162.3");
  var t_call_1 = lib.Colors.transparent(s);
  if (s.result) {
  s.result.perform_set("xB8gTd6eYdzIepWazYoNI284", t_call_1, s);
  }
  (s.pc = "4.162.6");
  var t_call_2 = lib.Colors.transparent(s);
  if (s.result) {
  s.result.perform_set("xePTIfIYg4fJ3yUz2Cv0ucfs", t_call_2, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_TuvYc3CSeDzlxw7k4r66Yrcb$0, 'a_TuvYc3CSeDzlxw7k4r66Yrcb$0');

/* ACTION: page theme */
function a_onF52KFta97Q2Qwj5GSJFw9u(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_onF52KFta97Q2Qwj5GSJFw9u$0;
  s.name = "page theme";
  s.result = undefined;
  return s;
}
cs.registerAction("page theme", "onF52KFta97Q2Qwj5GSJFw9u", a_onF52KFta97Q2Qwj5GSJFw9u, false);

function a_onF52KFta97Q2Qwj5GSJFw9u$0(s) {
  (s.pc = "4.168.1");
  (s.result = /* _page theme */ s.d.$A6TaCR1TM233ynuAfK2ieR1N);
  if (s.previous.needsPicker) {
  s.rt.displayResult("theme", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_onF52KFta97Q2Qwj5GSJFw9u$0, 'a_onF52KFta97Q2Qwj5GSJFw9u$0');

/* ACTION: apply theme */
function a_Rqqe3CxvoK7XWqNZh9kQWX7G(previous, returnAddr, $theme) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Rqqe3CxvoK7XWqNZh9kQWX7G$0;
  s.name = "apply theme";
  s.$theme = $theme;
  return s;
}
cs.registerAction("apply theme", "Rqqe3CxvoK7XWqNZh9kQWX7G", a_Rqqe3CxvoK7XWqNZh9kQWX7G, false);

function a_Rqqe3CxvoK7XWqNZh9kQWX7G$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.173.0");
  if (s.$theme) {
  var t_recOp_1 = s.$theme[("xB8gTd6eYdzIepWazYoNI284")];
  }
  var t_call_2 = (ok1(s, t_recOp_1) && t_recOp_1.A(s));
  var t_infix_3 = (ok1(s, t_call_2) && (t_call_2 > 0));
  ok1(s, t_infix_3);
  if (t_infix_3) {
  (s.pc = "4.173.40");
  if (s.$theme) {
  var t_recOp_4 = s.$theme[("xB8gTd6eYdzIepWazYoNI284")];
  }
  (ok1(s, t_recOp_4) && lib.Box.set_background(t_recOp_4, s));
  } else {
  (s.pc = "4.173.50");
  null;
  }
  var t_elseIf_5 = true;
  (s.pc = "4.173.5");
  if (s.$theme) {
  var t_recOp_6 = s.$theme[("xePTIfIYg4fJ3yUz2Cv0ucfs")];
  }
  var t_call_7 = (ok1(s, t_recOp_6) && t_recOp_6.A(s));
  var t_infix_8 = (ok1(s, t_call_7) && (t_call_7 > 0));
  ok1(s, t_infix_8);
  if (t_infix_8) {
  (s.pc = "4.173.90");
  if (s.$theme) {
  var t_recOp_9 = s.$theme[("xePTIfIYg4fJ3yUz2Cv0ucfs")];
  }
  (ok1(s, t_recOp_9) && lib.Box.set_foreground(t_recOp_9, s));
  } else {
  (s.pc = "4.173.a0");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_Rqqe3CxvoK7XWqNZh9kQWX7G$0, 'a_Rqqe3CxvoK7XWqNZh9kQWX7G$0');

/* ACTION: set background */
function a_xOGMqFGX0oajGlVqWyq6ciVg(previous, returnAddr, $theme, $c) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_xOGMqFGX0oajGlVqWyq6ciVg$0;
  s.name = "set background";
  s.$theme = $theme;
  s.$c = $c;
  return s;
}
cs.registerAction("set background", "xOGMqFGX0oajGlVqWyq6ciVg", a_xOGMqFGX0oajGlVqWyq6ciVg, false);

function a_xOGMqFGX0oajGlVqWyq6ciVg$0(s) {
  (s.pc = "4.178.1");
  if (s.$theme) {
  s.$theme.perform_set("xB8gTd6eYdzIepWazYoNI284", s.$c, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_xOGMqFGX0oajGlVqWyq6ciVg$0, 'a_xOGMqFGX0oajGlVqWyq6ciVg$0');

/* ACTION: set foreground */
function a_wjHWOo2L9s4mti20Bl4xgRr7(previous, returnAddr, $theme, $c) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_wjHWOo2L9s4mti20Bl4xgRr7$0;
  s.name = "set foreground";
  s.$theme = $theme;
  s.$c = $c;
  return s;
}
cs.registerAction("set foreground", "wjHWOo2L9s4mti20Bl4xgRr7", a_wjHWOo2L9s4mti20Bl4xgRr7, false);

function a_wjHWOo2L9s4mti20Bl4xgRr7$0(s) {
  (s.pc = "4.183.1");
  if (s.$theme) {
  s.$theme.perform_set("xePTIfIYg4fJ3yUz2Cv0ucfs", s.$c, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_wjHWOo2L9s4mti20Bl4xgRr7$0, 'a_wjHWOo2L9s4mti20Bl4xgRr7$0');

/* ACTION: set background picture */
function a_AKTQU67EzzZS6W1xy70h9dH4(previous, returnAddr, $theme, $pic) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_AKTQU67EzzZS6W1xy70h9dH4$0;
  s.name = "set background picture";
  s.$theme = $theme;
  s.$pic = $pic;
  return s;
}
cs.registerAction("set background picture", "AKTQU67EzzZS6W1xy70h9dH4", a_AKTQU67EzzZS6W1xy70h9dH4, false);

function a_AKTQU67EzzZS6W1xy70h9dH4$0(s) {
  (s.pc = "4.188.1");
  if (s.$theme) {
  s.$theme.perform_set("GKYkcMSe7G5kwyFRmRdC9FWX", s.$pic, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_AKTQU67EzzZS6W1xy70h9dH4$0, 'a_AKTQU67EzzZS6W1xy70h9dH4$0');

/* ACTION: level button theme */
function a_kyM6BKxra6FMoP8AENJbQMGs(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_kyM6BKxra6FMoP8AENJbQMGs$0;
  s.name = "level button theme";
  s.$level = $level;
  s.result = undefined;
  s.$id = undefined;
  s.$level_theme = undefined;
  return s;
}
cs.registerAction("level button theme", "kyM6BKxra6FMoP8AENJbQMGs", a_kyM6BKxra6FMoP8AENJbQMGs, false);

function a_kyM6BKxra6FMoP8AENJbQMGs$0(s) {
  (s.pc = "4.193.0");
  (s.$id = (ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")]));
  (s.pc = "4.193.3");
  var t_call_0 = (ok2(s, /* level theme index */ s.d.$BdGhpbmca, s.$id) && /* level theme index */ s.d.$BdGhpbmca.at(s.$id, s));
  (s.$level_theme = t_call_0);
  (s.pc = "4.193.6");
  if (s.$level_theme) {
  var t_recOp_1 = s.$level_theme.perform_get("T7dTa1GYk6ojgTI0G2RprFyk", s);
  }
  (s.result = t_recOp_1);
  return s.rt.leave();
}
cs.registerStep(a_kyM6BKxra6FMoP8AENJbQMGs$0, 'a_kyM6BKxra6FMoP8AENJbQMGs$0');

/* ACTION: clear */
function a_Py3tTGi0lf0TEZTI8El9TyIH(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_Py3tTGi0lf0TEZTI8El9TyIH$0;
  s.name = "clear";
  return s;
}
cs.registerAction("clear", "Py3tTGi0lf0TEZTI8El9TyIH", a_Py3tTGi0lf0TEZTI8El9TyIH, false);

function a_Py3tTGi0lf0TEZTI8El9TyIH$0(s) {
  (s.pc = "4.198.1");
  s.rt.logObjectMutation(/* level index */ s.d.$BbGV2ZWwgaW5kZXga);
  (ok1(s, /* level index */ s.d.$BbGV2ZWwgaW5kZXga) && /* level index */ s.d.$BbGV2ZWwgaW5kZXga.clear(s));
  (s.pc = "4.198.4");
  s.rt.logObjectMutation(/* level theme index */ s.d.$BdGhpbmca);
  (ok1(s, /* level theme index */ s.d.$BdGhpbmca) && /* level theme index */ s.d.$BdGhpbmca.clear(s));
  return s.rt.leave();
}
cs.registerStep(a_Py3tTGi0lf0TEZTI8El9TyIH$0, 'a_Py3tTGi0lf0TEZTI8El9TyIH$0');

/* ACTION: next */
function a_v1ibFfse8BhlXhYDaC3Wh2fN(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_v1ibFfse8BhlXhYDaC3Wh2fN$0;
  s.name = "next";
  s.$level = $level;
  s.result = undefined;
  return s;
}
cs.registerAction("next", "v1ibFfse8BhlXhYDaC3Wh2fN", a_v1ibFfse8BhlXhYDaC3Wh2fN, false);

function a_v1ibFfse8BhlXhYDaC3Wh2fN$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.203.1");
  var t_infix_1 = (ok1(s, (ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")])) && ((ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")]) + 1));
  var t_infix_2 = (ok2(s, t_infix_1, /* _level count */ s.d.$levelcount) && (t_infix_1 <= /* _level count */ s.d.$levelcount));
  ok1(s, t_infix_2);
  if (t_infix_2) {
  (s.pc = "4.203.50");
  var t_infix_3 = (ok1(s, (ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")])) && ((ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")]) + 1));
  var t_call_4 = (ok2(s, /* level index */ s.d.$BbGV2ZWwgaW5kZXga, t_infix_3) && /* level index */ s.d.$BbGV2ZWwgaW5kZXga.at(t_infix_3, s));
  (s.result = t_call_4);
  } else {
  (s.pc = "4.203.60");
  var t_call_5 = (ok1(s, /* level index */ s.d.$BbGV2ZWwgaW5kZXga) && /* level index */ s.d.$BbGV2ZWwgaW5kZXga.invalid(s));
  (s.result = t_call_5);
  }
  return s.rt.leave();
}
cs.registerStep(a_v1ibFfse8BhlXhYDaC3Wh2fN$0, 'a_v1ibFfse8BhlXhYDaC3Wh2fN$0');

/* ACTION: show details or start */
function a_hkrBuHpdV719LOBB6mZewhJD(previous, returnAddr, $lvl) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_hkrBuHpdV719LOBB6mZewhJD$0;
  s.name = "show details or start";
  s.$lvl = $lvl;
  return s;
}
cs.registerAction("show details or start", "hkrBuHpdV719LOBB6mZewhJD", a_hkrBuHpdV719LOBB6mZewhJD, true);

function a_hkrBuHpdV719LOBB6mZewhJD$0(s) {
  var t_elseIf_0 = true;
  (s.pc = "4.208.0");
  if (s.$lvl) {
  var t_recOp_1 = s.$lvl.perform_get("KVEfbkQ37muzCX37bf2bTBbl", s);
  }
  ok1(s, t_recOp_1);
  if (t_recOp_1) {
  (s.pc = "4.208.40");
  return s.rt.enter(a_startgame(s, a_hkrBuHpdV719LOBB6mZewhJD$3, s.$lvl));
  } else {
  (s.pc = "4.208.50");
  s.rt.forceNonRender();
  s.rt.forcePageRefresh();
  s.rt.postAutoPage(s.d.libName, "show level details", s.$lvl);
  }
  return a_hkrBuHpdV719LOBB6mZewhJD$2;
}
cs.registerStep(a_hkrBuHpdV719LOBB6mZewhJD$0, 'a_hkrBuHpdV719LOBB6mZewhJD$0');

function a_hkrBuHpdV719LOBB6mZewhJD$3(s) {
  var t_actRes_2 = s.rt.returnedFrom.result;
  t_actRes_2;
  return a_hkrBuHpdV719LOBB6mZewhJD$2;
}
cs.registerStep(a_hkrBuHpdV719LOBB6mZewhJD$3, 'a_hkrBuHpdV719LOBB6mZewhJD$3');

function a_hkrBuHpdV719LOBB6mZewhJD$2(s) {
  return s.rt.leave();
}
cs.registerStep(a_hkrBuHpdV719LOBB6mZewhJD$2, 'a_hkrBuHpdV719LOBB6mZewhJD$2');

/* ACTION: total score */
function a_vhNGQ52iSlYqwQHeL8LQGR8e(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_vhNGQ52iSlYqwQHeL8LQGR8e$0;
  s.name = "total score";
  s.result = undefined;
  s.$lvl2 = undefined;
  return s;
}
cs.registerAction("total score", "vhNGQ52iSlYqwQHeL8LQGR8e", a_vhNGQ52iSlYqwQHeL8LQGR8e, false);

function a_vhNGQ52iSlYqwQHeL8LQGR8e$0(s) {
  (s.pc = "4.213.1");
  (s.result = 0);
  (s.pc = "4.213.4");
  s.t_collArr_0 = (ok1(s, /* level index */ s.d.$BbGV2ZWwgaW5kZXga) && /* level index */ s.d.$BbGV2ZWwgaW5kZXga.get_enumerator());
  s.t_idx_1 = 0;
  return a_vhNGQ52iSlYqwQHeL8LQGR8e$1;
}
cs.registerStep(a_vhNGQ52iSlYqwQHeL8LQGR8e$0, 'a_vhNGQ52iSlYqwQHeL8LQGR8e$0');

function a_vhNGQ52iSlYqwQHeL8LQGR8e$1(s) {
  if ((s.t_idx_1 < (s.t_collArr_0.length))) {
  (s.$lvl2 = s.t_collArr_0[(s.t_idx_1)]);
  (s.t_idx_1++);
  if (s.$lvl2) {
  var t_recOp_2 = s.$lvl2.perform_get("e6cQUfw2298se1yYeqTlPcX8", s);
  }
  if (t_recOp_2) {
  (s.pc = "4.213.90");
  if (s.$lvl2) {
  var t_recOp_3 = s.$lvl2.perform_get("xF2SoxL0oxSdoSCsMwe5wRzo", s);
  }
  var t_infix_4 = (ok2(s, s.result, t_recOp_3) && (s.result + t_recOp_3));
  (s.result = t_infix_4);
  }
  return a_vhNGQ52iSlYqwQHeL8LQGR8e$1;
  }
  if (s.previous.needsPicker) {
  s.rt.displayResult("score", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_vhNGQ52iSlYqwQHeL8LQGR8e$1, 'a_vhNGQ52iSlYqwQHeL8LQGR8e$1');

/* ACTION: show score */
function a_LJpox6YpuCvn6ERcUlisZc56(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_LJpox6YpuCvn6ERcUlisZc56$0;
  s.name = "show score";
  s.$score = undefined;
  return s;
}
cs.registerAction("show score", "LJpox6YpuCvn6ERcUlisZc56", a_LJpox6YpuCvn6ERcUlisZc56, false);

function a_LJpox6YpuCvn6ERcUlisZc56$0(s) {
  (s.pc = "4.218.0");
  return s.rt.enter(a_vhNGQ52iSlYqwQHeL8LQGR8e(s, a_LJpox6YpuCvn6ERcUlisZc56$1));
}
cs.registerStep(a_LJpox6YpuCvn6ERcUlisZc56$0, 'a_LJpox6YpuCvn6ERcUlisZc56$0');

function a_LJpox6YpuCvn6ERcUlisZc56$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  (s.$score = t_actRes_0);
  var t_elseIf_1 = true;
  (s.pc = "4.218.3");
  var t_infix_2 = (ok1(s, s.$score) && (s.$score > 0));
  ok1(s, t_infix_2);
  if (t_infix_2) {
  (s.pc = "4.218.70");
  lib.Box.push_box(s);
  (s.pc = "4.218.720");
  lib.Box.set_horizontal_align("right", s);
  (s.pc = "4.218.723");
  lib.Box.set_font_size(2, s);
  (s.pc = "4.218.726");
  lib.Box.set_margins(0.5, 0, 0, 0, s);
  (s.pc = "4.218.729");
  var t_concat_3 = lib.String_.concatAny("score\u003a ", s.$score);
  (ok1(s, t_concat_3) && lib.String_.post_to_wall(t_concat_3, s));
  lib.Box.pop_box(s);
  } else {
  (s.pc = "4.218.80");
  null;
  }
  return s.rt.leave();
}
cs.registerStep(a_LJpox6YpuCvn6ERcUlisZc56$1, 'a_LJpox6YpuCvn6ERcUlisZc56$1');

/* ACTION: score */
function a_g5G6V1r466rXedV0GC2DdMLq(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_g5G6V1r466rXedV0GC2DdMLq$0;
  s.name = "score";
  s.$level = $level;
  s.result = undefined;
  return s;
}
cs.registerAction("score", "g5G6V1r466rXedV0GC2DdMLq", a_g5G6V1r466rXedV0GC2DdMLq, false);

function a_g5G6V1r466rXedV0GC2DdMLq$0(s) {
  (s.pc = "4.223.1");
  if (s.$level) {
  var t_recOp_0 = s.$level.perform_get("xF2SoxL0oxSdoSCsMwe5wRzo", s);
  }
  (s.result = t_recOp_0);
  return s.rt.leave();
}
cs.registerStep(a_g5G6V1r466rXedV0GC2DdMLq$0, 'a_g5G6V1r466rXedV0GC2DdMLq$0');

/* ACTION: set max score */
function a_LDiEr2d1hh8lQDdpGiAfUUDk(previous, returnAddr, $level, $m) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_LDiEr2d1hh8lQDdpGiAfUUDk$0;
  s.name = "set max score";
  s.$level = $level;
  s.$m = $m;
  return s;
}
cs.registerAction("set max score", "LDiEr2d1hh8lQDdpGiAfUUDk", a_LDiEr2d1hh8lQDdpGiAfUUDk, false);

function a_LDiEr2d1hh8lQDdpGiAfUUDk$0(s) {
  (s.pc = "4.228.1");
  var t_call_0 = (ok1(s, s.$m) && lib.Math_.max(0, s.$m, s));
  if (s.$level) {
  s.$level.perform_set("qod2mWVTq0MtY6ZGt7IA6uUe", t_call_0, s);
  }
  return s.rt.leave();
}
cs.registerStep(a_LDiEr2d1hh8lQDdpGiAfUUDk$0, 'a_LDiEr2d1hh8lQDdpGiAfUUDk$0');

/* ACTION: show rank */
function a_syCJwBkyr1jcu3Z9uQnocktT(previous, returnAddr, $lvl, $width, $height) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_syCJwBkyr1jcu3Z9uQnocktT$0;
  s.name = "show rank";
  s.$lvl = $lvl;
  s.$width = $width;
  s.$height = $height;
  s.$rank = undefined;
  s.$i = undefined;
  s.$rank_width = undefined;
  return s;
}
cs.registerAction("show rank", "syCJwBkyr1jcu3Z9uQnocktT", a_syCJwBkyr1jcu3Z9uQnocktT, false);

function a_syCJwBkyr1jcu3Z9uQnocktT$0(s) {
  (s.pc = "4.233.0");
  return s.rt.enter(a_g5G6V1r466rXedV0GC2DdMLq(s, a_syCJwBkyr1jcu3Z9uQnocktT$1, s.$lvl));
}
cs.registerStep(a_syCJwBkyr1jcu3Z9uQnocktT$0, 'a_syCJwBkyr1jcu3Z9uQnocktT$0');

function a_syCJwBkyr1jcu3Z9uQnocktT$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  if (s.$lvl) {
  var t_recOp_1 = s.$lvl.perform_get("qod2mWVTq0MtY6ZGt7IA6uUe", s);
  }
  var t_infix_2 = (ok2(s, t_actRes_0, t_recOp_1) && (t_actRes_0 / t_recOp_1));
  var t_infix_3 = (ok1(s, t_infix_2) && (t_infix_2 * 3));
  var t_call_4 = (ok1(s, t_infix_3) && lib.Math_.floor(t_infix_3, s));
  (s.$rank = t_call_4);
  (s.pc = "4.233.3");
  lib.Box.push_box(s);
  (s.pc = "4.233.50");
  lib.Box.set_padding(0, 0, 1, 0, s);
  (s.pc = "4.233.53");
  lib.Box.set_vertical_align("bottom", s);
  (s.pc = "4.233.56");
  lib.Box.set_horizontal_align("center", s);
  (s.pc = "4.233.59");
  (ok1(s, s.$width) && lib.Box.set_width(s.$width, s));
  (s.pc = "4.233.5c");
  (ok1(s, s.$height) && lib.Box.set_height(s.$height, s));
  (s.pc = "4.233.5f");
  lib.Box.use_horizontal_layout(s);
  (s.pc = "4.233.5i");
  s.t_bnd_5 = 3;
  (s.$i = 0);
  return a_syCJwBkyr1jcu3Z9uQnocktT$3;
}
cs.registerStep(a_syCJwBkyr1jcu3Z9uQnocktT$1, 'a_syCJwBkyr1jcu3Z9uQnocktT$1');

function a_syCJwBkyr1jcu3Z9uQnocktT$3(s) {
  if ((s.$i < s.t_bnd_5)) {
  (s.pc = "4.233.5m0");
  lib.Box.push_box(s);
  (s.pc = "4.233.5m20");
  var t_infix_6 = (ok1(s, s.$width) && (s.$width - 3));
  var t_infix_7 = (ok1(s, t_infix_6) && (t_infix_6 / 3));
  (s.$rank_width = t_infix_7);
  (s.pc = "4.233.5m23");
  (ok1(s, s.$rank_width) && lib.Box.set_width(s.$rank_width, s));
  (s.pc = "4.233.5m26");
  var t_infix_8 = (ok1(s, s.$rank_width) && (s.$rank_width / 3.2));
  (ok1(s, t_infix_8) && lib.Box.set_height(t_infix_8, s));
  (s.pc = "4.233.5m29");
  lib.Box.set_margins(0, 0.25, 0, 0.25, s);
  var t_elseIf_9 = true;
  (s.pc = "4.233.5m2c");
  var t_infix_10 = (ok2(s, s.$i, s.$rank) && (s.$i <= s.$rank));
  ok1(s, t_infix_10);
  if (t_infix_10) {
  (s.pc = "4.233.5m2g0");
  var t_call_11 = lib.Colors.orange(s);
  (ok1(s, t_call_11) && lib.Box.set_background(t_call_11, s));
  } else {
  (s.pc = "4.233.5m2h0");
  var t_call_12 = lib.Colors.gray(s);
  (ok1(s, t_call_12) && lib.Box.set_background(t_call_12, s));
  }
  lib.Box.pop_box(s);
  (s.$i++);
  return a_syCJwBkyr1jcu3Z9uQnocktT$3;
  }
  lib.Box.pop_box(s);
  return s.rt.leave();
}
cs.registerStep(a_syCJwBkyr1jcu3Z9uQnocktT$3, 'a_syCJwBkyr1jcu3Z9uQnocktT$3');

/* ACTION: index */
function a_uJZPahu4xxQkbhRSYWsWCJjm(previous, returnAddr, $level) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_uJZPahu4xxQkbhRSYWsWCJjm$0;
  s.name = "index";
  s.$level = $level;
  s.result = undefined;
  return s;
}
cs.registerAction("index", "uJZPahu4xxQkbhRSYWsWCJjm", a_uJZPahu4xxQkbhRSYWsWCJjm, false);

function a_uJZPahu4xxQkbhRSYWsWCJjm$0(s) {
  (s.pc = "4.238.1");
  (s.result = (ok1(s, s.$level) && s.$level[("xneF5ygmtTQb4TogUvxfMDe1")]));
  return s.rt.leave();
}
cs.registerStep(a_uJZPahu4xxQkbhRSYWsWCJjm$0, 'a_uJZPahu4xxQkbhRSYWsWCJjm$0');

/* ACTION: set level selection */
function a_vGJ0p4WhDBzjbpTymGtDKa6P(previous, returnAddr, $visible) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_vGJ0p4WhDBzjbpTymGtDKa6P$0;
  s.name = "set level selection";
  s.$visible = $visible;
  return s;
}
cs.registerAction("set level selection", "vGJ0p4WhDBzjbpTymGtDKa6P", a_vGJ0p4WhDBzjbpTymGtDKa6P, false);

function a_vGJ0p4WhDBzjbpTymGtDKa6P$0(s) {
  if (s.previous.needsPicker) {
  s.rt.pickParameters(a_vGJ0p4WhDBzjbpTymGtDKa6P$2, lib.RTValue.mkPicker(lib.Boolean_.picker(), false, "visible", "$visible"));
  return a_vGJ0p4WhDBzjbpTymGtDKa6P$2;
  }
  return a_vGJ0p4WhDBzjbpTymGtDKa6P$1;
}
cs.registerStep(a_vGJ0p4WhDBzjbpTymGtDKa6P$0, 'a_vGJ0p4WhDBzjbpTymGtDKa6P$0');

function a_vGJ0p4WhDBzjbpTymGtDKa6P$2(s) {
  return a_vGJ0p4WhDBzjbpTymGtDKa6P$1;
}
cs.registerStep(a_vGJ0p4WhDBzjbpTymGtDKa6P$2, 'a_vGJ0p4WhDBzjbpTymGtDKa6P$2');

function a_vGJ0p4WhDBzjbpTymGtDKa6P$1(s) {
  (s.pc = "4.244.1");
  (/* _level selection */ s.d.$xNNKA4FtL05eZdMpVoUDEmtz = s.$visible);
  s.rt.logDataWrite();
  return s.rt.leave();
}
cs.registerStep(a_vGJ0p4WhDBzjbpTymGtDKa6P$1, 'a_vGJ0p4WhDBzjbpTymGtDKa6P$1');

/* ACTION: first level */
function a_XT6yz9vjh6Ci02AGh2Y9e9pe(previous, returnAddr) {
  var s = TDev.Runtime.mkStackFrame(previous, returnAddr);
  s.entryAddr = a_XT6yz9vjh6Ci02AGh2Y9e9pe$0;
  s.name = "first level";
  s.result = undefined;
  return s;
}
cs.registerAction("first level", "XT6yz9vjh6Ci02AGh2Y9e9pe", a_XT6yz9vjh6Ci02AGh2Y9e9pe, false);

function a_XT6yz9vjh6Ci02AGh2Y9e9pe$0(s) {
  (s.pc = "4.249.1");
  return s.rt.enter(a_uIQCNem1kvZBE4J6UHoWPCK1(s, a_XT6yz9vjh6Ci02AGh2Y9e9pe$1, 1));
}
cs.registerStep(a_XT6yz9vjh6Ci02AGh2Y9e9pe$0, 'a_XT6yz9vjh6Ci02AGh2Y9e9pe$0');

function a_XT6yz9vjh6Ci02AGh2Y9e9pe$1(s) {
  var t_actRes_0 = s.rt.returnedFrom.result;
  (s.result = t_actRes_0);
  if (s.previous.needsPicker) {
  s.rt.displayResult("level", s.result)
  }
  return s.rt.leave();
}
cs.registerStep(a_XT6yz9vjh6Ci02AGh2Y9e9pe$1, 'a_XT6yz9vjh6Ci02AGh2Y9e9pe$1');

cs.startFn = function(rt) {
lib.App.rt_start(rt);
lib.Player.rt_start(rt);
lib.Senses.rt_start(rt);
lib.Time.rt_start(rt);
lib.Web.rt_start(rt);
};

cs.stopFn = function(rt) {
lib.App.rt_stop(rt);
lib.Player.rt_stop(rt);
lib.Senses.rt_stop(rt);
lib.Time.rt_stop(rt);
lib.Web.rt_stop(rt);
};

cs._compilerVersion = '1';cs._initGlobals = function(d) {
  if(!d.hasOwnProperty("$Bc3RhcnQgcGFnZSBkYXRh") || !d["$Bc3RhcnQgcGFnZSBkYXRh"]) d.$Bc3RhcnQgcGFnZSBkYXRh = new Tbl_Bc3RhcnQgcGFnZSBkYXRh(d.libName);
  if(!d.hasOwnProperty("$BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa") || !d["$BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa"]) d.$BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa = new Tbl_BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa(d.libName);
  if(!d.hasOwnProperty("$BbGV2ZWwgaW5kZXga") || !d["$BbGV2ZWwgaW5kZXga"]) d.$BbGV2ZWwgaW5kZXga = new Tbl_BbGV2ZWwgaW5kZXga(d.libName);
  if(!d.hasOwnProperty("$BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa") || !d["$BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa"]) d.$BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa = new Tbl_BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa(d.libName);
  if(!d.hasOwnProperty("$levelcount")) d.$levelcount = 0;
  if(!d.hasOwnProperty("$qTILdrMWpOE7W6v8fyiOqO8E")) d.$qTILdrMWpOE7W6v8fyiOqO8E = "";
  if(!d.hasOwnProperty("$BICBuYW1lICAa") || !d["$BICBuYW1lICAa"]) d.$BICBuYW1lICAa = new Tbl_BICBuYW1lICAa(d.libName);
  if(!d.hasOwnProperty("$Puz9SxF3xc92nwYRLTnhhcli")) d.$Puz9SxF3xc92nwYRLTnhhcli = "";
  if(!d.hasOwnProperty("$I51gPgcwfFqs55JGIhivi2xz")) d.$I51gPgcwfFqs55JGIhivi2xz = "";
  if(!d.hasOwnProperty("$xmXSki2Kan2xPa8mJmNvEq7E")) d.$xmXSki2Kan2xPa8mJmNvEq7E = "";
  if(!d.hasOwnProperty("$BdGhpbmca") || !d["$BdGhpbmca"]) d.$BdGhpbmca = new Tbl_BdGhpbmca(d.libName);
  if(!d.hasOwnProperty("$jm2ILvhcUMczcfijkGG49dZ2") || !d["$jm2ILvhcUMczcfijkGG49dZ2"]) d.$jm2ILvhcUMczcfijkGG49dZ2 = new Tbl_jm2ILvhcUMczcfijkGG49dZ2(d.libName);
  if(!d.hasOwnProperty("$xNNKA4FtL05eZdMpVoUDEmtz")) d.$xNNKA4FtL05eZdMpVoUDEmtz = false;

};

cs._initGlobals2 = function(d) {
d.$BbGV2ZWwgaW5kZXga.linked_cloudtables = [];
};

cs._resetGlobals = function(d) {
  d.$Bc3RhcnQgcGFnZSBkYXRh = undefined;
  d.$BbGV2ZWwgc2VsZWN0aW9uIHBhZ2UgZGF0YQaa = undefined;
  d.$BbGV2ZWwgaW5kZXga = undefined;
  d.$BbGV2ZWwgZGV0YWlscyBwYWdlIGRhdGEa = undefined;
  d.$levelcount = 0;
  d.$lJMupn7S4c2MRWeFYgzYI3sM = undefined;
  d.$qTILdrMWpOE7W6v8fyiOqO8E = "";
  d.$BICBuYW1lICAa = undefined;
  d.$Puz9SxF3xc92nwYRLTnhhcli = "";
  d.$I51gPgcwfFqs55JGIhivi2xz = "";
  d.$xmXSki2Kan2xPa8mJmNvEq7E = "";
  d.$BdGhpbmca = undefined;
  d.$jm2ILvhcUMczcfijkGG49dZ2 = undefined;
  d.$yX2e8ghq4LTf5saYPyFh4j7V = undefined;
  d.$A6TaCR1TM233ynuAfK2ieR1N = undefined;
  d.$xNNKA4FtL05eZdMpVoUDEmtz = false;
};

cs.mainActionName = "set credits";
cs.authorId = "jjef";
cs.scriptId = "vroyc";
cs.hasLocalData = 1;
})}
