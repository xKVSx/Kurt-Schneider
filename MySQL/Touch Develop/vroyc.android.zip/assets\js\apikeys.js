﻿// 
// Setting up the TouchDeveloper Api Keys:
// Some TouchDevelop actions require API keys.


// Show Terms Of Use page in Settings charm 
TDev.RunnerSettings.showTermsOfUse = true;
TDev.RunnerSettings.termsOfUse = '\x28no terms of use\x29'
TDev.RunnerSettings.termsOfUseUrl = 'http\x3a\x2f\x2fwww.touchdevelop.com\x2fapp\x2ff148414a.5ea4.4c52.a80b.16692175d0b9\x2ftermsofuse'
TDev.RunnerSettings.privacyStatement = 'This app does not collect any information, except analytics data as described below.'
TDev.RunnerSettings.privacyStatementUrl = 'http\x3a\x2f\x2fwww.touchdevelop.com\x2fapp\x2ff148414a.5ea4.4c52.a80b.16692175d0b9\x2fprivacy'
TDev.RunnerSettings.title = 'Hero'
TDev.RunnerSettings.description = 'Earth\x27s last chance of survival rests in the hands of its greatest hero.  Defeat the aliens and save Earth from total destruction\x21'
TDev.RunnerSettings.author = 'Kurt053205'
TDev.RunnerSettings.isGame = true;

// TouchDevelop runtime: 
// This key is required by the TouchDevelop runtime. Do not remove.
TDev.RunnerSettings.launch('f148414a.5ea4.4c52.a80b.16692175d0b9', 'android');
