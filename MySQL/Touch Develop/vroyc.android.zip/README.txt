﻿CONGRATULATIONS! You've exported your script into an Android App.

WHAT'S NEXT:

Download the Android Development Kit and open this workspace. 
Then, follow the usual Android app submission process.

ADDITIONAL INFO:

During the app submission process, you will need the following information in the 'Description' step:

  - Description: here is the description text that you gave us.

Earth's last chance of survival rests in the hands of its greatest hero.  Defeat the aliens and save Earth from total destruction!

  - Privacy Statement: TouchDevelop generated a URL containing your Privacy Statement.
  
http://www.touchdevelop.com/app/f148414a.5ea4.4c52.a80b.16692175d0b9/privacy 
  
  - Terms of Use: TouchDevelop generated a URL containing your Terms Of Use.

http://www.touchdevelop.com/app/f148414a.5ea4.4c52.a80b.16692175d0b9/termsofuse
