﻿package com.Kurt053205.vroyc;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

// A view that loads TouchDevelop in a WebView
public class TouchDevelopView extends Activity {
    @SuppressLint("SetJavaScriptEnabled") @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // don't show title bar
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        
        setContentView(R.layout.activity_touch_develop_view);     
        
        WebView myWebView = (WebView) findViewById(R.id.webview);
        myWebView.setWebViewClient(new TouchDevelopWebViewClient());
        myWebView.setWebChromeClient(new TouchDevelopWebChromeClient());
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setAppCachePath("cache");
        webSettings.setAppCacheEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setGeolocationDatabasePath("geo");
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setMediaPlaybackRequiresUserGesture(false);
        webSettings.setSupportZoom(false);        
        myWebView.addJavascriptInterface(new JsHost(this.getPackageName()), "touchDevelopHost");        
        myWebView.loadUrl("file:///android_asset/default.html");        
		AppReviewer.showAskReview(this);        
    }
    
    // replace this with WAB
    class JsHost {
    	private String packageName;
        public JsHost(final String packageName) {
        	this.packageName = packageName;
        }
    	@JavascriptInterface
        public String toString() { return "touchDevelopHost"; }
    	@JavascriptInterface
        public String storeid() {
    		return this.packageName;
    	}
    }
    
    class TouchDevelopWebChromeClient extends WebChromeClient {
    	
    }
    class TouchDevelopWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
        	Uri uri = Uri.parse(url);
        	if (uri.isAbsolute()) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                return true;
            }
            return false;
        }
    }
}
