﻿package com.Kurt053205.vroyc;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;

// Application-specific, version specific, local persistent settings.
public class LocalSettings {
	private static final String PROPERTY_APP_VERSION = "_app_version";

	public static String getPreference(final Context context, final String propertyId)
	{
		final SharedPreferences prefs = getGCMPreferences(context);
		String value = prefs.getString(propertyId, "");
		if (value.isEmpty()) {
			return "";
		}
		int registeredVersion = prefs.getInt(propertyId + PROPERTY_APP_VERSION, Integer.MIN_VALUE);
		int currentVersion = getAppVersion(context);
		if (registeredVersion != currentVersion) {
			return "";
		}
		return value;		
	}

	public static int getPreferenceInt(final Context context, final String propertyId)
	{
		final SharedPreferences prefs = getGCMPreferences(context);
		int value = prefs.getInt(propertyId, 0);
		if (value == 0) return 0;
		int registeredVersion = prefs.getInt(propertyId + PROPERTY_APP_VERSION, Integer.MIN_VALUE);
		int currentVersion = getAppVersion(context);
		if (registeredVersion != currentVersion) return 0;
		return value;		
	}
	
	static SharedPreferences getGCMPreferences(Context context) {
		return context.getSharedPreferences(LocalSettings.class.getSimpleName(), Context.MODE_PRIVATE);
	}

	static int getAppVersion(final Context context) {
		try {
			PackageInfo packageInfo = context.getPackageManager()
					.getPackageInfo(context.getPackageName(), 0);
			return packageInfo.versionCode;
		} catch (NameNotFoundException e) {
			// should never happen, default to 0
			return 1;
		}
	}

	public static void storePreference(final Context context, final String id, int value){
		final SharedPreferences prefs = getGCMPreferences(context);
		int appVersion = getAppVersion(context);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putInt(id, value);
		editor.putInt(id + PROPERTY_APP_VERSION, appVersion);
		editor.commit();		
	}
	
	public static void storePreference(final Context context, final String id, String value){
		final SharedPreferences prefs = getGCMPreferences(context);
		int appVersion = getAppVersion(context);
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString(id, value);
		editor.putInt(id + PROPERTY_APP_VERSION, appVersion);
		editor.commit();		
	}
}
