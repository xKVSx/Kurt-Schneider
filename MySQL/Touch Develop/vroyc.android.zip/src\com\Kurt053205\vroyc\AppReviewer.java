﻿package com.Kurt053205.vroyc;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

// Simple logic to ask the user for review after a certain amount of usage.
public class AppReviewer extends Activity {
	private static final String PROPERTY_START_EDITOR_COUNT = "_start_editor_count";
	private static final String PROPERTY_ASK_REVIEW_STATE = "_ask_review_state";
	private static int MinRunCount = 5;
        
    public static void showAskReview(final Context context) {
    	if (shouldAskReview(context)) {
			new AlertDialog.Builder(context)
			    .setTitle(R.string.ask_review_title)
			    .setMessage(R.string.ask_review_message)
			    .setCancelable(false)
			    .setPositiveButton(R.string.ask_review_ok, new DialogInterface.OnClickListener() {
			        public void onClick(DialogInterface dialog, int which) { 
			        	LocalSettings.storePreference(context, PROPERTY_ASK_REVIEW_STATE, 1);
			        	browseMarketplace(context);
			        }
			     })
			    .setNeutralButton(R.string.ask_review_later, new DialogInterface.OnClickListener() {
			        public void onClick(DialogInterface dialog, int which) {
			        	LocalSettings.storePreference(context, PROPERTY_START_EDITOR_COUNT, 0);
			        	
			        }
			     })
			    .setNegativeButton(R.string.ask_review_no, new DialogInterface.OnClickListener() {
			        public void onClick(DialogInterface dialog, int which) {
			        	LocalSettings.storePreference(context, PROPERTY_ASK_REVIEW_STATE, 1);		        	
			        }
			     })
			     .show();
    	}
   }
    
	static boolean shouldAskReview(final Context context) {
		return LocalSettings.getPreferenceInt(context, PROPERTY_START_EDITOR_COUNT) > MinRunCount 
			&& LocalSettings.getPreferenceInt(context, PROPERTY_ASK_REVIEW_STATE) == 0;
	}
	
	static void browseMarketplace(final Context context) {
		Uri uriUrl = Uri.parse("market://details?id=" + context.getPackageName());
		try {
			Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
			context.startActivity(launchBrowser);
		} catch(Exception ex) {
			// ignore silently
		}
	}	
}
